<?php
// Zamknięty mini v1.0 - lista_wpisow.php (panel admina)
if (!file_exists("../zamkniety_inc/config.php") || file_exists("../zamkniety_inc/zamkniety_install.php")) die("Błąd konfiguracji.");
require_once "../zamkniety_inc/config.php";
if (session_status() === PHP_SESSION_NONE) session_start();
if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
if (!administrator()) { header("Location: index.php"); exit; }

if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['admin_csrf'];

// POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('Nieprawidłowy CSRF.');
    $wid = (int)($_POST['wid'] ?? 0);
    $opt = $_POST['option'] ?? '';
    
    if ($opt === 'approve' && $wid > 0) {
        // Check current status
        $cur = $pdo->prepare("SELECT akt, slowa FROM {$prefix}wpisy WHERE id=:id"); 
        $cur->execute([':id'=>$wid]); $row = $cur->fetch();
        if ($row && $row['akt'] == 0) {
            $pdo->prepare("UPDATE {$prefix}wpisy SET akt=1 WHERE id=:id")->execute([':id'=>$wid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='wpi_a'");
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='wpi_n'");
            // Aktualizuj wpi_a w kategoriach i podkategoriach
            $rels = $pdo->prepare("SELECT id_kat, id_pod FROM {$prefix}relacje WHERE id_wpi=:id");
            $rels->execute([':id' => $wid]);
            foreach ($rels->fetchAll() as $rel) {
                $pdo->prepare("UPDATE {$prefix}kategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id' => $rel['id_kat']]);
                $pdo->prepare("UPDATE {$prefix}podkategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id' => $rel['id_pod']]);
            }
            // Dodaj tagi
            if (!empty($row['slowa'])) {
                foreach (explode(',', $row['slowa']) as $tag_raw) {
                    $tag_trim = trim($tag_raw);
                    if ($tag_trim === '') continue;
                    $tag_kod = preg_replace('/[^a-z0-9\-]/','',str_replace(' ','-',mb_strtolower($tag_trim,'UTF-8')));
                    $ex = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}tagi WHERE slowo=:s");
                    $ex->execute([':s' => $tag_trim]);
                    if ($ex->fetchColumn() < 1) {
                        $pdo->prepare("INSERT INTO {$prefix}tagi (slowo,kod,ilosc) VALUES (:s,:k,1)")->execute([':s'=>$tag_trim,':k'=>$tag_kod]);
                    } else {
                        $pdo->prepare("UPDATE {$prefix}tagi SET ilosc=ilosc+1 WHERE slowo=:s")->execute([':s'=>$tag_trim]);
                    }
                }
            }
        }
        // Wyślij mail do użytkownika jeśli pm=1
        if (!empty($cfg['pm']) && $cfg['pm'] == 1 && $wid > 0) {
            $wpis_m = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE id=:id");
            $wpis_m->execute([':id' => $wid]);
            $wpis = $wpis_m->fetch();
            if ($wpis && !empty($wpis['mail'])) {
                if (!function_exists('zm_send_mail')) require_once __DIR__ . '/mail_send.php';
                include __DIR__ . '/mail_dodano.php';
            }
        }
        header('Location: lista_wpisow.php?tab=pending&msg=approved'); exit;
    }
    if ($opt === 'deactivate' && $wid > 0) {
        $cur = $pdo->prepare("SELECT akt FROM {$prefix}wpisy WHERE id=:id");
        $cur->execute([':id'=>$wid]); $row = $cur->fetch();
        if ($row && $row['akt'] == 1) {
            $pdo->prepare("UPDATE {$prefix}wpisy SET akt=0 WHERE id=:id")->execute([':id'=>$wid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='wpi_a'");
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='wpi_n'");
            // Aktualizuj wpi_a/wpi_n w kategoriach i podkategoriach
            $rels = $pdo->prepare("SELECT id_kat, id_pod FROM {$prefix}relacje WHERE id_wpi=:id");
            $rels->execute([':id' => $wid]);
            foreach ($rels->fetchAll() as $rel) {
                $pdo->prepare("UPDATE {$prefix}kategorie SET wpi_a=GREATEST(0,wpi_a-1), wpi_n=wpi_n+1 WHERE id=:id")->execute([':id' => $rel['id_kat']]);
                $pdo->prepare("UPDATE {$prefix}podkategorie SET wpi_a=GREATEST(0,wpi_a-1), wpi_n=wpi_n+1 WHERE id=:id")->execute([':id' => $rel['id_pod']]);
            }
        }
        header('Location: lista_wpisow.php?tab=active&msg=deactivated'); exit;
    }
    if ($opt === 'delete' && $wid > 0) {
        $cur = $pdo->prepare("SELECT akt FROM {$prefix}wpisy WHERE id=:id");
        $cur->execute([':id'=>$wid]); $row = $cur->fetch();
        if ($row) {
            $col = $row['akt'] == 1 ? 'wpi_a' : 'wpi_n';
            $pdo->prepare("DELETE FROM {$prefix}wpisy WHERE id=:id")->execute([':id'=>$wid]);
            $pdo->prepare("DELETE FROM {$prefix}relacje WHERE id_wpi=:id")->execute([':id'=>$wid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='$col'");
        }
        header('Location: lista_wpisow.php?tab='.(($_POST['from_tab']??'active')).'&msg=deleted'); exit;
    }
    if ($opt === 'save_edit' && $wid > 0) {
        $tytul = htmlspecialchars(substr(strip_tags(trim($_POST['tytul']??'')),0,255),ENT_QUOTES,'UTF-8');
        $opis  = htmlspecialchars(substr(strip_tags(trim($_POST['opis']??'')),0,2000),ENT_QUOTES,'UTF-8');
        $slowa = htmlspecialchars(substr(strip_tags(trim($_POST['slowa']??'')),0,500),ENT_QUOTES,'UTF-8');
        $pdo->prepare("UPDATE {$prefix}wpisy SET tytul=:t,opis=:o,slowa=:s WHERE id=:id")
            ->execute([':t'=>$tytul,':o'=>$opis,':s'=>$slowa,':id'=>$wid]);
        header('Location: lista_wpisow.php?tab='.($_POST['from_tab']??'active').'&msg=saved'); exit;
    }
}

$tab  = $_GET['tab'] ?? 'pending';
$msg  = $_GET['msg'] ?? '';
$edit = (int)($_GET['edit'] ?? 0);
$po_ile = 20;
$min    = max(0, (int)($_GET['min'] ?? 0));

admin_site_header();

// Flash messages
$msgs = ['approved'=>'✅ ' . t('entry_approved'), 'deactivated'=>'⬜ ' . t('entry_deactivated'), 'deleted'=>'🗑️ ' . t('entry_deleted'), 'saved'=>'💾 ' . t('saved')];
if ($msg && isset($msgs[$msg])) {
    echo '<div style="background:rgba(40,160,80,0.15);border:1px solid rgba(40,160,80,0.4);border-radius:4px;padding:8px 14px;margin-bottom:12px;font-weight:bold;">'.$msgs[$msg].'</div>';
}

// Edit form
if ($edit > 0) {
    $wpi = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE id=:id"); $wpi->execute([':id'=>$edit]); $wpi = $wpi->fetch();
    if ($wpi) {
        echo '<div class="admin-section-title">✏️ ' . t('entry_edit') . ' #'.$edit.'</div>';
        echo '<form method="post" action="lista_wpisow.php">';
        echo '<input type="hidden" name="option" value="save_edit"><input type="hidden" name="csrf_token" value="'.$csrf.'">';
        echo '<input type="hidden" name="wid" value="'.$edit.'"><input type="hidden" name="from_tab" value="'.$tab.'">';
        echo '<p style="font-size:12px;color:#7a9aaa;">URL: <b>http://'.htmlspecialchars($wpi['url'].'/'.$wpi['uri'],ENT_QUOTES,'UTF-8').'</b></p>';
        echo '<table class="admin-table"><tr><th>' . t('lw_field') . '</th><th>' . t('lw_value') . '</th></tr>';
        foreach ([t('lw_tytul')=>'tytul', t('lw_opis')=>'opis', t('lw_slowa')=>'slowa'] as $lbl=>$fld) {
            $v = htmlspecialchars($wpi[$fld],ENT_QUOTES,'UTF-8');
            $tag = ($fld==='tytul') ? "input type='text' style='width:100%;'" : "textarea rows='4' style='width:100%;'";
            $close = ($fld==='tytul') ? '' : '</textarea>';
            $val = ($fld==='tytul') ? "value='$v'" : ">$v";
            echo "<tr><td style='width:150px;font-weight:bold;'>$lbl</td><td><$tag name='$fld' $val$close</td></tr>";
        }
        echo '</table><br/>';
        echo '<button type="submit" class="btn" style="width:auto;padding:8px 24px;">💾 ' . t('save') . '</button> ';
        echo '<a href="lista_wpisow.php?tab='.$tab.'" class="btn" style="background:#888;width:auto;padding:8px 24px;text-decoration:none;">↩ ' . t('cancel') . '</a>';
        echo '</form><br/>';
    }
}

// Tabs
echo '<div style="display:flex;gap:0;margin-bottom:0;border-bottom:2px solid var(--blue-light,#a8ccee);">';
$cnt_pend = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt='0'")->fetchColumn();
$cnt_act  = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt='1'")->fetchColumn();
foreach (['pending'=>'⏳ ' . t('lw_pending') . ' ('.$cnt_pend.')', 'active'=>'✅ ' . t('lw_active') . ' ('.$cnt_act.')'] as $t=>$label) {
    $active_style = ($tab===$t) ? 'background:rgba(255,255,255,0.9);font-weight:bold;border-bottom:2px solid white;' : 'background:rgba(200,220,240,0.4);';
    echo '<a href="lista_wpisow.php?tab='.$t.'" style="padding:8px 20px;text-decoration:none;color:var(--blue-dark,#1a4a80);'.$active_style.'">'.$label.'</a>';
}
echo '</div>';
echo '<div style="background:rgba(255,255,255,0.75);border:1px solid var(--border);border-top:none;padding:12px;border-radius:0 0 6px 6px;">';

// List entries
$akt_val = ($tab === 'pending') ? 0 : 1;
$all = (int)$pdo->prepare("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=:a")->execute([':a'=>$akt_val]) 
     ? $pdo->prepare("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=:a") && ($s=$pdo->prepare("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=:a")) && $s->execute([':a'=>$akt_val]) && ($all=(int)$s->fetchColumn()) 
     : 0;

$cnt_s = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=:a");
$cnt_s->execute([':a'=>$akt_val]); $all = (int)$cnt_s->fetchColumn();

$next = $min + $po_ile; $prev = $min - $po_ile;
$total_pages = (int)ceil($all / $po_ile);
$cur_page    = (int)floor($min / $po_ile) + 1;

$nav = '';
if ($total_pages > 1) {
    if ($prev >= 0) $nav .= '<a href="lista_wpisow.php?tab='.$tab.'&min='.$prev.'" style="padding:3px 8px;border:1px solid #a0c0e0;border-radius:3px;text-decoration:none;color:#2a6ab0;">&laquo;</a> ';
    for ($p = 1; $p <= $total_pages; $p++) {
        $p_min = ($p - 1) * $po_ile;
        if ($p === $cur_page) {
            $nav .= '<span style="padding:3px 9px;border:1px solid #2a6ab0;border-radius:3px;background:#2a6ab0;color:#fff;font-weight:bold;">'.$p.'</span> ';
        } elseif ($p === 1 || $p === $total_pages || abs($p - $cur_page) <= 2) {
            $nav .= '<a href="lista_wpisow.php?tab='.$tab.'&min='.$p_min.'" style="padding:3px 8px;border:1px solid #a0c0e0;border-radius:3px;text-decoration:none;color:#2a6ab0;">'.$p.'</a> ';
        } elseif (abs($p - $cur_page) === 3) {
            $nav .= '<span style="color:#aaa;">…</span> ';
        }
    }
    if ($next < $all) $nav .= '<a href="lista_wpisow.php?tab='.$tab.'&min='.$next.'" style="padding:3px 8px;border:1px solid #a0c0e0;border-radius:3px;text-decoration:none;color:#2a6ab0;">&raquo;</a>';
}

$zap = $pdo->prepare("SELECT w.*, GROUP_CONCAT(k.nazwa ORDER BY k.nazwa SEPARATOR ', ') as kat_names
    FROM {$prefix}wpisy w
    LEFT JOIN {$prefix}relacje r ON r.id_wpi=w.id
    LEFT JOIN {$prefix}kategorie k ON k.id=r.id_kat
    WHERE w.akt=:a GROUP BY w.id ORDER BY w.data DESC LIMIT :min,:po");
$zap->bindValue(':a', $akt_val, PDO::PARAM_INT);
$zap->bindValue(':min', $min, PDO::PARAM_INT);
$zap->bindValue(':po', $po_ile, PDO::PARAM_INT);
$zap->execute();
$rows = $zap->fetchAll();

if ($nav) echo '<div style="margin-bottom:10px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;font-size:12px;"><span style="color:#7a9aaa;">'.($min+1).'-'.min($all,$min+$po_ile).' / '.$all.':</span> '.$nav.'</div>';

if ($rows) {
    echo '<table class="admin-table">';
    echo '<tr><th>' . t('lw_col_title') . '</th><th>' . t('category') . '</th><th>' . t('col_date') . '</th><th>' . t('col_actions') . '</th></tr>';
    foreach ($rows as $row) {
        $t_e = htmlspecialchars($row['tytul'],ENT_QUOTES,'UTF-8');
        $u_e = htmlspecialchars('http://'.$row['url'].($row['uri']?'/'.$row['uri']:''),ENT_QUOTES,'UTF-8');
        $d_e = date('d-m-Y',(int)$row['data']);
        $k_e = htmlspecialchars($row['kat_names']??'—',ENT_QUOTES,'UTF-8');
        echo '<tr>';
        echo '<td><b>'.$t_e.'</b><br/><span style="font-size:11px;color:#7a9aaa;"><a href="'.$u_e.'" target="_blank">'.$u_e.'</a></span></td>';
        echo '<td style="font-size:11px;">'.$k_e.'</td>';
        echo '<td style="white-space:nowrap;">'.$d_e.'</td>';
        echo '<td style="white-space:nowrap;">';
        echo '<a href="lista_wpisow.php?tab='.$tab.'&edit='.(int)$row['id'].'" class="btn" style="padding:3px 8px;font-size:11px;">✏️</a> ';
        if ($tab === 'pending') {
            echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="approve"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.(int)$row['id'].'"><button type="submit" class="btn" style="padding:3px 8px;font-size:11px;" title="' . t('activate') . '">✅</button></form> ';
        } else {
            echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="deactivate"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.(int)$row['id'].'"><button type="submit" class="btn" style="padding:3px 8px;font-size:11px;background:#888;" title="' . t('disable') . '">⬜</button></form> ';
        }
        echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="delete"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.(int)$row['id'].'"><input type="hidden" name="from_tab" value="'.$tab.'"><button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;" onclick="return confirm(\'' . t('confirm_delete_entry') . '\')" title="' . t('delete') . '">🗑️</button></form>';
        echo '</td></tr>';
    }
    echo '</table>';
    if ($nav) echo '<div style="margin-top:10px;display:flex;align-items:center;gap:6px;flex-wrap:wrap;">'.$nav.'</div>';
} else {
    echo '<p style="color:#7a9aaa;padding:20px 0;">'.($tab==='pending' ? t('lw_no_pending') : t('lw_no_active')).'</p>';
}
echo '</div>';

admin_site_footer();
