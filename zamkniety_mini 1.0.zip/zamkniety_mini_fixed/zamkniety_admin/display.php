<?php
// Zamknięty mini v1.0 - display.php (panel admina - edytor szablonu)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        $csrf = $_SESSION['admin_csrf'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('Nieprawidłowy CSRF.');
            foreach ($_POST as $key => $val) {
                if ($key === 'csrf_token') continue;
                $key_s = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
                $pdo->prepare("UPDATE {$prefix}template SET wartosc=:v WHERE nazwa=:n")->execute([':v' => $val, ':n' => $key_s]);
            }
            header("Location: display.php?saved=1"); exit;
        }

        admin_site_header();
        echo '<div class="admin-section-title">' . t('appearance_title') . '</div>';
        if (($_GET['saved'] ?? '') === '1') echo '<div style="color:green;">✅ ' . t('saved') . '</div>';
        // Opisy pól szablonu
        $field_help = [
            'top'           => 'Nagłówek strony (pasek u góry). Może zawierać HTML, np. logo lub nazwę serwisu.',
            'foot'          => 'Stopka strony (pasek u dołu). Może zawierać HTML, prawa autorskie itp.',
            'blockleft'     => 'Lista bloków lewej kolumny oddzielona znakiem <b>|</b>. Każda nazwa musi odpowiadać polu poniżej (np. <code>blok_menu|blok_wyszukiwarka|blok_statystyki</code>). Kolumna jest widoczna tylko gdy <b>leftwidth &gt; 0</b>.',
            'blockright'    => 'Lista bloków prawej kolumny oddzielona znakiem <b>|</b> (np. <code>blok_reklama</code>). Kolumna jest widoczna tylko gdy <b>rightwidth &gt; 0</b>.',
            'leftwidth'     => 'Szerokość lewej kolumny w pikselach. Ustaw <b>0</b> aby ukryć lewą kolumnę.',
            'leftwidthsep'  => 'Odstęp (w px) między lewą kolumną a treścią. Domyślnie 5.',
            'rightwidth'    => 'Szerokość prawej kolumny w pikselach. Ustaw <b>0</b> aby ukryć prawą kolumnę.',
            'rightwidthsep' => 'Odstęp (w px) między treścią a prawą kolumną.',
            'mainwidth'     => 'Całkowita szerokość layoutu w pikselach (np. 780). Szerokość treści = mainwidth − leftwidth − leftwidthsep − rightwidth − rightwidthsep.',
            'center'        => 'Szerokość środkowej kolumny (treści) w px — wyliczana automatycznie z mainwidth, zwykle nie trzeba zmieniać.',
            'welcome'       => 'Tekst powitalny wyświetlany na górze strony głównej. Może zawierać HTML.',
            'stat1'         => 'Kod statystyk zewnętrznych wstawiany w &lt;head&gt; (np. Google Analytics, tag &lt;script&gt;). Wstaw skrypt śledzący.',
            'stat2'         => 'Kod statystyk wstawiany na końcu &lt;body&gt; (np. licznik widoczny na stronie).',
            'stat3'         => 'Dodatkowy kod w &lt;head&gt; (np. meta tagi, style CSS).',
            'ads1'          => 'Reklama/HTML wyświetlany pod nagłówkiem, przed lewą kolumną i treścią.',
            'ads2'          => 'Reklama/HTML wyświetlany na górze obszaru treści (nad listą kategorii/wpisów).',
            'ads3'          => 'Reklama/HTML wyświetlany na dole obszaru treści (pod listą kategorii/wpisów).',
            'ads4'          => 'Reklama/HTML wyświetlany nad stopką.',
            'inf'           => 'Treść strony <b>Regulamin</b> (dostępna pod adresem /inf.html). Może zawierać HTML.',
            'blok_menu'     => '<b>Wbudowany blok</b> — menu nawigacyjne. Używany w blockleft/blockright przez wpisanie nazwy <code>blok_menu</code>.',
            'blok_wyszukiwarka' => '<b>Wbudowany blok</b> — formularz wyszukiwarki. Używany przez wpisanie nazwy <code>blok_wyszukiwarka</code>.',
        ];

        // Domyślna kolejność wyświetlania pól
        $field_order = ['top','foot','blockleft','blockright','leftwidth','leftwidthsep','rightwidth','rightwidthsep','mainwidth','center','welcome','stat1','stat2','stat3','ads1','ads2','ads3','ads4','inf'];

        // Opisy specjalnych tagów
        echo '<div style="background:#e8f0f8;border:1px solid #a0c0e0;border-radius:6px;padding:12px 16px;margin-bottom:16px;font-size:12px;line-height:1.7;">';
        echo '<b>📋 Jak działają bloki (blockleft / blockright):</b><br>';
        echo 'Wpisz nazwy bloków oddzielone <code>|</code>, np: <code>blok_menu|blok_wyszukiwarka|blok_statystyki</code><br>';
        echo 'Każda nazwa musi mieć odpowiadające pole poniżej (możesz dodać własny blok tworząc nowe pole o nazwie np. <code>blok_statystyki</code>).<br><br>';
        echo '<b>🔧 Dostępne wbudowane bloki:</b><br>';
        echo '• <code>blok_menu</code> — menu z linkami Strona główna / Regulamin<br>';
        echo '• <code>blok_wyszukiwarka</code> — formularz wyszukiwania<br><br>';
        echo '<b>🔌 Tag <code>&lt;php&gt;plik.php&lt;/php&gt;</code></b> — dołącza plik PHP z głównego katalogu skryptu, np:<br>';
        echo '• <code>&lt;php&gt;statPL.php&lt;/php&gt;</code> — statystyki katalogu (PL)<br>';
        echo '• <code>&lt;php&gt;statENG.php&lt;/php&gt;</code> — statystyki katalogu (EN)<br>';
        echo '• <code>&lt;php&gt;formularz.php&lt;/php&gt;</code> — wyszukiwarka (już w blok_wyszukiwarka)<br><br>';
        echo 'Poza tagiem <code>&lt;php&gt;</code> każde pole akceptuje zwykły <b>HTML</b> (tekst, obrazki, tabele, skrypty reklamowe itp.)';
        echo '</div>';

        echo '<form method="post" action="display.php">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '" />';

        // Pobierz wszystkie pola z bazy
        $all_rows = [];
        foreach ($pdo->query("SELECT * FROM {$prefix}template") as $row) {
            $all_rows[$row['nazwa']] = $row['wartosc'];
        }

        // Wyświetl pola w ustalonej kolejności
        $shown = [];
        foreach ($field_order as $fname) {
            if (!array_key_exists($fname, $all_rows)) continue;
            $shown[] = $fname;
            $n = htmlspecialchars($fname, ENT_QUOTES, 'UTF-8');
            $v = htmlspecialchars($all_rows[$fname], ENT_QUOTES, 'UTF-8');
            $help = $field_help[$fname] ?? '';
            $rows_count = in_array($fname, ['welcome','inf','ads1','ads2','ads3','ads4','foot','top','blok_menu','blok_wyszukiwarka']) ? 4 : 2;
            echo '<div style="margin-bottom:12px;padding:10px 12px;background:rgba(240,246,252,0.8);border:1px solid rgba(160,200,240,0.4);border-radius:5px;">';
            echo '<b style="font-size:13px;color:#1a3a6a;">' . $n . '</b>';
            if ($help) echo '<div style="font-size:11px;color:#5a7a9a;margin:3px 0 5px 0;">' . $help . '</div>';
            echo '<textarea name="' . $n . '" rows="' . $rows_count . '" style="width:100%;font-size:12px;font-family:monospace;padding:5px;border:1px solid #b0c8e0;border-radius:3px;box-sizing:border-box;">' . $v . '</textarea>';
            echo '</div>';
        }

        // Wyświetl pozostałe pola (własne bloki dodane przez użytkownika)
        foreach ($all_rows as $fname => $fval) {
            if (in_array($fname, $shown)) continue;
            $n = htmlspecialchars($fname, ENT_QUOTES, 'UTF-8');
            $v = htmlspecialchars($fval, ENT_QUOTES, 'UTF-8');
            $help = $field_help[$fname] ?? '<i>Własny blok — użyj nazwy <code>' . $n . '</code> w blockleft lub blockright.</i>';
            echo '<div style="margin-bottom:12px;padding:10px 12px;background:rgba(240,252,240,0.8);border:1px solid rgba(100,200,100,0.4);border-radius:5px;">';
            echo '<b style="font-size:13px;color:#1a6a1a;">' . $n . '</b> <span style="font-size:10px;color:#5a9a5a;">(własny blok)</span>';
            if ($help) echo '<div style="font-size:11px;color:#5a7a5a;margin:3px 0 5px 0;">' . $help . '</div>';
            echo '<textarea name="' . $n . '" rows="4" style="width:100%;font-size:12px;font-family:monospace;padding:5px;border:1px solid #b0d0b0;border-radius:3px;box-sizing:border-box;">' . $v . '</textarea>';
            echo '</div>';
        }

        echo '<button type="submit" class="btn">' . t('save') . '</button>';
        echo '</form>';
        admin_site_footer();
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
