<?php
// ============================================================
// Zamknięty mini v1.0 - Instalator / Aktualizator
// PHP 8.4, PDO, UTF-8
// ============================================================

$stop = '';
$done = false;
$done_mode = ''; // 'install' or 'update'

if ($_SERVER['REQUEST_METHOD'] === 'POST' && in_array($_POST['option'] ?? '', ['install','update'])) {

    $mode   = $_POST['option'];
    $dbhost = trim($_POST['dbhost'] ?? '');
    $dbuser = trim($_POST['dbuser'] ?? '');
    $dbpss  = trim($_POST['dbpss']  ?? '');
    $dbname = trim($_POST['dbname'] ?? '');
    $prefix = preg_replace('/[^a-zA-Z0-9_]/', '', trim($_POST['prefix'] ?? 'zm_'));
    $dir    = trim($_POST['dir']    ?? '');
    $login  = trim($_POST['login']  ?? '');
    $pass   = trim($_POST['pass']   ?? '');

    if ($dbhost === '' || $dbuser === '' || $dbname === '') $stop = 'Wypełnij wszystkie pola bazy danych.';
    if ($dir    === '')                                      $stop = 'Podaj ścieżkę na dysku do katalogu głównego skryptu.';
    if ($mode === 'install' && ($login === '' || $pass === '')) $stop = 'Podaj login i hasło administratora.';

    // Połącz z bazą
    if (empty($stop)) {
        try {
            $pdo = new PDO(
                "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4",
                $dbuser, $dbpss,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
            );
        } catch (PDOException $e) {
            $stop = 'Błąd połączenia z bazą: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }
    }

    // ============================================================
    // TRYB: AKTUALIZACJA — zachowuje wszystkie dane
    // Tworzy brakujące tabele, dodaje brakujące kolumny i klucze
    // ============================================================
    if (empty($stop) && $mode === 'update') {

        // 1. Napraw PRIMARY KEY na konfiguracja jeśli brakuje
        $res = $pdo->query("SHOW INDEX FROM `{$prefix}konfiguracja` WHERE Key_name='PRIMARY'");
        if ($res && $res->rowCount() === 0) {
            // Usuń duplikaty, dodaj PRIMARY KEY
            $pdo->exec("CREATE TABLE `{$prefix}konfiguracja_tmp` (
                `nazwa` varchar(100) NOT NULL DEFAULT '',
                `wartosc` varchar(255) NOT NULL DEFAULT '',
                PRIMARY KEY (`nazwa`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("INSERT INTO `{$prefix}konfiguracja_tmp` (nazwa,wartosc)
                SELECT nazwa, MAX(wartosc) FROM `{$prefix}konfiguracja` GROUP BY nazwa");
            $pdo->exec("DROP TABLE `{$prefix}konfiguracja`");
            $pdo->exec("RENAME TABLE `{$prefix}konfiguracja_tmp` TO `{$prefix}konfiguracja`");
        }

        // 2. Napraw PRIMARY KEY na ilosci jeśli brakuje
        $res = $pdo->query("SHOW INDEX FROM `{$prefix}ilosci` WHERE Key_name='PRIMARY'");
        if ($res && $res->rowCount() === 0) {
            $pdo->exec("CREATE TABLE `{$prefix}ilosci_tmp` (
                `nazwa` varchar(100) NOT NULL DEFAULT '',
                `ilosc` int NOT NULL DEFAULT 0,
                PRIMARY KEY (`nazwa`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
            $pdo->exec("INSERT INTO `{$prefix}ilosci_tmp` (nazwa,ilosc)
                SELECT nazwa, MAX(ilosc) FROM `{$prefix}ilosci` GROUP BY nazwa");
            $pdo->exec("DROP TABLE `{$prefix}ilosci`");
            $pdo->exec("RENAME TABLE `{$prefix}ilosci_tmp` TO `{$prefix}ilosci`");
        }

        // 3. Utwórz brakujące tabele (CREATE TABLE IF NOT EXISTS — nie rusza istniejących)
        $pdo->exec("CREATE TABLE IF NOT EXISTS `{$prefix}wizyty` (
            `ip` varchar(45) NOT NULL DEFAULT '',
            `dzien` date NOT NULL,
            PRIMARY KEY (`ip`,`dzien`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `{$prefix}tagi` (
            `id` int NOT NULL AUTO_INCREMENT,
            `slowo` varchar(300) NOT NULL,
            `kod` varchar(300) NOT NULL DEFAULT '',
            `ilosc` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `slowo` (`slowo`(100))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `{$prefix}blokowane` (
            `id` int NOT NULL AUTO_INCREMENT,
            `adres` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE IF NOT EXISTS `{$prefix}filtr` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` text,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->prepare("INSERT IGNORE INTO `{$prefix}filtr` VALUES ('frazy', NULL)")->execute();

        // 4. Dodaj brakujące klucze konfiguracyjne (INSERT IGNORE — nie nadpisuje istniejących)
        $cfg_defaults = [
            'glotag'=>'0','glotag_min'=>'0','glotag_ilo'=>'20',
            'anchor'=>'0','anchor_ilo'=>'3','anchor_opi'=>'300',
            'dodkat'=>'0','pob_tresc'=>'0',
            'rss'=>'0','rss_kanal'=>'','rss_link'=>'1','rss_ilo'=>'5',
            'link_zwr'=>'0','link_prz'=>'1','link_sor'=>'1',
            'link_adres'=>'http://','link_opis'=>'Link zwrotny',
            'link_anchor_1'=>'Katalog Stron','link_anchor_2'=>'','link_anchor_3'=>'',
            'opr'=>'0','opr_key'=>'',
            'loktag'=>'1','wp'=>'1','iw'=>'1','min'=>'1','pm'=>'1',
            'wersja'=>'zamkniety-mini-v1.0',
        ];
        foreach ($cfg_defaults as $n => $v) {
            $pdo->prepare("INSERT IGNORE INTO `{$prefix}konfiguracja` (nazwa,wartosc) VALUES (:n,:v)")
                ->execute([':n'=>$n, ':v'=>$v]);
        }

        // 5. Dodaj brakujące liczniki do ilosci
        $ilosci_defaults = [
            'kat_a'=>0,'kat_n'=>0,'pod_a'=>0,'pod_n'=>0,
            'wpi_a'=>0,'wpi_n'=>0,'rel'=>0,'moje'=>0,
            'seslasttime'=>0,'sescount'=>0,'odwiedziny'=>0,
        ];
        foreach ($ilosci_defaults as $n => $v) {
            $pdo->prepare("INSERT IGNORE INTO `{$prefix}ilosci` (nazwa,ilosc) VALUES (:n,:v)")
                ->execute([':n'=>$n, ':v'=>$v]);
        }

        // 6. Synchronizuj liczniki wpi_a/wpi_n w kategoriach i podkategoriach
        $pdo->exec("UPDATE `{$prefix}kategorie` k SET
            k.wpi_a = (SELECT COUNT(*) FROM `{$prefix}relacje` r
                       JOIN `{$prefix}wpisy` w ON w.id=r.id_wpi AND w.akt=1 WHERE r.id_kat=k.id),
            k.wpi_n = (SELECT COUNT(*) FROM `{$prefix}relacje` r
                       JOIN `{$prefix}wpisy` w ON w.id=r.id_wpi AND w.akt=0 WHERE r.id_kat=k.id)");
        $pdo->exec("UPDATE `{$prefix}podkategorie` p SET
            p.wpi_a = (SELECT COUNT(*) FROM `{$prefix}relacje` r
                       JOIN `{$prefix}wpisy` w ON w.id=r.id_wpi AND w.akt=1 WHERE r.id_pod=p.id),
            p.wpi_n = (SELECT COUNT(*) FROM `{$prefix}relacje` r
                       JOIN `{$prefix}wpisy` w ON w.id=r.id_wpi AND w.akt=0 WHERE r.id_pod=p.id)");

        // 7. Synchronizuj globalne liczniki
        $pdo->exec("UPDATE `{$prefix}ilosci` SET ilosc=(SELECT COUNT(*) FROM `{$prefix}wpisy` WHERE akt=1) WHERE nazwa='wpi_a'");
        $pdo->exec("UPDATE `{$prefix}ilosci` SET ilosc=(SELECT COUNT(*) FROM `{$prefix}wpisy` WHERE akt=0) WHERE nazwa='wpi_n'");
        $pdo->exec("UPDATE `{$prefix}ilosci` SET ilosc=(SELECT COUNT(*) FROM `{$prefix}kategorie` WHERE akt=1) WHERE nazwa='kat_a'");
        $pdo->exec("UPDATE `{$prefix}ilosci` SET ilosc=(SELECT COUNT(*) FROM `{$prefix}podkategorie` WHERE akt=1) WHERE nazwa='pod_a'");
        $pdo->exec("UPDATE `{$prefix}ilosci` SET ilosc=(SELECT COUNT(*) FROM `{$prefix}relacje`) WHERE nazwa='rel'");

        // 8. Zapisz config.php (tylko połączenie — login/hasło admina bez zmian)
        $h_dir  = rtrim($dir, '/');
        $config = "<?php\n";
        $config .= "\$home_dir = " . var_export($h_dir,  true) . ";\n";
        $config .= "\$dbhost   = " . var_export($dbhost, true) . ";\n";
        $config .= "\$dbuser   = " . var_export($dbuser, true) . ";\n";
        $config .= "\$dbpss    = " . var_export($dbpss,  true) . ";\n";
        $config .= "\$dbname   = " . var_export($dbname, true) . ";\n";
        $config .= "\$prefix   = " . var_export($prefix, true) . ";\n";
        // Zachowaj stary login i hasło jeśli istnieje config
        $old_cfg = __DIR__ . '/config.php';
        if (file_exists($old_cfg)) {
            $old_vars = [];
            include $old_cfg;
            $config .= "\$login    = " . var_export($login ?? '', true) . ";\n";
            $config .= "\$pass     = " . var_export($pass  ?? '', true) . ";\n";
        } else {
            $config .= "\$login    = " . var_export($login, true) . ";\n";
            $config .= "\$pass     = " . var_export($pass,  true) . ";\n";
        }

        $config_path = __DIR__ . '/config.php';
        if (file_put_contents($config_path, $config) === false) {
            $stop = 'Nie można zapisać pliku config.php. Sprawdź uprawnienia katalogu zamkniety_inc/.';
        } else {
            $done = true;
            $done_mode = 'update';
        }
    }

    // ============================================================
    // TRYB: ŚWIEŻA INSTALACJA — usuwa wszystkie dane i tworzy od nowa
    // ============================================================
    if (empty($stop) && $mode === 'install') {

        $tables = ['blokowane','filtr','ilosci','kategorie','konfiguracja','podkategorie','relacje','sesje','tagi','template','wizyty','wpisy'];
        foreach ($tables as $t) {
            $pdo->exec("DROP TABLE IF EXISTS `{$prefix}{$t}`");
        }

        $pdo->exec("CREATE TABLE `{$prefix}blokowane` (
            `id` int NOT NULL AUTO_INCREMENT,
            `adres` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}filtr` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` text,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("INSERT INTO `{$prefix}filtr` VALUES ('frazy', NULL)");

        $pdo->exec("CREATE TABLE `{$prefix}ilosci` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `ilosc` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        foreach (['kat_a'=>12,'kat_n'=>0,'pod_a'=>36,'pod_n'=>0,'wpi_a'=>8,'wpi_n'=>0,'rel'=>11,'moje'=>0,'seslasttime'=>0,'sescount'=>0,'odwiedziny'=>0] as $n=>$v) {
            $pdo->prepare("INSERT INTO `{$prefix}ilosci` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}kategorie` (
            `id` int NOT NULL AUTO_INCREMENT,
            `nazwa` varchar(255) NOT NULL DEFAULT '',
            `data` int NOT NULL DEFAULT 0,
            `pod_a` int NOT NULL DEFAULT 0,
            `pod_n` int NOT NULL DEFAULT 0,
            `wpi_a` int NOT NULL DEFAULT 0,
            `wpi_n` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `nazwa` (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $sample_cats = [
            [1,'Sport, turystyka',3,1],[2,'Hobby, rozrywka',3,1],[3,'Zdrowie, uroda',3,1],
            [4,'Biznes, ekonomia',3,1],[5,'Budownictwo',3,1],[6,'Edukacja, nauka',3,1],
            [7,'Firmy wg branż',3,1],[8,'Internet, komputery',3,1],[9,'Reklama, marketing',3,1],
            [10,'Motoryzacja',3,1],[11,'Kultura, sztuka',3,1],[12,'RTV, AGD, GSM',3,1],
        ];
        $t = time();
        foreach ($sample_cats as [$id,$nazwa,$pod_a,$akt]) {
            $pdo->prepare("INSERT INTO `{$prefix}kategorie` (id,nazwa,data,pod_a,akt) VALUES (:id,:n,:d,:p,:a)")
                ->execute([':id'=>$id,':n'=>$nazwa,':d'=>$t,':p'=>$pod_a,':a'=>$akt]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}konfiguracja` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $cfg_vals = [
            'o1'=>'Nazwa Twojego katalogu','o2'=>'Opis Twojego katalogu','o3'=>'Słowa kluczowe',
            'o4'=>'http://'.$_SERVER['HTTP_HOST'],'f1'=>'index',
            'g1'=>'3','g2'=>'1','g3'=>'3','g4'=>'1','g5'=>'3',
            'k1'=>'3','k2'=>'1','k3'=>'3','p1'=>'10','p2'=>'1',
            'u1'=>'2','u2'=>'2','u3'=>'2','u4'=>'10','u5'=>'1',
            'w1'=>'1','w2'=>'1','w3'=>'2','w4'=>'2','w5'=>'1','w6'=>'1',
            'm1'=>'3','m2'=>'-','m3'=>'kat','m4'=>'pod','m5'=>'szcz','m6'=>'inf','m7'=>'1','m8'=>'',
            's1'=>'5000','s2'=>'googleNumerWeryf','s3'=>'1',
            'wp'=>'1','iw'=>'1','min'=>'1','pm'=>'1','loktag'=>'1','glotag'=>'0',
            'glotag_min'=>'0','glotag_ilo'=>'20','anchor'=>'0','anchor_ilo'=>'3','anchor_opi'=>'300',
            'dodkat'=>'0','pob_tresc'=>'0','rss'=>'0','rss_kanal'=>'','rss_link'=>'1','rss_ilo'=>'5',
            'link_zwr'=>'0','link_prz'=>'1','link_sor'=>'1','link_adres'=>'http://','link_opis'=>'Link zwrotny',
            'link_anchor_1'=>'Katalog Stron','link_anchor_2'=>'','link_anchor_3'=>'',
            'mail_nadaw'=>'katalog@katalog.pl','mail_odkog'=>'Administrator','mail_chars'=>'UTF-8',
            'maild_tem'=>'Wpis zatwierdzony!','maild_tre'=>'Witaj, Twój wpis został dodany do [MyBB[home]]. Zobacz: [MyBB[id]]',
            'mailu_tem'=>'Wpis odrzucony','mailu_tre'=>'Witaj, Twój wpis nie został dodany do [MyBB[home]].',
            'wersja'=>'zamkniety-mini-v1.0','opr'=>'0','opr_key'=>'',
        ];
        foreach ($cfg_vals as $n => $v) {
            $pdo->prepare("INSERT INTO `{$prefix}konfiguracja` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}podkategorie` (
            `id` int NOT NULL AUTO_INCREMENT,
            `id_kat` int NOT NULL DEFAULT 0,
            `nazwa` varchar(255) NOT NULL DEFAULT '',
            `data` int NOT NULL DEFAULT 0,
            `wpi_a` int NOT NULL DEFAULT 0,
            `wpi_n` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `nazwa` (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $sample_pods = [
            [6,'Chemia'],[12,'Aparaty cyfrowe'],[12,'Akcesoria gsm'],[8,'Pozycjonowanie'],[8,'Gry komputerowe'],
            [10,'Lakiernik'],[10,'Akcesoria samochodowe'],[6,'Angielski'],[6,'Astronomia'],[12,'Anteny satelitarne'],
            [8,'Katalogi stron'],[3,'Gabinety kosmetyczne'],[3,'Moda'],[2,'Sylwester'],[3,'Kobiety'],
            [10,'Auto ubezpieczenia'],[11,'Aktorzy'],[11,'Film'],[11,'Fotografia'],[1,'Agroturystyka'],
            [1,'Apartamenty'],[1,'Hotele'],[7,'Agencje promocji'],[7,'Aparatura pomiarowa'],[5,'Aranżacja wnętrz'],
            [4,'Agencje pracy'],[4,'Agencje reklamowe'],[2,'Dowcipy'],[2,'Imprezy'],[9,'Reklama'],
            [9,'Marketing'],[9,'Artykuły reklamowe'],[4,'Agencje interaktywne'],[5,'Architektura'],[5,'Automatyka'],
            [7,'Aranżacja wnętrz'],
        ];
        foreach ($sample_pods as [$kat_id,$nazwa]) {
            $pdo->prepare("INSERT INTO `{$prefix}podkategorie` (id_kat,nazwa,data,akt) VALUES (:k,:n,:d,1)")
                ->execute([':k'=>$kat_id,':n'=>$nazwa,':d'=>$t]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}relacje` (
            `id` int NOT NULL AUTO_INCREMENT,
            `id_kat` int NOT NULL DEFAULT 0,
            `id_pod` int NOT NULL DEFAULT 0,
            `id_wpi` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}sesje` (
            `ip` varchar(255) NOT NULL DEFAULT '',
            `host` varchar(255) NOT NULL DEFAULT '',
            `ua` varchar(255) NOT NULL DEFAULT '',
            `czas` varchar(10) NOT NULL DEFAULT '',
            `gdzie_jest` varchar(255) NOT NULL DEFAULT '',
            `sesref` text NOT NULL,
            `ident` varchar(255) NOT NULL DEFAULT '',
            `token` varchar(255) NOT NULL DEFAULT '',
            KEY `ident` (`ident`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}wizyty` (
            `ip` varchar(45) NOT NULL DEFAULT '',
            `dzien` date NOT NULL,
            PRIMARY KEY (`ip`,`dzien`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}tagi` (
            `id` int NOT NULL AUTO_INCREMENT,
            `slowo` varchar(300) NOT NULL,
            `kod` varchar(300) NOT NULL DEFAULT '',
            `ilosc` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `slowo` (`slowo`(100))
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}template` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` text NOT NULL,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $tpl_vals = ['welcome'=>'','ads2'=>'','ads3'=>'','stat1'=>'','stat2'=>'','stat3'=>'','mainwidth'=>'780','leftwidth'=>'0','rightwidth'=>'0','leftwidthsep'=>'0','rightwidthsep'=>'0'];
        foreach ($tpl_vals as $n => $v) {
            $pdo->prepare("INSERT INTO `{$prefix}template` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}wpisy` (
            `id` int NOT NULL AUTO_INCREMENT,
            `data` int NOT NULL DEFAULT 0,
            `tytul` varchar(255) NOT NULL DEFAULT '',
            `opis` text NOT NULL,
            `slowa` text NOT NULL,
            `url` varchar(255) NOT NULL DEFAULT '',
            `uri` varchar(255) NOT NULL DEFAULT '',
            `pr` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `klikniecia` int NOT NULL DEFAULT 0,
            `relacji` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            `moje` int NOT NULL DEFAULT 0,
            `mail` varchar(100) NOT NULL DEFAULT '',
            `rss` varchar(255) NOT NULL DEFAULT '',
            `link_zwrotny` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`),
            KEY `tytul` (`tytul`),
            FULLTEXT KEY `search_idx` (`tytul`,`opis`,`slowa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Zapisz config.php
        $h_dir  = rtrim($dir, '/');
        $config = "<?php\n";
        $config .= "\$home_dir = " . var_export($h_dir,  true) . ";\n";
        $config .= "\$dbhost   = " . var_export($dbhost, true) . ";\n";
        $config .= "\$dbuser   = " . var_export($dbuser, true) . ";\n";
        $config .= "\$dbpss    = " . var_export($dbpss,  true) . ";\n";
        $config .= "\$dbname   = " . var_export($dbname, true) . ";\n";
        $config .= "\$prefix   = " . var_export($prefix, true) . ";\n";
        $config .= "\$login    = " . var_export($login,  true) . ";\n";
        $config .= "\$pass     = " . var_export($pass,   true) . ";\n";

        $config_path = __DIR__ . '/config.php';
        if (file_put_contents($config_path, $config) === false) {
            $stop = 'Nie można zapisać pliku config.php. Sprawdź uprawnienia katalogu zamkniety_inc/.';
        } else {
            $done = true;
            $done_mode = 'install';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>Instalacja / Aktualizacja — Zamknięty mini v1.0</title>
<style>
body{font-family:Arial,sans-serif;font-size:13px;background:#dce9f5;color:#1a2a3a;padding:30px;}
h1{color:#1a4a80;}
.box{background:rgba(255,255,255,0.85);border:1px solid rgba(60,130,200,0.3);border-radius:8px;padding:24px;max-width:540px;margin:0 auto;}
label{display:block;margin-top:10px;font-weight:bold;}
input[type=text],input[type=password]{width:100%;padding:6px;border:1px solid #a0c0e0;border-radius:3px;margin-top:3px;box-sizing:border-box;}
.btn-row{display:flex;gap:10px;margin-top:18px;}
button{padding:9px 22px;border:none;border-radius:4px;font-size:13px;cursor:pointer;font-weight:bold;}
.btn-update{background:#2a9a50;color:#fff;}
.btn-install{background:#c03030;color:#fff;}
.err{color:red;margin-bottom:10px;padding:8px;background:#fff0f0;border-radius:4px;}
.ok-update{color:#1a6a30;background:#e8f8ee;padding:10px;border-radius:4px;border:1px solid #8ad0a8;}
.ok-install{color:#1a4a80;background:#e8f0f8;padding:10px;border-radius:4px;border:1px solid #8ab0d8;}
.warn{background:#fff8e0;border:1px solid #e0c040;border-radius:4px;padding:10px;margin:10px 0;font-size:12px;color:#6a5000;}
.section{background:rgba(200,220,240,0.3);border-radius:4px;padding:10px 14px;margin-top:16px;}
.section h3{margin:0 0 6px 0;font-size:13px;color:#1a3a6a;}
</style>
</head>
<body>
<div class="box">
<h1>Zamknięty mini v1.0</h1>

<?php if ($done && $done_mode === 'update'): ?>
<p class="ok-update"><b>✅ Aktualizacja zakończona pomyślnie!</b></p>
<p>Baza danych została zaktualizowana — wszystkie wpisy, kategorie i konfiguracja zostały zachowane.</p>
<p><b>Teraz usuń plik <code>zamkniety_inc/zamkniety_install.php</code></b> aby skrypt działał normalnie.</p>
<p><a href="../index.php">Przejdź do katalogu</a> | <a href="../zamkniety_admin/">Panel admina</a></p>

<?php elseif ($done && $done_mode === 'install'): ?>
<p class="ok-install"><b>✅ Instalacja zakończona pomyślnie!</b></p>
<p>Plik <code>config.php</code> został zapisany. Baza danych została utworzona od nowa.</p>
<p><b>Teraz usuń plik <code>zamkniety_inc/zamkniety_install.php</code></b> aby uruchomić skrypt.</p>
<p><a href="../index.php">Przejdź do katalogu</a> | <a href="../zamkniety_admin/">Panel admina</a></p>

<?php else: ?>
<?php if ($stop): ?><p class="err">⚠️ <?= htmlspecialchars($stop, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>

<form method="post" action="zamkniety_install.php">
<input type="hidden" name="csrf_dummy" value="1" />

<div class="section">
<h3>🔌 Dane połączenia z bazą danych</h3>
<label>Host bazy danych:</label>
<input type="text" name="dbhost" value="<?= htmlspecialchars($_POST['dbhost'] ?? 'localhost', ENT_QUOTES, 'UTF-8') ?>" />
<label>Użytkownik bazy:</label>
<input type="text" name="dbuser" value="<?= htmlspecialchars($_POST['dbuser'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />
<label>Hasło bazy:</label>
<input type="password" name="dbpss" />
<label>Nazwa bazy:</label>
<input type="text" name="dbname" value="<?= htmlspecialchars($_POST['dbname'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />
<label>Prefiks tabel (np. <code>zm_</code>):</label>
<input type="text" name="prefix" value="<?= htmlspecialchars($_POST['prefix'] ?? 'zm_', ENT_QUOTES, 'UTF-8') ?>" />
<label>Ścieżka na dysku (bez slash na końcu, np. <code>/home/user/public_html</code>):</label>
<input type="text" name="dir" value="<?= htmlspecialchars($_POST['dir'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />
</div>

<div class="section">
<h3>👤 Administrator (tylko przy świeżej instalacji)</h3>
<label>Login administratora:</label>
<input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? 'admin', ENT_QUOTES, 'UTF-8') ?>" />
<label>Hasło administratora:</label>
<input type="password" name="pass" />
</div>

<div class="btn-row">
    <button type="submit" name="option" value="update" class="btn-update">
        🔄 AKTUALIZUJ (zachowaj dane)
    </button>
    <button type="submit" name="option" value="install" class="btn-install">
        🗑️ ZAINSTALUJ OD NOWA (usuń dane!)
    </button>
</div>

<div class="warn">
⚠️ <b>AKTUALIZUJ</b> — dodaje brakujące tabele i naprawia strukturę bazy. Wszystkie wpisy, kategorie i ustawienia zostają zachowane.<br><br>
🗑️ <b>ZAINSTALUJ OD NOWA</b> — usuwa wszystkie tabele i dane bezpowrotnie! Używaj tylko przy pierwszej instalacji lub gdy chcesz zacząć od zera.
</div>

</form>
<?php endif; ?>
</div>
</body>
</html>
