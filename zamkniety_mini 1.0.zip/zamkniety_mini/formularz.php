<?php
// Zamknięty mini - formularz.php (formularz wyszukiwarki - wersja w katalogu głównym)
// Używany przez mini_magic z blok_wyszukiwarka
global $cfg;
?>
<form name="search" action="index.php" method="get">
<input type="hidden" name="a" value="search" />
<input type="text" name="szukaj" class="search" placeholder="Szukaj..." />
<input type="submit" value="Szukaj" class="button" />
</form>
