<?php
// Zamknięty mini v1.0 - display.php (panel admina - edytor szablonu)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        $csrf = $_SESSION['admin_csrf'];

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('Nieprawidłowy CSRF.');
            foreach ($_POST as $key => $val) {
                if ($key === 'csrf_token') continue;
                $key_s = preg_replace('/[^a-zA-Z0-9_]/', '', $key);
                $pdo->prepare("UPDATE {$prefix}template SET wartosc=:v WHERE nazwa=:n")->execute([':v' => $val, ':n' => $key_s]);
            }
            header("Location: display.php?saved=1"); exit;
        }

        admin_site_header();
        echo '<div class="admin-section-title">' . t('appearance_title') . '</div>';
        if (($_GET['saved'] ?? '') === '1') echo '<div style="color:green;">✅ ' . t('saved') . '</div>';
        echo '<div style="background:rgba(220,235,250,0.5);border:1px solid var(--border);border-radius:6px;padding:10px 14px;margin-bottom:14px;font-size:12px;color:#3a6a9a;">';
        echo '💡 ' . t('appearance_hint');
        echo '</div>';
        echo '<form method="post" action="display.php">';
        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '" />';

        $rows = $pdo->query("SELECT * FROM {$prefix}template ORDER BY nazwa");
        while ($row = $rows->fetch()) {
            $n = htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8');
            $v = htmlspecialchars($row['wartosc'], ENT_QUOTES, 'UTF-8');
            echo '<p><b>' . $n . ':</b><br /><textarea name="' . $n . '" rows="4" cols="70">' . $v . '</textarea></p>';
        }
        echo '<button type="submit" class="btn">' . t('save') . '</button>';
        echo '</form>';
        admin_site_footer();
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
