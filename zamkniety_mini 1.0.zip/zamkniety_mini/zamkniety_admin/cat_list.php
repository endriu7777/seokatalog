<?php
// Zamknięty mini v1.0 - cat_list.php (panel admina - wybór kategorii dla wpisu)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        $wpi_id = (int)($_GET['id_wpi'] ?? 0);
        $a      = $_GET['a'] ?? '';

        admin_site_header();

        switch ($a) {
            case 'show':
                $kat_id = (int)($_GET['id'] ?? 0);
                echo '<div class="admin-section-title">Wybierz podkategorię</div>';
                $pods = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id_kat=:k ORDER BY nazwa");
                $pods->execute([':k' => $kat_id]);
                echo '<ul>';
                while ($pod = $pods->fetch()) {
                    $name  = htmlspecialchars($pod['nazwa'], ENT_QUOTES, 'UTF-8');
                    $color = $pod['akt'] ? '' : ' style="color:red;"';
                    echo '<li' . $color . '><a href="index.php?a=wpi&id=' . $wpi_id . '&assign_pod=' . (int)$pod['id'] . '&assign_kat=' . $kat_id . '">' . $name . '</a></li>';
                }
                echo '</ul>';
                break;

            default:
                echo '<div class="admin-section-title">Wybierz kategorię</div>';
                $kats = $pdo->query("SELECT * FROM {$prefix}kategorie ORDER BY nazwa");
                echo '<ul>';
                while ($kat = $kats->fetch()) {
                    $name  = htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8');
                    $color = $kat['akt'] ? '' : ' style="color:red;"';
                    echo '<li' . $color . '><a href="cat_list.php?a=show&id=' . (int)$kat['id'] . '&id_wpi=' . $wpi_id . '">' . $name . '</a></li>';
                }
                echo '</ul>';
        }

        admin_site_footer();
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
