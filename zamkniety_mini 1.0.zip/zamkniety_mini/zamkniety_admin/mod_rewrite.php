<?php
// Zamknięty mini v1.0 - mod_rewrite.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!administrator()) { header("Location: index.php"); exit; }

        admin_site_header();
        echo '<div class="admin-section-title">Przyjazne linki (mod_rewrite)</div>';

        if ($cfg['m1'] == 1 || $cfg['m1'] == 3) {
            $sep = $cfg['m2'] ?? '-';
            $kat = $cfg['m3'] ?? 'kat';
            $pod = $cfg['m4'] ?? 'pod';
            $szc = $cfg['m5'] ?? 'szcz';
            $inf = $cfg['m6'] ?? 'inf';

            echo '<p style="color:green;">Przyjazne linki są aktywne. Tryb: ' . (int)$cfg['m1'] . '</p>';
            echo '<p>Wklej poniższą zawartość do pliku <b>.htaccess</b> w katalogu głównym:</p>';
            echo '<textarea rows="12" cols="70" style="font-family:monospace;font-size:12px;">';
            echo "RewriteEngine On\n";
            echo "RewriteRule ^([^\\-]+){$sep}k([0-9]+)\\.html$ index.php?a=kat&id=\$2 [L,QSA]\n";
            echo "RewriteRule ^([^\\-]+){$sep}p([0-9]+)(-([0-9]+))*\\.html$ index.php?a=pod&id=\$2&min=\$4 [L,QSA]\n";
            echo "RewriteRule ^([^\\-]+){$sep}s([0-9]+)\\.html$ index.php?a=szcz&id=\$2 [L,QSA]\n";
            echo "RewriteRule ^search{$sep}(.+){$sep}([0-9]+)\\.html$ index.php?a=search&szukaj=\$1&min=\$2 [L,QSA]\n";
            echo "RewriteRule ^{$inf}\\.html$ index.php?a=inf [L]\n";
            echo "RewriteRule ^rss\\.xml$ index.php?a=rss [L]\n";
            echo "RewriteRule ^mapa\\.html$ index.php?a=mapa [L]\n";
            echo '</textarea>';
        } else {
            echo '<p style="color:#888;">Przyjazne linki są wyłączone (m1=0). Zmień ustawienie w konfiguracji.</p>';
        }

        admin_site_footer();
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
