<?php
// Zamknięty mini v1.0 - int_tools.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        $csrf = $_SESSION['admin_csrf'];

        $a = $_GET['a'] ?? '';

        switch ($a) {
            case 'update_ilosci':
                // Recalculate all counters
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=0 WHERE nazwa='wpi_n'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=1) WHERE nazwa='wpi_a'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=0) WHERE nazwa='wpi_n'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}kategorie WHERE akt=1) WHERE nazwa='kat_a'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}kategorie WHERE akt=0) WHERE nazwa='kat_n'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}podkategorie WHERE akt=1) WHERE nazwa='pod_a'")->execute();
                $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}podkategorie WHERE akt=0) WHERE nazwa='pod_n'")->execute();
                header("Location: index.php?err=0"); exit;

            case 'clear_sessions':
                if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) { header("Location: index.php"); exit; }
                $pdo->query("TRUNCATE TABLE {$prefix}sesje");
                header("Location: index.php?err=0"); exit;

            default:
                admin_site_header();
                echo '<div class="admin-section-title">Narzędzia techniczne</div>';
                echo '<table class="admin-table">';
                echo '<tr><td><b>Przelicz liczniki</b><br />Synchronizuje tabele ilosci z rzeczywistymi danymi z bazy.</td>';
                echo '<td><a href="int_tools.php?a=update_ilosci" class="btn">Przelicz</a></td></tr>';
                echo '<tr><td><b>Wyczyść sesje</b><br />Usuwa wszystkie wpisy z tabeli sesji.</td>';
                echo '<td><form method="post" action="int_tools.php?a=clear_sessions" style="display:inline;">';
                echo '<input type="hidden" name="csrf_token" value="' . $csrf . '" />';
                echo '<button type="submit" class="btn btn-danger" onclick="return confirm(\'Na pewno wyczyścić sesje?\')">Wyczyść</button></form></td></tr>';
                echo '</table>';
                admin_site_footer();
        }
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
