<?php
// ============================================================
// Zamknięty mini v1.0 - zabezpieczenia.php
// Zakładka: Zabezpieczenia (SSL, HTTP Auth, Google reCAPTCHA)
// ============================================================

if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {

        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }

        if (!administrator()) { header("Location: index.php"); exit; }

        if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        $csrf = $_SESSION['admin_csrf'];

        // ---- Paths -----------------------------------------
        $htaccess_main  = realpath(__DIR__ . '/..') . '/.htaccess';
        $htaccess_admin = __DIR__ . '/.htaccess';
        $htpasswd_file  = __DIR__ . '/.htpasswd';
        $security_cfg   = __DIR__ . '/../zamkniety_inc/security.json';

        // ---- Load security config ---------------------------
        $sec = [];
        if (file_exists($security_cfg)) {
            $sec = json_decode(file_get_contents($security_cfg), true) ?: [];
        }
        // Defaults
        $sec = array_merge([
            'ssl'               => false,
            'htauth'            => false,
            'captcha_enabled'   => false,
            'captcha_mode'      => 'v2',
            'captcha_site_key'  => '',
            'captcha_secret'    => '',
            'captcha_v3_score'  => '0.5',
            'captcha_forms'     => ['add_link' => true, 'add_cat' => false],
            'captcha_msg_label' => 'Weryfikacja CAPTCHA',
            'captcha_msg_error' => 'Weryfikacja CAPTCHA nie powiodła się. Spróbuj ponownie.',
            'captcha_msg_expire'=> 'Sesja CAPTCHA wygasła. Odśwież stronę.',
        ], $sec);

        // ---- Helper: save security config -------------------
        function save_sec(array $sec, string $path): bool
        {
            return file_put_contents($path, json_encode($sec, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
        }

        // ---- Helper: read main .htaccess --------------------
        function read_htaccess(string $path): string
        {
            return file_exists($path) ? file_get_contents($path) : '';
        }

        // ---- Helper: write SSL block to main .htaccess ------
        function apply_ssl(string $path, bool $enable): string
        {
            $content = read_htaccess($path);
            // Remove existing SSL block
            $content = preg_replace(
                '/# BEGIN ZamknietySSSL.*?# END ZamknietySSSL\n?/s',
                '',
                $content
            );
            $content = ltrim($content);

            if ($enable) {
                $block = "# BEGIN ZamknietySSSL\n"
                    . "<IfModule mod_rewrite.c>\n"
                    . "  RewriteEngine On\n"
                    . "  RewriteCond %{HTTPS} off\n"
                    . "  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]\n"
                    . "</IfModule>\n"
                    . "# END ZamknietySSSL\n\n";
                $content = $block . $content;
            }

            return $content;
        }

        // ---- Helper: apply HTTP Auth to admin .htaccess -----
        function apply_htauth(string $htaccess, string $htpasswd, bool $enable, string $user = '', string $pass = ''): array
        {
            $msgs = [];
            if ($enable) {
                // Generate .htpasswd entry (apr1 md5 compatible)
                $hashed = htpasswd_apr1($pass);
                $htpasswd_content = $user . ':' . $hashed . "\n";
                if (file_put_contents($htpasswd, $htpasswd_content) === false) {
                    $msgs[] = 'ERROR: Could not write .htpasswd';
                }

                $htaccess_content = "AuthType Basic\n"
                    . "AuthName \"Admin Area\"\n"
                    . "AuthUserFile " . $htpasswd . "\n"
                    . "Require valid-user\n";
                if (file_put_contents($htaccess, $htaccess_content) === false) {
                    $msgs[] = 'ERROR: Could not write admin .htaccess';
                }
            } else {
                // Remove .htaccess auth
                if (file_exists($htaccess)) {
                    $existing = file_get_contents($htaccess);
                    $cleaned  = preg_replace(
                        '/AuthType Basic.*?Require valid-user\n?/s',
                        '',
                        $existing
                    );
                    file_put_contents($htaccess, trim($cleaned));
                }
                if (file_exists($htpasswd)) {
                    unlink($htpasswd);
                }
            }
            return $msgs;
        }

        // APR1-MD5 password hash (compatible with Apache htpasswd)
        function htpasswd_apr1(string $password): string
        {
            $salt = substr(str_replace('+', '.', base64_encode(random_bytes(6))), 0, 8);
            $pass = '$apr1$' . $salt . '$';
            $len  = strlen($password);
            $ctx  = $password . '$apr1$' . $salt;
            $ctx1 = $password . $salt . $password;
            $final = md5($ctx1, true);

            for ($i = $len; $i > 0; $i -= 16) {
                $ctx .= substr($final, 0, min(16, $i));
            }
            for ($i = $len; $i > 0; $i >>= 1) {
                $ctx .= ($i & 1) ? chr(0) : $password[0];
            }
            $final = md5($ctx, true);
            for ($i = 0; $i < 1000; $i++) {
                $ctx1 = '';
                $ctx1 .= ($i & 1) ? $password : $final;
                if ($i % 3) $ctx1 .= $salt;
                if ($i % 7) $ctx1 .= $password;
                $ctx1 .= ($i & 1) ? $final : $password;
                $final = md5($ctx1, true);
            }
            $out = '';
            $itoa64 = './0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
            $to64 = function(int $v, int $n) use ($itoa64): string {
                $r = '';
                while ($n-- > 0) { $r .= $itoa64[$v & 0x3f]; $v >>= 6; }
                return $r;
            };
            $out .= $to64(ord($final[0]) << 16 | ord($final[6])  << 8 | ord($final[12]), 4);
            $out .= $to64(ord($final[1]) << 16 | ord($final[7])  << 8 | ord($final[13]), 4);
            $out .= $to64(ord($final[2]) << 16 | ord($final[8])  << 8 | ord($final[14]), 4);
            $out .= $to64(ord($final[3]) << 16 | ord($final[9])  << 8 | ord($final[15]), 4);
            $out .= $to64(ord($final[4]) << 16 | ord($final[10]) << 8 | ord($final[5]),  4);
            $out .= $to64(ord($final[11]), 2);
            return $pass . $out;
        }

        // ============================================================
        // POST — process actions
        // ============================================================
        $flash = '';
        $flash_type = 'ok';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) {
                die(t('err_csrf'));
            }

            $action = $_POST['action'] ?? '';

            // ---- SSL -------------------------------------------
            if ($action === 'save_ssl') {
                $ssl_on = ($_POST['ssl'] ?? '') === '1';
                $new_htaccess = apply_ssl($htaccess_main, $ssl_on);
                if (file_put_contents($htaccess_main, $new_htaccess) !== false) {
                    $sec['ssl'] = $ssl_on;
                    save_sec($sec, $security_cfg);
                    $flash = t('ssl_saved');
                } else {
                    $flash = 'Błąd: Nie można zapisać .htaccess (sprawdź uprawnienia do ' . htmlspecialchars($htaccess_main, ENT_QUOTES, 'UTF-8') . ')';
                    $flash_type = 'err';
                }
            }

            // ---- HTTP Auth --------------------------------------
            elseif ($action === 'save_htauth') {
                $enable = ($_POST['htauth'] ?? '') === '1';
                if ($enable) {
                    $user = trim($_POST['htauth_user'] ?? '');
                    $pass = $_POST['htauth_pass'] ?? '';
                    if ($user === '') { $flash = t('htauth_user_req'); $flash_type = 'err'; }
                    elseif ($pass === '') { $flash = t('htauth_pass_req'); $flash_type = 'err'; }
                    else {
                        $errs = apply_htauth($htaccess_admin, $htpasswd_file, true, $user, $pass);
                        if (empty($errs)) {
                            $sec['htauth'] = true;
                            save_sec($sec, $security_cfg);
                            $flash = t('htauth_saved');
                        } else {
                            $flash = implode('<br>', $errs);
                            $flash_type = 'err';
                        }
                    }
                } else {
                    apply_htauth($htaccess_admin, $htpasswd_file, false);
                    $sec['htauth'] = false;
                    save_sec($sec, $security_cfg);
                    $flash = t('htauth_disabled');
                }
            }

            // ---- Google reCAPTCHA -------------------------------
            elseif ($action === 'save_captcha') {
                $cap_on  = ($_POST['captcha_enabled'] ?? '') === '1';
                $cap_mode = in_array($_POST['captcha_mode'] ?? '', ['v2','v2_invisible','v3'], true)
                            ? $_POST['captcha_mode'] : 'v2';
                $site_key = trim($_POST['captcha_site_key'] ?? '');
                $secret   = trim($_POST['captcha_secret'] ?? '');
                $score    = max(0.0, min(1.0, (float)($_POST['captcha_v3_score'] ?? 0.5)));

                if ($cap_on && $site_key === '') { $flash = t('captcha_site_req'); $flash_type = 'err'; }
                elseif ($cap_on && $secret === '') { $flash = t('captcha_secret_req'); $flash_type = 'err'; }
                else {
                    $sec['captcha_enabled']    = $cap_on;
                    $sec['captcha_mode']       = $cap_mode;
                    $sec['captcha_site_key']   = $site_key;
                    $sec['captcha_secret']     = $secret;
                    $sec['captcha_v3_score']   = number_format($score, 1);
                    $sec['captcha_forms'] = [
                        'add_link' => isset($_POST['captcha_form_add_link']),
                        'add_cat'  => isset($_POST['captcha_form_add_cat']),
                    ];
                    $sec['captcha_msg_label']  = htmlspecialchars(trim($_POST['captcha_msg_label']  ?? ''), ENT_QUOTES, 'UTF-8');
                    $sec['captcha_msg_error']  = htmlspecialchars(trim($_POST['captcha_msg_error']  ?? ''), ENT_QUOTES, 'UTF-8');
                    $sec['captcha_msg_expire'] = htmlspecialchars(trim($_POST['captcha_msg_expire'] ?? ''), ENT_QUOTES, 'UTF-8');
                    save_sec($sec, $security_cfg);
                    $flash = t('captcha_saved');
                }
            }
        }

        // ============================================================
        // RENDER
        // ============================================================
        admin_site_header();
        ?>

<div class="admin-section-title"><?= t('security_title') ?></div>

<?php if ($flash): ?>
<div class="admin-flash admin-flash--<?= $flash_type ?>"><?= $flash ?></div>
<?php endif; ?>

<!-- Tab navigation -->
<div class="sec-tabs">
    <a href="#sec-ssl"     class="sec-tab" onclick="showTab('ssl');return false;">
        <span class="sec-tab-icon">🔒</span> SSL
    </a>
    <a href="#sec-htauth"  class="sec-tab" onclick="showTab('htauth');return false;">
        <span class="sec-tab-icon">🔑</span> HTTP Auth
    </a>
    <a href="#sec-captcha" class="sec-tab" onclick="showTab('captcha');return false;">
        <span class="sec-tab-icon">🤖</span> reCAPTCHA
    </a>
</div>

<style>
.admin-flash { padding:10px 14px; border-radius:4px; margin-bottom:14px; font-weight:bold; }
.admin-flash--ok  { background:rgba(40,160,80,0.15); border:1px solid rgba(40,160,80,0.4); color:#1a6a30; }
.admin-flash--err { background:rgba(200,40,40,0.12); border:1px solid rgba(200,40,40,0.4); color:#8a1a1a; }
.sec-tabs { display:flex; gap:6px; margin-bottom:16px; border-bottom:2px solid var(--blue-light,#a8ccee); padding-bottom:6px; flex-wrap:wrap; }
.sec-tab { display:flex; align-items:center; gap:6px; padding:7px 16px; border-radius:4px 4px 0 0;
    border:1px solid var(--border,rgba(60,130,200,0.35)); border-bottom:none;
    background:rgba(200,225,250,0.5); color:var(--blue-dark,#1a4a80); font-weight:bold;
    text-decoration:none; font-size:13px; cursor:pointer; transition:background .15s; }
.sec-tab:hover, .sec-tab.active { background:rgba(255,255,255,0.85); color:var(--blue-dark,#1a4a80); }
.sec-panel { display:none; }
.sec-panel.active { display:block; }
.sec-box { background:rgba(255,255,255,0.7); border:1px solid var(--border,rgba(60,130,200,0.3));
    border-radius:6px; padding:18px 20px; margin-bottom:16px; }
.sec-box h3 { margin:0 0 8px 0; font-size:15px; color:var(--blue-dark,#1a4a80); }
.sec-desc { font-size:12px; color:#5a7a9a; margin-bottom:14px; }
.sec-status { display:inline-flex; align-items:center; gap:8px; padding:6px 14px;
    border-radius:20px; font-size:12px; font-weight:bold; margin-bottom:12px; }
.sec-status.on  { background:rgba(30,150,80,0.15); color:#1a6a30; border:1px solid rgba(30,150,80,0.3); }
.sec-status.off { background:rgba(150,150,150,0.15); color:#5a5a5a; border:1px solid rgba(150,150,150,0.3); }
.sec-note { font-size:11px; color:#7a9aaa; background:rgba(200,225,250,0.4); border-left:3px solid var(--blue-light,#a8ccee);
    padding:6px 10px; border-radius:0 4px 4px 0; margin:10px 0; }
.sec-row { display:flex; align-items:center; gap:12px; margin:8px 0; flex-wrap:wrap; }
.sec-row label { min-width:220px; font-size:12px; font-weight:bold; color:#2a4a6a; }
.sec-row input[type=text], .sec-row input[type=password], .sec-row select, .sec-row input[type=number] {
    flex:1; min-width:200px; padding:5px 8px; border:1px solid var(--border,rgba(60,130,200,0.35));
    border-radius:3px; font-size:12px; background:rgba(255,255,255,0.85); }
.sec-row input[type=text]:focus, .sec-row input[type=password]:focus, .sec-row select:focus { 
    border-color:var(--blue-mid,#3a80c0); outline:none; }
.sec-row.checkbox-row { align-items:flex-start; gap:8px; }
.sec-row.checkbox-row label { min-width:auto; font-weight:normal; }
.sec-row.checkbox-row input[type=checkbox] { width:16px; height:16px; margin-top:1px; flex:none; }
.toggle-section { border:1px solid rgba(60,130,200,0.2); border-radius:4px; padding:10px 14px;
    background:rgba(240,248,255,0.5); margin:10px 0; }
.toggle-section h4 { margin:0 0 10px 0; font-size:13px; color:#2a5a80; }
.sec-hint { font-size:11px; color:#7a9aaa; margin-top:2px; }
.sec-link { font-size:12px; color:var(--blue-mid,#3a80c0); }
</style>

<script>
function showTab(name) {
    document.querySelectorAll('.sec-panel').forEach(function(el){ el.classList.remove('active'); });
    document.querySelectorAll('.sec-tab').forEach(function(el){ el.classList.remove('active'); });
    var panel = document.getElementById('sec-' + name);
    if (panel) panel.classList.add('active');
    var tab = document.querySelector('[onclick="showTab(\'' + name + '\');return false;"]');
    if (tab) tab.classList.add('active');
    localStorage.setItem('zm_sec_tab', name);
}
document.addEventListener('DOMContentLoaded', function(){
    var saved = localStorage.getItem('zm_sec_tab') || 'ssl';
    showTab(saved);
});

function toggleCaptchaOptions() {
    var on = document.getElementById('cap_on').checked;
    document.getElementById('captcha_options').style.display = on ? 'block' : 'none';
}
function toggleCaptchaMode() {
    var mode = document.getElementById('captcha_mode').value;
    document.getElementById('v3_options').style.display = mode === 'v3' ? 'block' : 'none';
}
function toggleHtAuth() {
    var on = document.getElementById('htauth_on').checked;
    document.getElementById('htauth_credentials').style.display = on ? 'block' : 'none';
}
</script>

<?php
// ============================================================
// TAB 1: SSL
// ============================================================
$ssl_active = (bool)($sec['ssl'] ?? false);
?>
<div id="sec-ssl" class="sec-panel">
<div class="sec-box">
    <h3><?= t('ssl_section') ?></h3>
    <p class="sec-desc"><?= t('ssl_desc') ?></p>

    <div class="sec-status <?= $ssl_active ? 'on' : 'off' ?>">
        <?= $ssl_active ? '✅ ' . t('ssl_on') : '⬜ ' . t('ssl_off') ?>
    </div>

    <div class="sec-note"><?= t('ssl_note') ?></div>

    <form method="post" action="zabezpieczenia.php">
    <input type="hidden" name="action" value="save_ssl" />
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />

    <div class="toggle-section">
        <h4><?= t('ssl_status') ?></h4>
        <div class="sec-row checkbox-row">
            <input type="radio" name="ssl" id="ssl_on"  value="1" <?= $ssl_active ? 'checked' : '' ?> />
            <label for="ssl_on">🔒 <?= t('ssl_enable') ?></label>
        </div>
        <div class="sec-row checkbox-row">
            <input type="radio" name="ssl" id="ssl_off" value="0" <?= !$ssl_active ? 'checked' : '' ?> />
            <label for="ssl_off">🔓 <?= t('ssl_disable') ?></label>
        </div>
    </div>

    <br />
    <button type="submit" class="btn">💾 <?= t('ssl_save') ?></button>
    </form>
</div>
</div>

<?php
// ============================================================
// TAB 2: HTTP AUTH
// ============================================================
$htauth_active = (bool)($sec['htauth'] ?? false);
$htauth_exists = file_exists($htpasswd_file);
?>
<div id="sec-htauth" class="sec-panel">
<div class="sec-box">
    <h3><?= t('htauth_section') ?></h3>
    <p class="sec-desc"><?= t('htauth_desc') ?></p>

    <div class="sec-status <?= $htauth_active ? 'on' : 'off' ?>">
        <?= $htauth_active ? '✅ ' . t('htauth_on') : '⬜ ' . t('htauth_off') ?>
    </div>

    <div class="sec-note"><?= t('htauth_note') ?></div>

    <form method="post" action="zabezpieczenia.php">
    <input type="hidden" name="action" value="save_htauth" />
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />

    <div class="toggle-section">
        <h4><?= t('htauth_status') ?></h4>
        <div class="sec-row checkbox-row">
            <input type="radio" name="htauth" id="htauth_on"  value="1"
                   <?= $htauth_active ? 'checked' : '' ?>
                   onchange="toggleHtAuth()" />
            <label for="htauth_on">🔑 <?= t('htauth_enable_btn') ?></label>
        </div>
        <div class="sec-row checkbox-row">
            <input type="radio" name="htauth" id="htauth_off" value="0"
                   <?= !$htauth_active ? 'checked' : '' ?>
                   onchange="toggleHtAuth()" />
            <label for="htauth_off">🔓 <?= t('htauth_disable_btn') ?></label>
        </div>
    </div>

    <div id="htauth_credentials" style="display:<?= $htauth_active ? 'block' : 'none' ?>;">
        <br />
        <div class="sec-row">
            <label for="htauth_user">👤 <?= t('htauth_username') ?></label>
            <input type="text" id="htauth_user" name="htauth_user" value=""
                   placeholder="<?= t('htauth_username') ?>" autocomplete="off" />
        </div>
        <div class="sec-row">
            <label for="htauth_pass">🔐 <?= t('htauth_password') ?></label>
            <input type="password" id="htauth_pass" name="htauth_pass" value=""
                   placeholder="<?= t('htauth_password') ?>" autocomplete="new-password" />
        </div>
        <p class="sec-hint">
            <?php if ($htauth_exists): ?>
                ✅ Plik .htpasswd istnieje. Wprowadź nowe dane tylko jeśli chcesz zmienić hasło.
            <?php else: ?>
                ℹ️ Podaj dane dla nowego konta HTTP Auth.
            <?php endif; ?>
        </p>
    </div>

    <br />
    <button type="submit" class="btn">💾 <?= t('save') ?></button>
    </form>
</div>
</div>

<?php
// ============================================================
// TAB 3: GOOGLE reCAPTCHA
// ============================================================
$cap_on    = (bool)($sec['captcha_enabled'] ?? false);
$cap_mode  = $sec['captcha_mode'] ?? 'v2';
$cap_site  = htmlspecialchars($sec['captcha_site_key'] ?? '', ENT_QUOTES, 'UTF-8');
$cap_sec   = htmlspecialchars($sec['captcha_secret']   ?? '', ENT_QUOTES, 'UTF-8');
$cap_score = htmlspecialchars($sec['captcha_v3_score'] ?? '0.5', ENT_QUOTES, 'UTF-8');
$cap_forms = $sec['captcha_forms'] ?? [];
$cap_label = htmlspecialchars($sec['captcha_msg_label']  ?? 'Weryfikacja CAPTCHA', ENT_QUOTES, 'UTF-8');
$cap_error = htmlspecialchars($sec['captcha_msg_error']  ?? 'Weryfikacja nie powiodła się.', ENT_QUOTES, 'UTF-8');
$cap_expir = htmlspecialchars($sec['captcha_msg_expire'] ?? 'Sesja wygasła. Odśwież stronę.', ENT_QUOTES, 'UTF-8');
?>
<div id="sec-captcha" class="sec-panel">
<div class="sec-box">
    <h3><?= t('captcha_section') ?></h3>
    <p class="sec-desc"><?= t('captcha_desc') ?>
        &nbsp; <a href="<?= t('captcha_api_url') ?>" target="_blank" class="sec-link">
            🔗 <?= t('captcha_api_link') ?></a>
    </p>

    <div class="sec-status <?= $cap_on ? 'on' : 'off' ?>">
        <?= $cap_on ? '✅ ' . t('captcha_on') : '⬜ ' . t('captcha_off') ?>
    </div>

    <form method="post" action="zabezpieczenia.php">
    <input type="hidden" name="action" value="save_captcha" />
    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>" />

    <!-- ON/OFF -->
    <div class="toggle-section">
        <h4><?= t('captcha_status') ?></h4>
        <div class="sec-row checkbox-row">
            <input type="checkbox" id="cap_on" name="captcha_enabled" value="1"
                   <?= $cap_on ? 'checked' : '' ?> onchange="toggleCaptchaOptions()" />
            <label for="cap_on"><?= t('captcha_on') ?></label>
        </div>
    </div>

    <div id="captcha_options" style="display:<?= $cap_on ? 'block' : 'none' ?>;">

        <!-- API KEYS -->
        <div class="toggle-section">
            <h4>🔑 API Keys</h4>
            <div class="sec-row">
                <label for="cap_site"><?= t('captcha_site_key') ?></label>
                <input type="text" id="cap_site" name="captcha_site_key" value="<?= $cap_site ?>"
                       placeholder="6Lc..." autocomplete="off" />
            </div>
            <div class="sec-row">
                <label for="cap_secret"><?= t('captcha_secret_key') ?></label>
                <input type="password" id="cap_secret" name="captcha_secret" value="<?= $cap_sec ?>"
                       placeholder="6Lc..." autocomplete="new-password" />
            </div>
        </div>

        <!-- MODE -->
        <div class="toggle-section">
            <h4>⚙️ <?= t('captcha_mode') ?></h4>
            <div class="sec-row">
                <label for="captcha_mode"><?= t('captcha_mode') ?></label>
                <select id="captcha_mode" name="captcha_mode" onchange="toggleCaptchaMode()">
                    <option value="v2"          <?= $cap_mode === 'v2'          ? 'selected' : '' ?>><?= t('captcha_v2') ?></option>
                    <option value="v2_invisible" <?= $cap_mode === 'v2_invisible' ? 'selected' : '' ?>><?= t('captcha_v2_inv') ?></option>
                    <option value="v3"           <?= $cap_mode === 'v3'          ? 'selected' : '' ?>><?= t('captcha_v3') ?></option>
                </select>
            </div>

            <div id="v3_options" style="display:<?= $cap_mode === 'v3' ? 'block' : 'none' ?>;">
                <div class="sec-row">
                    <label for="cap_score"><?= t('captcha_v3_score') ?></label>
                    <input type="number" id="cap_score" name="captcha_v3_score"
                           value="<?= $cap_score ?>" min="0" max="1" step="0.1"
                           style="width:80px;flex:none;" />
                </div>
                <p class="sec-hint"><?= t('captcha_v3_score_note') ?></p>
            </div>
        </div>

        <!-- PROTECTED FORMS -->
        <div class="toggle-section">
            <h4>📋 <?= t('captcha_protect') ?></h4>
            <div class="sec-row checkbox-row">
                <input type="checkbox" id="cap_form_link" name="captcha_form_add_link" value="1"
                       <?= !empty($cap_forms['add_link']) ? 'checked' : '' ?> />
                <label for="cap_form_link"><?= t('captcha_protect_contact') ?></label>
            </div>
            <div class="sec-row checkbox-row">
                <input type="checkbox" id="cap_form_cat" name="captcha_form_add_cat" value="1"
                       <?= !empty($cap_forms['add_cat']) ? 'checked' : '' ?> />
                <label for="cap_form_cat"><?= t('captcha_protect_add') ?></label>
            </div>
        </div>

        <!-- MESSAGES -->
        <div class="toggle-section">
            <h4>💬 <?= t('captcha_msg_title') ?></h4>
            <div class="sec-row">
                <label for="cap_msg_label"><?= t('captcha_msg_verify') ?></label>
                <input type="text" id="cap_msg_label" name="captcha_msg_label" value="<?= $cap_label ?>" />
            </div>
            <div class="sec-row">
                <label for="cap_msg_error"><?= t('captcha_msg_error') ?></label>
                <input type="text" id="cap_msg_error" name="captcha_msg_error" value="<?= $cap_error ?>" />
            </div>
            <div class="sec-row">
                <label for="cap_msg_expir"><?= t('captcha_msg_expired') ?></label>
                <input type="text" id="cap_msg_expir" name="captcha_msg_expire" value="<?= $cap_expir ?>" />
            </div>
        </div>

    </div><!-- /captcha_options -->

    <br />
    <button type="submit" class="btn">💾 <?= t('save') ?></button>
    </form>
</div>
</div>

<?php
        admin_site_footer();

    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
