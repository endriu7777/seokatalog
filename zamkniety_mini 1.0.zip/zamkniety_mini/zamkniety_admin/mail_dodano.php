<?php
// Zamknięty mini v1.0 - mail_dodano.php
// Wysyła e-mail po zatwierdzeniu wpisu

$temat = $cfg['maild_tem'] ?? 'Wpis został zatwierdzony!';

$body_template = $cfg['maild_tre'] ?? 'Witaj, Twój wpis został dodany.';

// Replace placeholders
$body = str_replace('[MyBB[email]]', $wpis['mail'] ?? '', $body_template);
$body = str_replace('[MyBB[home]]',
    '<a href="' . htmlspecialchars($cfg['o4'] ?? '', ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($cfg['o4'] ?? '', ENT_QUOTES, 'UTF-8') . '</a>',
    $body
);
$wpis_id  = (int)($_GET['id'] ?? 0);
$wpis_url = htmlspecialchars(szcz_link($wpis_id, $wpis['tytul'] ?? '', $cfg), ENT_QUOTES, 'UTF-8');
$body = str_replace('[MyBB[id]]', '<a href="' . ($cfg['o4'] ?? '') . '/' . $wpis_url . '">' . ($cfg['o4'] ?? '') . '/' . $wpis_url . '</a>', $body);

$headers  = "From: " . ($cfg['mail_odkog'] ?? 'Admin') . " <" . ($cfg['mail_nadaw'] ?? '') . ">\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-type: text/html; charset=UTF-8\r\n";

$html_mail = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>' . htmlspecialchars($temat, ENT_QUOTES, 'UTF-8') . '</title></head><body>' . $body . '</body></html>';

if (!empty($wpis['mail']) && filter_var($wpis['mail'], FILTER_VALIDATE_EMAIL)) {
    mail($wpis['mail'], $temat, $html_mail, $headers);
}
