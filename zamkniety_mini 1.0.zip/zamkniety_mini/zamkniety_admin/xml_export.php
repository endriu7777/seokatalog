<?php
// Zamknięty mini v1.0 - xml_export.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        $a = $_GET['a'] ?? '';

        switch ($a) {
            case 'mapy_stron':
                // Google XML Sitemap export
                header('Content-Type: application/xml; charset=UTF-8');
                header('Content-Disposition: attachment; filename="sitemap.xml"');
                $base = htmlspecialchars($cfg['o4'] ?? 'http://' . ($_SERVER['HTTP_HOST'] ?? ''), ENT_XML1, 'UTF-8');
                echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
                echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

                // Homepage
                echo "<url><loc>{$base}/</loc><priority>1.0</priority></url>\n";

                // Categories
                $kats = $pdo->query("SELECT * FROM {$prefix}kategorie WHERE akt='1' ORDER BY nazwa");
                while ($kat = $kats->fetch()) {
                    $sep = str_contains($cfg['m3'], '/') ? '/' : $cfg['m2'];
                    $end = str_contains($cfg['m3'], '/') ? '/' : '.html';
                    $url = $base . '/' . $cfg['m3'] . $sep . (int)$kat['id'] . $end;
                    echo "<url><loc>" . htmlspecialchars($url, ENT_XML1, 'UTF-8') . "</loc><priority>0.8</priority></url>\n";

                    $pods = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id_kat=:k AND akt='1'");
                    $pods->execute([':k' => $kat['id']]);
                    while ($pod = $pods->fetch()) {
                        $sep2 = str_contains($cfg['m4'], '/') ? '/' : $cfg['m2'];
                        $end2 = str_contains($cfg['m4'], '/') ? '/' : '.html';
                        $url2 = $base . '/' . $cfg['m4'] . $sep2 . (int)$pod['id'] . $end2;
                        echo "<url><loc>" . htmlspecialchars($url2, ENT_XML1, 'UTF-8') . "</loc><priority>0.6</priority></url>\n";
                    }
                }

                // Entries
                $wpisy = $pdo->query("SELECT * FROM {$prefix}wpisy WHERE akt='1' ORDER BY data DESC LIMIT 0,1000");
                while ($wpi = $wpisy->fetch()) {
                    $sep3 = str_contains($cfg['m5'], '/') ? '/' : $cfg['m2'];
                    $end3 = str_contains($cfg['m5'], '/') ? '/' : '.html';
                    $url3 = $base . '/' . $cfg['m5'] . $sep3 . (int)$wpi['id'] . $end3;
                    $lastmod = date('Y-m-d', (int)$wpi['data']);
                    echo "<url><loc>" . htmlspecialchars($url3, ENT_XML1, 'UTF-8') . "</loc><lastmod>{$lastmod}</lastmod><priority>0.5</priority></url>\n";
                }

                echo '</urlset>' . "\n";
                exit;

            default:
                admin_site_header();
                echo '<div class="admin-section-title">XML Export</div>';
                echo '<p><a href="xml_export.php?a=mapy_stron" class="btn">Pobierz Google Sitemap XML</a></p>';
                admin_site_footer();
        }
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
