<?php
if (!function_exists('zm_send_mail')) { require_once __DIR__ . '/mail_send.php'; }
// ============================================================
// Zamknięty mini v1.0 - admin_functions.php
// PHP 8.4, PDO — funkcje zdefiniowane PRZED wywołaniem
// ============================================================
// PDO init i załadowanie cfg/ile/tpl następuje NA KOŃCU tego pliku

// ---- administrator() ----------------------------------------
function administrator(): bool
{
    global $login, $pass;
    $cookie_login = $_COOKIE['loginn'] ?? '';
    $cookie_pass  = $_COOKIE['passs']  ?? '';
    return ($login !== '' && $pass !== ''
        && hash_equals($login, $cookie_login)
        && hash_equals($pass,  $cookie_pass));
}

// ---- SEO URL + link helpers (kopie z funkcje.php, bez require funkcje.php w adminie) ---
if (!function_exists('zmiana_url')) {
function zmiana_url(string $text): string {
    global $cfg;
    $sep = $cfg['m2'] ?? '-';
    // Tekst jest już w UTF-8 — nie konwertuj z ISO
    $map = [
        'a'=>['à','á','â','ã','ä','å','ā','ą','a','A'],
        'b'=>['b','B'],'c'=>['ć','č','ç','c','C'],'d'=>['ď','đ','d','D'],
        'e'=>['è','é','ê','ë','ě','ę','e','E'],'f'=>['f','F'],'g'=>['ğ','g','G'],
        'h'=>['h','H'],'i'=>['ì','í','î','ï','ī','i','I'],'j'=>['j','J'],
        'k'=>['k','K'],'l'=>['ł','ĺ','l','L'],'m'=>['m','M'],
        'n'=>['ń','ñ','n','N'],'o'=>['ò','ó','ô','õ','ö','ø','ő','o','O'],
        'p'=>['p','P'],'q'=>['q','Q'],'r'=>['ř','ŕ','r','R'],
        's'=>['ś','š','ş','s','S'],'t'=>['ť','t','T'],
        'u'=>['ù','ú','û','ü','ů','ű','u','U'],'v'=>['v','V'],
        'w'=>['w','W'],'x'=>['x','X'],'y'=>['ÿ','y','Y'],
        'z'=>['ź','ż','ž','z','Z'],
    ];
    $out='';
    preg_match_all('~.~su',$text,$ch);
    foreach($ch[0] as $c){
        $f=false;
        foreach($map as $rep=>$src){if(in_array($c,$src,true)){$out.=$rep;$f=true;break;}}
        if(!$f){if(preg_match('~[0-9]~',$c))$out.=$c;elseif(in_array($c,[' ',',','.','_','-']))$out.=$sep;}
    }
    $out=preg_replace('~'.preg_quote($sep,'~').'+~',$sep,$out);
    return trim($out,$sep);
}
}
if (!function_exists('kat_link')) {
function kat_link(int $id, string $nazwa, array $cfg): string {
    $m=$cfg['m3']??'kat';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($nazwa).$s.'k'.$id.$e;
    return'index.php?a=kat&id='.$id;
}
}
if (!function_exists('pod_link')) {
function pod_link(int $id, string $nazwa, array $cfg): string {
    $m=$cfg['m4']??'pod';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($nazwa).$s.'p'.$id.$e;
    return'index.php?a=pod&id='.$id;
}
}
if (!function_exists('szcz_link')) {
function szcz_link(int $id, string $tytul, array $cfg): string {
    $m=$cfg['m5']??'szcz';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($tytul).$s.'s'.$id.$e;
    return'index.php?a=szcz&id='.$id;
}
}

// ---- admin_site_header() ------------------------------------
function admin_site_header(): void
{
    global $cfg, $pdo, $prefix;
    header("Content-Type: text/html; charset=UTF-8");

    // Load language system if not already loaded
    if (!function_exists('t')) {
        if (file_exists(__DIR__ . '/lang.php')) {
            include_once __DIR__ . '/lang.php';
        } else {
            // Fallback stub
            function t(string $k): string { return $k; }
        }
    }

    $f1   = htmlspecialchars($cfg['f1'] ?? 'index', ENT_QUOTES, 'UTF-8');
    $lang = function_exists('admin_get_lang') ? admin_get_lang() : 'pl';

    // Build current URL without set_lang param for switcher links
    $cur_url  = strtok($_SERVER['REQUEST_URI'] ?? 'index.php', '?');
    $cur_qs   = $_GET ?? [];
    unset($cur_qs['set_lang']);
    $qs_pl    = http_build_query(array_merge($cur_qs, ['set_lang' => 'pl']));
    $qs_en    = http_build_query(array_merge($cur_qs, ['set_lang' => 'en']));
    $url_pl   = $cur_url . '?' . $qs_pl;
    $url_en   = $cur_url . '?' . $qs_en;

    if (administrator()) {
        $header_info = '<a href="index.php">📊 ' . t('nav_dashboard') . '</a>'
            . ' | <a href="index.php?a=kategorie">📂 ' . t('categories') . '</a>'
            . ' | <a href="index.php?a=cfg">⚙️ ' . t('nav_config') . '</a>'
            . ' | <a href="index.php?a=cookie">🍪 ' . t('nav_cookie') . '</a>'
            . ' | <a href="display.php">🎨 ' . t('nav_appearance') . '</a>'
            . ' | <a href="lista_wpisow.php?tab=pending">🔗 ' . t('entries') . '</a>'
            . ' | <a href="index.php?a=xml_import">📥 ' . t('nav_xml_import') . '</a>'
            . ' | <a href="xml_export.php">📤 ' . t('nav_xml_export') . '</a>'
            . ' | <a href="sesje.php?a=online">👁️ ' . t('nav_sessions') . '</a>'
            . ' | <a href="blokowane.php?blok=adresy&a=lista">🚫 ' . t('nav_blocked') . '</a>'
            . ' | <a href="zabezpieczenia.php" style="color:#ffd070;">🔒 ' . t('nav_security') . '</a>'
            . ' | <a href="index.php?a=payments" style="color:#ffd070;">💳 ' . t('nav_payments') . '</a>'
            . ' | <a href="../' . $f1 . '.php">🏠</a>'
            . ' | <a href="index.php?a=logout">🚪 ' . t('logout') . '</a>';
    } else {
        $header_info = t('not_logged_in');
    }

    // Language switcher HTML
    $lang_switch = '<span style="font-size:11px;display:flex;align-items:center;gap:6px;">'
        . '<span style="opacity:.7;">' . t('language') . ':</span>'
        . '<a href="' . htmlspecialchars($url_pl, ENT_QUOTES, 'UTF-8') . '" '
        .   'style="' . ($lang === 'pl' ? 'font-weight:bold;color:#fff;' : 'color:#cce0ff;') . '">'
        .   '🇵🇱 PL</a>'
        . ' <a href="' . htmlspecialchars($url_en, ENT_QUOTES, 'UTF-8') . '" '
        .   'style="' . ($lang === 'en' ? 'font-weight:bold;color:#fff;' : 'color:#cce0ff;') . '">'
        .   '🇬🇧 EN</a>'
        . '</span>';
    ?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
<meta charset="UTF-8" />
<meta name="robots" content="noindex, nofollow" />
<title><?= t('panel_title') ?></title>
<style>
:root {
    --blue-dark:  #1a4a80;
    --blue-mid:   #3a80c0;
    --blue-light: #a8ccee;
    --sand:       #e8e0d0;
    --white-glass: rgba(255,255,255,0.75);
    --border:     rgba(60,130,200,0.35);
}
*, *::before, *::after { box-sizing: border-box; }
html, body {
    font-family: Arial, sans-serif;
    font-size: 13px;
    margin: 0;
    padding: 0;
    background: linear-gradient(160deg, #c8dff5 0%, #dce9f5 60%, #e8e0d0 100%);
    min-height: 100vh;
    color: #1a2a3a;
}
a { color: var(--blue-dark); }
a:hover { color: var(--blue-mid); }
.admin-header {
    background: linear-gradient(90deg, var(--blue-dark) 0%, var(--blue-mid) 100%);
    color: #fff;
    padding: 10px 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    border-bottom: 2px solid var(--blue-light);
}
.admin-header a { color: #cce0ff; font-size: 12px; }
.admin-header a:hover { color: #fff; }
.admin-logo { font-size: 16px; font-weight: bold; letter-spacing: 1px; }
.admin-wrap { display: flex; gap: 12px; padding: 12px; }
.admin-main { flex: 1; background: var(--white-glass); border: 1px solid var(--border); border-radius: 6px; padding: 14px; backdrop-filter: blur(4px); }
.admin-side { width: 200px; background: var(--white-glass); border: 1px solid var(--border); border-radius: 6px; padding: 10px; backdrop-filter: blur(4px); font-size: 12px; }
.admin-section-title { font-size: 16px; font-weight: bold; color: var(--blue-dark); border-bottom: 2px solid var(--blue-light); padding-bottom: 4px; margin-bottom: 10px; }
.admin-table { width: 100%; border-collapse: collapse; }
.admin-table th { background: var(--blue-dark); color: #fff; padding: 6px 8px; text-align: left; font-size: 12px; }
.admin-table td { padding: 5px 8px; border-bottom: 1px solid var(--border); font-size: 12px; }
.admin-table tr:hover td { background: rgba(168,204,238,0.3); }
.btn { display: inline-block; padding: 4px 12px; border-radius: 3px; border: 1px solid var(--blue-dark); background: linear-gradient(180deg, var(--blue-mid) 0%, var(--blue-dark) 100%); color: #fff; font-size: 11px; font-weight: bold; cursor: pointer; text-decoration: none; }
.btn:hover { background: linear-gradient(180deg, #5090d0 0%, var(--blue-mid) 100%); color: #fff; }
.btn-danger { border-color: #a02020; background: linear-gradient(180deg, #d04040 0%, #a02020 100%); }
input[type=text], input[type=password], textarea, select {
    border: 1px solid var(--border);
    background: rgba(255,255,255,0.85);
    border-radius: 3px;
    padding: 4px 6px;
    font-size: 12px;
    color: #1a2a3a;
}
input[type=text]:focus, input[type=password]:focus, textarea:focus { border-color: var(--blue-mid); outline: none; }
.inactive { color: #888; }
.small    { font-size: 11px; }
.big      { font-size: 20px; font-weight: bold; color: var(--blue-dark); }
ul { padding: 0; margin: 0 0 0 18px; }
li { margin: 2px 0; }
.oczekujace-title { font-size: 14px; font-weight: bold; color: var(--blue-dark); margin-bottom: 6px; }
</style>
<script type="text/javascript" src="javascript.js"></script>
</head>
<body>
<div class="admin-header">
  <span class="admin-logo">Zamknięty mini v1.0</span>
  <span style="display:flex;flex-direction:column;align-items:flex-end;gap:4px;">
    <span><?= $header_info ?></span>
    <?= $lang_switch ?>
  </span>
</div>
<div class="admin-wrap">
<div class="admin-main">
<?php
}

// ---- admin_site_footer() ------------------------------------
function admin_site_footer(): void
{
    ?>
</div><!-- /admin-main -->
<div class="admin-side">
<?php oczekujace(); ?>
</div>
</div><!-- /admin-wrap -->
<div style="text-align:center;padding:18px 0 10px 0;font-size:11px;color:#8aaabb;border-top:1px solid rgba(60,130,200,0.15);margin-top:20px;">
    Autor: <strong>Andrzej Kupis</strong><br />
    e-mail: <a href="mailto:endriu222@o2.pl" style="color:#7aabb0;">endriu222@o2.pl</a>
</div>
<div style="text-align:center;padding:8px 0 14px 0;font-size:11px;color:#8aaabb;">
    <strong><?php echo t('footer_ad_label'); ?></strong><br />
    <a href="<?php echo t('footer_ad_url'); ?>" target="_blank" rel="nofollow" style="color:#3a80c0;text-decoration:none;"><?php echo t('footer_ad_text'); ?></a>
</div>
</body>
</html>
<?php
}

// ---- oczekujace() -------------------------------------------
function oczekujace(): void
{
    global $pdo, $prefix, $ile;

    $n_wpi = $pdo->query("SELECT * FROM {$prefix}wpisy WHERE akt='0' ORDER BY data DESC LIMIT 0,10");
    $n_kat = $pdo->query("SELECT * FROM {$prefix}kategorie WHERE akt='0' ORDER BY data DESC LIMIT 0,3");
    $n_pod = $pdo->query("SELECT * FROM {$prefix}podkategorie WHERE akt='0' ORDER BY data DESC LIMIT 0,5");

    echo '<div class="oczekujace-title">' . t('pending_inactive') . ':</div>';
    echo '<b>' . t('entries') . '</b> (' . (int)($ile['wpi_n'] ?? 0) . ')<br />';
    echo '<ul>';
    while ($l = $n_wpi->fetch()) {
        echo '<li><a href="index.php?a=wpi&id=' . (int)$l['id'] . '">' . htmlspecialchars($l['tytul'], ENT_QUOTES, 'UTF-8') . '</a></li>';
    }
    echo '</ul>';

    echo '<b>' . t('categories') . '</b> (' . (int)($ile['kat_n'] ?? 0) . ')<br />';
    echo '<ul>';
    while ($l = $n_kat->fetch()) {
        echo '<li><a href="index.php?a=kategorie">' . htmlspecialchars($l['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></li>';
    }
    echo '</ul>';

    echo '<b>' . t('subcategories') . '</b> (' . (int)($ile['pod_n'] ?? 0) . ')<br />';
    echo '<ul>';
    while ($l = $n_pod->fetch()) {
        echo '<li><a href="index.php?a=kategorie">' . htmlspecialchars($l['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></li>';
    }
    echo '</ul>';

    echo '<br /><div class="oczekujace-title">' . t('catalog_size') . ':</div>';
    echo '<b>' . t('entries') . ':</b> ' . ((int)($ile['wpi_a'] ?? 0) + (int)($ile['wpi_n'] ?? 0)) . '<br />';
    echo '&nbsp;' . t('active_entries') . ': ' . (int)($ile['wpi_a'] ?? 0) . '<br />';
    echo '&nbsp;' . t('inactive_entries') . ': ' . (int)($ile['wpi_n'] ?? 0) . '<br />';
    echo '<b>' . t('categories') . ':</b> ' . ((int)($ile['kat_a'] ?? 0) + (int)($ile['kat_n'] ?? 0)) . '<br />';
    echo '<b>' . t('subcategories') . ':</b> ' . ((int)($ile['pod_a'] ?? 0) + (int)($ile['pod_n'] ?? 0)) . '<br />';
}

// ---- unhtmlspecialchars() -----------------------------------
function unhtmlspecialchars(string $string): string
{
    return html_entity_decode($string, ENT_QUOTES, 'UTF-8');
}

// ---- DB helpers ---------------------------------------------
function admin_cfg(PDO $pdo, string $prefix): array
{
    $cfg = [];
    foreach ($pdo->query("SELECT * FROM {$prefix}konfiguracja") as $l) {
        $cfg[$l['nazwa']] = $l['wartosc'];
    }
    return $cfg;
}

function admin_ile(PDO $pdo, string $prefix): array
{
    $ile = [];
    foreach ($pdo->query("SELECT * FROM {$prefix}ilosci") as $l) {
        $ile[$l['nazwa']] = $l['ilosc'];
    }
    return $ile;
}

function admin_tpl(PDO $pdo, string $prefix): array
{
    $tpl = [];
    foreach ($pdo->query("SELECT * FROM {$prefix}template") as $l) {
        $tpl[$l['nazwa']] = $l['wartosc'];
    }
    return $tpl;
}
// ============================================================
// INIT — PDO + załadowanie konfiguracji (NA KOŃCU PLIKU)
// ============================================================

try {
    $pdo = new PDO(
        "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4",
        $dbuser, $dbpss,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    die('<h2>Błąd połączenia z bazą danych.</h2><p>Sprawdź dane w zamkniety_inc/config.php</p>');
}

$ile = admin_ile($pdo, $prefix);
$cfg = admin_cfg($pdo, $prefix);
$tpl = admin_tpl($pdo, $prefix);
