<?php
// Zamknięty mini v1.0 - blokowane.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        // CSRF
        if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
        $csrf = $_SESSION['admin_csrf'];

        $blok_type = in_array($_GET['blok'] ?? '', ['adresy','frazy'], true) ? $_GET['blok'] : 'adresy';
        $act       = $_GET['a'] ?? 'lista';

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('Nieprawidłowy token CSRF.');
        }

        switch ($blok_type) {
            case 'adresy':
                switch ($act) {
                    case 'usun':
                        $pid = (int)($_GET['p'] ?? 0);
                        if ($pid > 0) $pdo->prepare("DELETE FROM {$prefix}blokowane WHERE id=:id")->execute([':id'=>$pid]);
                        header("Location: blokowane.php?blok=adresy&a=lista"); exit;

                    case 'zablokuj':
                        if (!empty($_POST['adres'])) {
                            $adres_b = str_replace(['http://','www.'], '', trim($_POST['adres']));
                            $adres_b = explode('/', $adres_b)[0];
                            $adres_b = preg_replace('/[^a-zA-Z0-9\.\-\*]/', '', $adres_b);
                            $exists  = $pdo->prepare("SELECT id FROM {$prefix}blokowane WHERE adres=:a");
                            $exists->execute([':a' => $adres_b]);
                            if (!$exists->fetch()) {
                                $pdo->prepare("INSERT INTO {$prefix}blokowane SET adres=:a")->execute([':a'=>$adres_b]);
                            }
                        }
                        header("Location: blokowane.php?blok=adresy&a=lista"); exit;

                    default: // lista
                        $po_ile = 30;
                        $min    = max(0, (int)($_GET['min'] ?? 0));
                        $all    = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}blokowane")->fetchColumn();
                        $zap    = $pdo->prepare("SELECT * FROM {$prefix}blokowane ORDER BY adres LIMIT :min, :po_ile");
                        $zap->bindValue(':min', $min, PDO::PARAM_INT);
                        $zap->bindValue(':po_ile', $po_ile, PDO::PARAM_INT);
                        $zap->execute();

                        admin_site_header();
                        echo '<div class="admin-section-title">' . t('blok_title_addr') . '</div>';
                        echo '<p><a href="blokowane.php?blok=adresy&a=lista">' . t('blok_addr') . '</a> | <a href="blokowane.php?blok=frazy&a=lista">' . t('blok_phrases') . '</a></p>';
                        echo '<form method="post" action="blokowane.php?blok=adresy&a=zablokuj">';
                        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '" />';
                        echo t('blok_addr_label') . ': <input type="text" name="adres" size="30" /> <button type="submit" class="btn">' . t('add') . '</button>';
                        echo '</form><br />';
                        echo '<table class="admin-table"><tr><th>' . t('blok_addr') . '</th><th>' . t('blok_scope') . '</th><th>' . t('col_actions') . '</th></tr>';
                        while ($row = $zap->fetch()) {
                            $adres_disp = htmlspecialchars($row['adres'], ENT_QUOTES, 'UTF-8');
                            $is_wild    = str_starts_with($row['adres'], '*.');
                            echo '<tr><td>' . $adres_disp . '</td>';
                            echo '<td>' . ($is_wild ? t('blok_scope_domain') : t('blok_scope_exact')) . '</td>';
                            echo '<td><a href="blokowane.php?blok=adresy&a=usun&p=' . (int)$row['id'] . '" onclick="return confirm(\'' . t('confirm_delete') . '\')">' . t('delete') . '</a></td></tr>';
                        }
                        echo '</table>';
                        admin_site_footer();
                }
                break;

            case 'frazy':
                switch ($act) {
                    case 'zablokuj':
                        $frazy = strip_tags($_POST['frazy'] ?? '');
                        $pdo->prepare("UPDATE {$prefix}filtr SET wartosc=:v WHERE nazwa='frazy'")->execute([':v' => $frazy]);
                        header("Location: blokowane.php?blok=frazy&a=lista"); exit;

                    default:
                        $row = $pdo->query("SELECT * FROM {$prefix}filtr WHERE nazwa='frazy'")->fetch();
                        admin_site_header();
                        echo '<div class="admin-section-title">' . t('blok_title_phrases') . '</div>';
                        echo '<p><a href="blokowane.php?blok=adresy&a=lista">' . t('blok_addr') . '</a> | <a href="blokowane.php?blok=frazy&a=lista">' . t('blok_phrases') . '</a></p>';
                        echo '<form method="post" action="blokowane.php?blok=frazy&a=zablokuj">';
                        echo '<input type="hidden" name="csrf_token" value="' . $csrf . '" />';
                        echo '<textarea name="frazy" rows="15" cols="60">' . htmlspecialchars($row['wartosc'] ?? '', ENT_QUOTES, 'UTF-8') . '</textarea><br />';
                        echo '<button type="submit" class="btn">' . t('save') . '</button>';
                        echo '</form>';
                        admin_site_footer();
                }
                break;
        }
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
