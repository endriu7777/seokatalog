<?php
// Zamknięty mini v1.0 - sesje.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }

        if (!administrator()) { header("Location: index.php"); exit; }

        switch ($_GET['a'] ?? '') {
            default:
                header("Location: index.php");
                exit;

            case 'online':
                $po_ile = 20;
                $min    = max(0, (int)($_GET['min'] ?? 0));
                $next   = $min + $po_ile;
                $prev   = $min - $po_ile;

                $all  = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}sesje")->fetchColumn();
                $zap  = $pdo->prepare("SELECT * FROM {$prefix}sesje ORDER BY czas DESC LIMIT :min, :po_ile");
                $zap->bindValue(':min', $min, PDO::PARAM_INT);
                $zap->bindValue(':po_ile', $po_ile, PDO::PARAM_INT);
                $zap->execute();

                $dod = '';
                if ($prev >= 0) $dod .= '<a href="sesje.php?a=online&min=' . $prev . '">&lt; prev</a> | ';
                if ($next >= $po_ile && $all > $next) $dod .= '<a href="sesje.php?a=online&min=' . $next . '">next &gt;</a>';
                $min_list  = $min + 1;
                $next_list = ($next >= $all) ? $all : $next;

                admin_site_header();
                echo '<div class="admin-section-title">' . t('sessions_title') . '</div>';
                echo '<p>' . t('show_range') . ': ' . $min_list . '-' . $next_list . ' ' . t('of') . ' <b>' . $all . '</b> | ' . $dod . '</p>';
                echo '<table class="admin-table"><tr>'
                    . '<th>' . t('col_ip_host') . '</th>'
                    . '<th>' . t('col_page') . '</th>'
                    . '<th>' . t('col_referer') . '</th>'
                    . '<th>' . t('col_time') . '</th></tr>';

                while ($wpis = $zap->fetch()) {
                    $ip   = htmlspecialchars(urldecode($wpis['ip']), ENT_QUOTES, 'UTF-8');
                    $host = htmlspecialchars(urldecode($wpis['host']), ENT_QUOTES, 'UTF-8');
                    $uri  = htmlspecialchars(urldecode($wpis['gdzie_jest']), ENT_QUOTES, 'UTF-8');
                    $ref  = htmlspecialchars(urldecode($wpis['sesref']), ENT_QUOTES, 'UTF-8');
                    $czas = date('d-m-Y H:i:s', (int)$wpis['czas']);
                    echo '<tr><td>' . $ip . '<br /><span class="small">' . $host . '</span></td>';
                    echo '<td><a href="' . $uri . '">' . $uri . '</a></td>';
                    echo '<td><span class="small">' . $ref . '</span></td>';
                    echo '<td>' . $czas . '</td></tr>';
                }
                echo '</table>';
                echo '<p>' . $dod . '</p>';
                admin_site_footer();
                break;
        }
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
