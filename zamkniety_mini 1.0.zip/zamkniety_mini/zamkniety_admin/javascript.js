

// ---------------------------------------------------------------------------- // 
// Skrypt otwarty.pl mini
// ---------------------------------------------------------------------------- // 




function pokaz(theTable) {
if (document.getElementById(theTable).style.display == 'none') {
   document.getElementById(theTable).style.display = 'block';
   } else {
   document.getElementById(theTable).style.display = 'none';
   }
}


function ustaw_podkat(id) {
  parent.document.relacje.id_pod.value = id;
}



function po(c,co) {
		 if (c.checked)
					document.getElementById(co).style.display="";
		 else
					document.getElementById(co).style.display="none";
}


function za(c,co) {
					document.getElementById(co).style.display="none";
}


function uk(c,co) {
		 if (c.checked)
					document.getElementById(co).style.display="none";
		 else
					document.getElementById(co).style.display="";
}

