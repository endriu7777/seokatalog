<?php
// Zamknięty mini v1.0 - xml_import.php
// Może być wywołany bezpośrednio LUB z index.php (case 'xml_import')
// Zabezpieczenie przed podwójnym include

if (!function_exists('administrator')) {
    // Wywołanie bezpośrednie - załaduj zależności
    if (!file_exists("../zamkniety_inc/config.php"))  die("Brak config.php");
    if (file_exists("../zamkniety_inc/zamkniety_install.php")) die("Usuń plik instalacyjny.");
    require_once "../zamkniety_inc/config.php";
    if (session_status() === PHP_SESSION_NONE) session_start();
    require_once __DIR__ . "/lang.php";
    require_once __DIR__ . "/admin_functions.php";
}
if (!administrator()) { header("Location: index.php"); exit; }

if (empty($_SESSION['admin_csrf'])) $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
$csrf = $_SESSION['admin_csrf'];

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('Nieprawidłowy CSRF.');

    if (($_POST['option'] ?? '') === 'xml_import') {
        $url = trim($_POST['plik'] ?? '');
        if (!empty($url) && str_ends_with(strtolower($url), '.xml') && str_starts_with($url, 'http')) {
            $ctx = stream_context_create(['http' => ['timeout' => 15]]);
            $xml = @simplexml_load_file($url, 'SimpleXMLElement', 0, '', false);
            if ($xml === false) {
                $msg = '<div style="color:red;">❌ Nie można wczytać pliku XML. Sprawdź adres URL.</div>';
            } else {
                // Try to import categories from DMOZ/ODP-style XML or generic XML
                $imported = 0; $skipped = 0;
                // Try: <category><name>...</name></category>
                foreach ($xml->xpath('//category') ?: [] as $cat) {
                    $name = trim((string)($cat->name ?? $cat->attributes()->name ?? ''));
                    if ($name === '') continue;
                    $name = htmlspecialchars(substr($name, 0, 255), ENT_QUOTES, 'UTF-8');
                    $ex = $pdo->prepare("SELECT id FROM {$prefix}kategorie WHERE nazwa=:n");
                    $ex->execute([':n'=>$name]);
                    if ($ex->fetch()) { $skipped++; continue; }
                    $pdo->prepare("INSERT INTO {$prefix}kategorie (nazwa,data,akt) VALUES (:n,:d,1)")
                        ->execute([':n'=>$name,':d'=>time()]);
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='kat_a'");
                    $imported++;
                }
                $msg = '<div style="color:green;">✅ ' . t('xml_import_done') . ' <b>'.$imported.'</b> ' . t('xml_imported_cats') . '. ' . t('xml_skipped') . ': <b>'.$skipped.'</b>.</div>';
            }
        } else {
            $msg = '<div style="color:red;">❌ ' . t('xml_url_error') . '</div>';
        }
    }
}

// Render only the content (header/footer already rendered if called from index.php)
$standalone = !defined('ZAMKNIETY_ADMIN_HEADER_SENT');
if ($standalone) {
    define('ZAMKNIETY_ADMIN_HEADER_SENT', true);
    admin_site_header();
}
?>
<div class="admin-section-title">📥 <?= t('nav_xml_import') ?></div>
<?= $msg ?>
<div style="background:rgba(255,255,255,0.65);border:1px solid var(--border);border-radius:6px;padding:16px 20px;margin-bottom:16px;">
<p style="font-size:12px;color:#5a7a9a;"><?= t('xml_desc') ?></p>
<form method="post" action="index.php?a=xml_import">
<input type="hidden" name="option" value="xml_import" />
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf,ENT_QUOTES,'UTF-8') ?>" />
<div style="display:flex;gap:8px;align-items:center;margin-top:8px;">
<input type="text" name="plik" placeholder="https://example.com/categories.xml" style="flex:1;padding:8px;border:1px solid var(--border);border-radius:4px;font-size:13px;" />
<button type="submit" class="btn" style="width:auto;padding:8px 20px;">📥 <?= t('xml_import_btn') ?></button>
</div>
</form>
</div>
<div style="background:rgba(220,235,250,0.5);border:1px solid var(--border);border-radius:6px;padding:16px 20px;">
<b><?= t('xml_sitemap_title') ?></b>
<p style="font-size:12px;color:#5a7a9a;"><?= t('xml_sitemap_desc') ?></p>
<a href="xml_export.php?a=mapy_stron" class="btn" style="display:inline-block;width:auto;padding:8px 20px;text-decoration:none;">📤 <?= t('xml_sitemap_btn') ?></a>
</div>
<?php
if ($standalone) admin_site_footer();
