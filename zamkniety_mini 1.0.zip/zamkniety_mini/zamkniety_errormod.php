<?php
// Zamknięty mini v1.0 - zamkniety_errormod.php
// Obsługa błędów 404 dla mod_rewrite (tryb m7=2 lub 3)

require_once("zamkniety_inc/config.php");
require_once("zamkniety_disp/funkcje.php");

if ($cfg['m1'] == 1 || $cfg['m1'] == 3) {
    $ru = '';
    if (($cfg['m7'] ?? '') == 2) {
        $ru = substr($_SERVER['REQUEST_URI'] ?? '', 1, -5);
    } elseif (($cfg['m7'] ?? '') == 3) {
        $ru = substr($_SERVER['PATH_REDIRECTED'] ?? '', 1, -5);
    }

    $sep = $cfg['m2'] ?? '-';
    $ru  = explode($sep, $ru);

    if (!empty($ru[0])) {
        switch ($ru[0]) {
            case $cfg['m3']: // kat
                $id = (int)($ru[1] ?? 0);
                header('HTTP/1.0 200 OK');
                $_GET['a']  = 'kat';
                $_GET['id'] = $id;
                include('zamkniety_disp/kat.php');
                break;
            case $cfg['m4']: // pod
                $id  = (int)($ru[1] ?? 0);
                $min = (int)($ru[2] ?? 0);
                header('HTTP/1.0 200 OK');
                $_GET['a']   = 'pod';
                $_GET['id']  = $id;
                $_GET['min'] = $min;
                include('zamkniety_disp/pod.php');
                break;
            case $cfg['m5']: // szcz
                $id = (int)($ru[1] ?? 0);
                header('HTTP/1.0 200 OK');
                $_GET['a']  = 'szcz';
                $_GET['id'] = $id;
                include('zamkniety_disp/szcz.php');
                break;
            default:
                header('HTTP/1.0 404 Not Found');
        }
    }
}
