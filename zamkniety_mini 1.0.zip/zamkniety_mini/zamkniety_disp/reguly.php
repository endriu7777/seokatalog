<?php
// Zamknięty mini v1.0 - reguly.php
// Wyświetla regulamin (pobierany z szablonu)
echo $tpl['regulamin'] ?? '';
