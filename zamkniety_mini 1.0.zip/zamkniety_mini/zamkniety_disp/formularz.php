<?php
// Zamknięty mini - formularz.php (kopia w zamkniety_disp/)
global $cfg;
?>
<form name="search" action="index.php" method="get">
<input type="hidden" name="a" value="search" />
<input type="text" name="szukaj" class="search" placeholder="Szukaj..." />
<input type="submit" value="Szukaj" class="button" />
</form>
