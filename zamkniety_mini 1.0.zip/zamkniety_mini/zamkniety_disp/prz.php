<?php
// Zamknięty mini v1.0 - prz.php
// Google PR is defunct; placeholder
header('HTTP/1.1 301 Moved Permanently');
header('Location: /');
exit;
