<?php
// go.php - przekierowanie zewnętrzne
// Wywoływany przez index.php PRZED jakimkolwiek outputem
$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $stmt = $pdo->prepare("SELECT url, uri, akt FROM {$prefix}wpisy WHERE id=:id AND akt='1'");
    $stmt->execute([':id' => $id]);
    $li = $stmt->fetch();
    if (!empty($li['url'])) {
        $pdo->prepare("UPDATE {$prefix}wpisy SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$id]);
        $dest = 'http://' . $li['url'] . ($li['uri'] !== '' ? '/' . $li['uri'] : '');
        header('Location: ' . $dest, true, 301);
        exit;
    }
}
header('Location: /', true, 301);
exit;
