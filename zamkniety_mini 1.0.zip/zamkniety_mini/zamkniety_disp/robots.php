<?php
// Zamknięty mini - robots.php
// Uwaga: includowany jako include __DIR__ . '/robots.php'
// __DIR__ = katalog zamkniety_disp/, dirname(__DIR__) = katalog główny serwisu

$_rb_ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

// rob.db leży w katalogu głównym serwisu (jeden poziom wyżej niż zamkniety_disp/)
$_rb_db = dirname(__DIR__) . '/rob.db';

$_rb_bots = [
    'Google' => ['needle' => 'googlebot',   'color' => '#4285F4'],
    'Bing'   => ['needle' => 'bingbot',     'color' => '#008272'],
    'Yahoo'  => ['needle' => 'slurp',       'color' => '#7B1FA2'],
    'Yandex' => ['needle' => 'yandexbot',   'color' => '#D32F2F'],
    'Baidu'  => ['needle' => 'baiduspider', 'color' => '#E65100'],
];

// Wykryj bota
$_rb_detected = '';
foreach ($_rb_bots as $_rb_name => $_rb_data) {
    if (str_contains($_rb_ua, $_rb_data['needle'])) {
        $_rb_detected = $_rb_name;
        break;
    }
}

// Wczytaj liczniki
$_rb_counts = array_fill_keys(array_keys($_rb_bots), 0);
if (file_exists($_rb_db) && filesize($_rb_db) > 0) {
    $loaded = @unserialize(@file_get_contents($_rb_db));
    if (is_array($loaded)) {
        foreach (array_keys($_rb_bots) as $k) {
            if (isset($loaded[$k])) $_rb_counts[$k] = (int)$loaded[$k];
        }
    }
}

// Zapisz wizytę bota
if ($_rb_detected !== '') {
    $_rb_counts[$_rb_detected]++;
    @file_put_contents($_rb_db, serialize($_rb_counts), LOCK_EX);
}

// Wyświetl pasek - zawsze widoczny, bez emoji
echo '<div style="font-size:11px;color:#7a9aaa;padding:5px 2px;margin-top:6px;'
   . 'border-top:1px solid #dde8f0;display:flex;flex-wrap:wrap;gap:10px;">';
foreach ($_rb_bots as $name => $data) {
    $cnt = (int)($_rb_counts[$name] ?? 0);
    echo '<span style="white-space:nowrap;">'
       . '<b style="color:' . $data['color'] . ';">' . $name . '</b>'
       . ': <b style="color:#3a6a9a;">' . $cnt . '</b>'
       . '</span>';
}
echo '</div>';
