<?php
// Zamknięty mini - robots.php
// Bot counter przechowywany w tabeli ilosci (klucze: bot_Google, bot_Bing itd.)

global $pdo, $prefix;
if (empty($pdo) || empty($prefix)) return;

$_rb_ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');

$_rb_bots = [
    'Google' => ['needle' => 'googlebot',   'color' => '#4285F4'],
    'Bing'   => ['needle' => 'bingbot',     'color' => '#008272'],
    'Yahoo'  => ['needle' => 'slurp',       'color' => '#7B1FA2'],
    'Yandex' => ['needle' => 'yandexbot',   'color' => '#D32F2F'],
    'Baidu'  => ['needle' => 'baiduspider', 'color' => '#E65100'],
];

// Wykryj bota i inkrementuj licznik w bazie
$_rb_detected = '';
foreach ($_rb_bots as $_rb_name => $_rb_data) {
    if (str_contains($_rb_ua, $_rb_data['needle'])) {
        $_rb_detected = $_rb_name;
        break;
    }
}

if ($_rb_detected !== '') {
    $key = 'bot_' . $_rb_detected;
    $pdo->prepare("INSERT INTO {$prefix}ilosci (nazwa,ilosc) VALUES (:k,1) ON DUPLICATE KEY UPDATE ilosc=ilosc+1")
        ->execute([':k' => $key]);
}

// Wczytaj liczniki z bazy
$_rb_counts = array_fill_keys(array_keys($_rb_bots), 0);
$_rb_rows = $pdo->query("SELECT nazwa, ilosc FROM {$prefix}ilosci WHERE nazwa LIKE 'bot_%'");
if ($_rb_rows) {
    foreach ($_rb_rows as $r) {
        $name = substr($r['nazwa'], 4); // strip 'bot_'
        if (isset($_rb_counts[$name])) $_rb_counts[$name] = (int)$r['ilosc'];
    }
}

// Wyświetl pasek
echo '<div style="font-size:11px;color:#7a9aaa;padding:5px 2px;margin-top:6px;'
   . 'border-top:1px solid #dde8f0;display:flex;flex-wrap:wrap;gap:10px;">';
foreach ($_rb_bots as $name => $data) {
    $cnt = (int)($_rb_counts[$name] ?? 0);
    echo '<span style="white-space:nowrap;">'
       . '<b style="color:' . $data['color'] . ';">' . $name . '</b>'
       . ': <b style="color:#3a6a9a;">' . $cnt . '</b>'
       . '</span>';
}
echo '</div>';
