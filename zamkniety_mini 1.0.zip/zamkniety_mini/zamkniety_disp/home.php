<?php
// Zamknięty mini v1.0 - home.php
disp_header($cfg['o1'] ?? '', $cfg['o2'] ?? '', $cfg['o3'] ?? '');
    mini_magic($tpl['welcome'] ?? '');
    mini_magic($tpl['ads2'] ?? '');
    ?>
<div class="cat_sub_block">
  <table>
    <tr style="vertical-align:top;">
<?php
    if ((int)($ile['kat_a'] ?? 0) > 0) {
        $cols  = (int)($cfg['g1'] ?? 1);
        $total = (int)$ile['kat_a'];
        $dz    = (int)ceil($total / $cols);

        for ($i = 1; $i <= $cols; $i++) {
            $offset = $dz * ($i - 1);
            $count  = ($i === $cols) ? ($total - $offset) : $dz;
            if ($count < 0) $count = 0;

            echo '<td style="vertical-align:top;">';

            $stmt = $pdo->prepare("SELECT * FROM {$prefix}kategorie WHERE akt=1 ORDER BY data DESC, id DESC LIMIT :offset, :count");
            $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
            $stmt->bindValue(':count',  $count,  PDO::PARAM_INT);
            $stmt->execute();

            while ($li = $stmt->fetch()) {
                $kat_link = kat_link($li['id'], $li['nazwa'], $cfg);

                echo '<div class="cat_block_home">';
                echo '<div class="in_link_home_cat_div"><a href="' . htmlspecialchars($kat_link, ENT_QUOTES, 'UTF-8') . '" class="in_link_home_cat">' . htmlspecialchars($li['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></div>';

                if ($cfg['g2'] == 1 && $li['pod_a'] > 0) {
                    echo '<div class="sub_block_home">';
                    $sub_count = (int)($cfg['g3'] ?? 5);
                    $stmt_pod = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id_kat = :kid AND akt=1 ORDER BY nazwa LIMIT 0, :cnt");
                    $stmt_pod->bindValue(':kid', $li['id'], PDO::PARAM_INT);
                    $stmt_pod->bindValue(':cnt', $sub_count, PDO::PARAM_INT);
                    $stmt_pod->execute();

                    while ($li_pod = $stmt_pod->fetch()) {
                        $pod_link = pod_link($li_pod['id'], $li_pod['nazwa'], $cfg);
                        echo '<a href="' . htmlspecialchars($pod_link, ENT_QUOTES, 'UTF-8') . '" class="body_links">' . htmlspecialchars($li_pod['nazwa'], ENT_QUOTES, 'UTF-8') . '</a>';
                        if ((int)($cfg['iw'] ?? 0) == 1) {
                            $cnt_q = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}relacje r JOIN {$prefix}wpisy w ON w.id=r.id_wpi AND w.akt=1 WHERE r.id_pod=:pid");
                            $cnt_q->execute([':pid' => (int)$li_pod['id']]);
                            echo ' <span class="ilosc_cat">(' . (int)$cnt_q->fetchColumn() . ')</span>';
                        }
                        echo '<br />';
                    }
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</td>';
        }
    }
?>
    </tr>
  </table>
</div>
<?php
    // --- Ostatnio dodane wpisy na stronie głównej ---
    // Ile wpisów: bierz k3 z konfiguracji (3/6/9), domyślnie 5
    $home_entries_lim = max(3, min(20, (int)($cfg['k3'] ?? 5)));
    $home_stmt = $pdo->prepare(
        "SELECT * FROM {$prefix}wpisy WHERE akt='1' ORDER BY data DESC LIMIT :lim"
    );
    $home_stmt->bindValue(':lim', $home_entries_lim, PDO::PARAM_INT);
    $home_stmt->execute();
    $home_entries = $home_stmt->fetchAll();
    if ($home_entries) {
        echo '<div class="text_body_h3">Ostatnio dodane wpisy:</div>';
        echo '<div class="links_block">';
        foreach ($home_entries as $li_lw) {
            render_entry($li_lw, $pdo, $prefix, $cfg, $nofollow, $target);
        }
        echo '</div>';
    }

    if (!empty($cfg['glotag'])) {
        globalne_tagi($pdo, $prefix);
    }
    include __DIR__ . '/robots.php';
    mini_magic($tpl['ads3'] ?? '');
    disp_footer();

