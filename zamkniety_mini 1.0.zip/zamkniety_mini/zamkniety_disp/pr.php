<?php
// Zamknięty mini v1.0 - pr.php
// Google PageRank API is defunct; this stub returns -9 (unknown)
function getrank(string $url): int
{
    return -9;
}
