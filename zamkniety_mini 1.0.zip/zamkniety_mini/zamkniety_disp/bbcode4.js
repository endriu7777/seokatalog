D=document,S=[],T=[],C=alert,B=unescape;onload=function(){F=D.getElementById('txt')}
function bbcode(x,z){(z=s())?A('['+x+']'+z+'[/'+x+']'):R(x)}
function A(x){D.selection?(F.focus(),D.selection.createRange().text=x):(F.selectionStart||F.selectionStart=='0')?F.value=F.value.substring(0,F.selectionStart)+x+F.value.substring(F.selectionEnd,F.value.length):F.value+=x}
function s(){return D.selection?D.selection.createRange().text:F.value.substring(F.selectionEnd||0,F.selectionStart||0)}
function R(x){T[x]?'':T[x]=0;T[x]?CT(x):(S.push(x),T[x]=1,A('['+x+']'),St(x,'*'))}
function St(i,x){D.getElementById(i).value=i+x}Z='%52%4b';function emot(x){A(x)}
function CT(x,a){T[a=S.pop()]=0;A('[/'+a+']');St(a,'');a!=x?CT(x):''}
function CA(e){while(S[0]){A('[/'+(e=S.pop())+']');T[e]=0;St(e,'')}}