<?php
// Zamknięty mini v1.0 - mapa.php
    disp_header(
        'Mapa katalogu - ' . ($cfg['o1'] ?? ''),
        $cfg['o2'] ?? '',
        $cfg['o3'] ?? ''
    );
    echo '<div class="text_body_h1">Mapa katalogu</div>';

    $kats = $pdo->query("SELECT * FROM {$prefix}kategorie WHERE akt='1' ORDER BY nazwa");
    while ($kat = $kats->fetch()) {
        $kl = htmlspecialchars(kat_link((int)$kat['id'], $kat['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
        echo '<div class="cat_block_home"><a href="' . $kl . '" class="in_link_home_cat">' . htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></div>';

        $pods = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id_kat=:kid AND akt='1' ORDER BY nazwa");
        $pods->execute([':kid' => $kat['id']]);
        while ($pod = $pods->fetch()) {
            $pl = htmlspecialchars(pod_link((int)$pod['id'], $pod['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
            echo '<div class="sub_block_home" style="padding-left:20px;">&raquo; <a href="' . $pl . '" class="body_links">' . htmlspecialchars($pod['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></div>';
        }
    }

    disp_footer();
