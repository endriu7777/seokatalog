<?php
// Zamknięty mini v1.0 - kat.php
    $kat_id = (int)($_GET['id'] ?? 0);
    $stmt   = $pdo->prepare("SELECT * FROM {$prefix}kategorie WHERE id = :id AND akt = '1'");
    $stmt->execute([':id' => $kat_id]);
    $kat    = $stmt->fetch();

    if (!empty($kat['id']) && $kat['akt'] == 1) {
        $pdo->prepare("UPDATE {$prefix}kategorie SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$kat_id]);

        disp_header(
            $kat['nazwa'] . ' - ' . ($cfg['o1'] ?? ''),
            $kat['nazwa'] . ' - ' . ($cfg['o2'] ?? ''),
            $kat['nazwa'] . ' - ' . ($cfg['o3'] ?? '')
        );
        echo '<div class="text_body_h1">' . htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8') . '</div>';
        mini_magic($tpl['ads2'] ?? '');
?>
<div class="cat_sub_block">
<table><tr style="vertical-align:top;">
<?php
        if ((int)$kat['pod_a'] > 0) {
            $cols   = (int)($cfg['k1'] ?? 2);
            $total  = (int)$kat['pod_a'];
            $dz     = (int)ceil($total / $cols);

            for ($i = 1; $i <= $cols; $i++) {
                $offset = $dz * ($i - 1);
                $count  = ($i === $cols) ? ($total - $offset) : $dz;
                if ($count < 0) $count = 0;

                echo '<td>';
                $s = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE akt=1 AND id_kat=:kid ORDER BY data DESC, id DESC LIMIT :off, :cnt");
                $s->bindValue(':kid', $kat_id, PDO::PARAM_INT);
                $s->bindValue(':off', $offset, PDO::PARAM_INT);
                $s->bindValue(':cnt', $count,  PDO::PARAM_INT);
                $s->execute();

                while ($li = $s->fetch()) {
                    $pod_link_e = htmlspecialchars(pod_link((int)$li['id'], $li['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
                    echo '<div class="sub_block_cat">';
                    echo '<a href="' . $pod_link_e . '" class="in_link_cat_sub">' . htmlspecialchars($li['nazwa'], ENT_QUOTES, 'UTF-8') . '</a>';
                    if ($cfg['iw'] == 1) {
                        $cnt_q = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}relacje r JOIN {$prefix}wpisy w ON w.id=r.id_wpi AND w.akt=1 WHERE r.id_pod=:pid");
                        $cnt_q->execute([':pid' => (int)$li['id']]);
                        echo ' <span class="ilosc_cat">(' . (int)$cnt_q->fetchColumn() . ')</span>';
                    }
                    echo '<br /></div>';
                }
                echo '</td>';
            }
        }
?>
</tr></table>
</div>
<?php
        // Recently added entries in this category
        if ($cfg['k2'] == 1 && (int)$kat['wpi_a'] > 0) {
            $limit_k3 = (int)($cfg['k3'] ?? 5);
            $zap_lw   = $pdo->prepare(
                "SELECT w.* FROM {$prefix}relacje r
                 JOIN {$prefix}wpisy w ON w.id = r.id_wpi
                 WHERE r.id_kat = :kid AND w.akt = '1'
                 GROUP BY w.id ORDER BY w.data DESC LIMIT 0, :lim"
            );
            $zap_lw->bindValue(':kid', $kat_id, PDO::PARAM_INT);
            $zap_lw->bindValue(':lim', $limit_k3, PDO::PARAM_INT);
            $zap_lw->execute();

            echo '<div class="links_block">';
            echo '<div class="text_body_h3">Ostatnio dodane wpisy w kategorii "' . htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8') . '":</div>';

            while ($li_lw = $zap_lw->fetch()) {
                $pdo->prepare("UPDATE {$prefix}wpisy SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$li_lw['id']]);
                render_entry($li_lw, $pdo, $prefix, $cfg, $nofollow, $target);
            }
            echo '</div>';
        }

        include 'robots.php';
?>
<div style="background:rgba(210,230,250,0.5);border:1px solid rgba(100,160,220,0.3);border-radius:4px;padding:8px 12px;margin:8px 0;font-size:12px;color:#4a6a8a;">
ℹ️ Aby dodać stronę do katalogu, wejdź najpierw w wybraną <b>podkategorię</b>, a tam znajdziesz formularz dodawania.
</div>
<div class="add_block">
<?php add_sub_form('', $kat_id, $pdo, $prefix); ?>
</div>
<?php
        mini_magic($tpl['ads3'] ?? '');
        disp_footer();
    } else {
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: /');
        header('Connection: close');
        exit;
    }
