<?php
// Zamknięty mini v1.0 - rss.php
    header('Content-Type: application/rss+xml; charset=UTF-8');

    $limit = 20;
    $stmt  = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE akt='1' ORDER BY data DESC LIMIT 0, :lim");
    $stmt->bindValue(':lim', $limit, PDO::PARAM_INT);
    $stmt->execute();
    $items = $stmt->fetchAll();

    $title       = htmlspecialchars($cfg['o1'] ?? 'Katalog', ENT_XML1, 'UTF-8');
    $description = htmlspecialchars($cfg['o2'] ?? '', ENT_XML1, 'UTF-8');
    $link        = htmlspecialchars($cfg['o4'] ?? 'http://' . ($_SERVER['HTTP_HOST'] ?? ''), ENT_XML1, 'UTF-8');

    echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
    echo '<rss version="2.0">' . "\n";
    echo '<channel>' . "\n";
    echo '<title>' . $title . '</title>' . "\n";
    echo '<link>' . $link . '</link>' . "\n";
    echo '<description>' . $description . '</description>' . "\n";

    foreach ($items as $item) {
        $it    = htmlspecialchars($item['tytul'], ENT_XML1, 'UTF-8');
        $io    = htmlspecialchars(koder($item['opis']), ENT_XML1, 'UTF-8');
        $ilink = htmlspecialchars('http://' . $item['url'] . '/' . $item['uri'], ENT_XML1, 'UTF-8');
        $idate = date('r', (int)$item['data']);

        echo '<item>' . "\n";
        echo '<title>' . $it . '</title>' . "\n";
        echo '<link>' . $ilink . '</link>' . "\n";
        echo '<description>' . $io . '</description>' . "\n";
        echo '<pubDate>' . $idate . '</pubDate>' . "\n";
        echo '</item>' . "\n";
    }

    echo '</channel>' . "\n";
    echo '</rss>' . "\n";
    exit;
