
// ---------------------------------------------------------------------------- // 
// Skrypt otwarty.pl mini
// ---------------------------------------------------------------------------- // 


function OtwartyMiniBlank() { 

tagA = document.getElementsByTagName('a');
for( i = 0; i < tagA.length; i++ ) 
{
      if( tagA[ i ].className.match("^out_link") ) 
      {
            tagA[ i ].target = "_blank";
      }
}
}
window.onload = OtwartyMiniBlank;
