// Copyright (c) 2008, General_Depet - http://www.katalog.intelekt.net.pl

var obj='';
var timer='';
function iloscZnakow(o,i){
   if (o) obj=o;
   if (i) obj2=i;
   var div=document.getElementById('iloscZnakow');
   var iloscWpisanych = obj.value.length;
   var ilosc = obj2;

   obj1 = document.getElementById('anchor');
   
   if (iloscWpisanych > ilosc) {
   obj1.disabled = false;
   iloscWpisanych = '<span style="color:green">'+iloscWpisanych+'</span>'; 
   }
   else {
   obj1.disabled = true;
   iloscWpisanych = '<span style="color:red">'+iloscWpisanych+'</span>'; 
   }

   div.style.fontWeight='bold';
   div.innerHTML='wpisanych znaków '+iloscWpisanych;

   timer=setTimeout('iloscZnakow()', 100);
}

