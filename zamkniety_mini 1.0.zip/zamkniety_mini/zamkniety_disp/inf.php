<?php
// Zamknięty mini v1.0 - inf.php
    disp_header(
        'Informacje - ' . ($cfg['o1'] ?? ''),
        $cfg['o2'] ?? '',
        $cfg['o3'] ?? ''
    );
    mini_magic($tpl['ads2'] ?? '');
    echo '<div class="text_body_h1">Regulamin oraz informacje o katalogu</div>';
    echo $tpl['inf'] ?? '<p>Brak treści regulaminu.</p>';
    mini_magic($tpl['ads3'] ?? '');
    disp_footer();
