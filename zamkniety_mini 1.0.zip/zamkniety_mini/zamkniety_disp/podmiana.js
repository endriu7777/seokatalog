// Zamknięty mini v1.0 - podmiana.js
function podmiana(kat_id, nr, max) {
    for (var i = 1; i <= max; i++) {
        var el = document.getElementById(nr + '_' + i);
        if (el) el.style.display = 'none';
    }
    var show = document.getElementById(nr + '_' + kat_id);
    if (show) show.style.display = 'inline';
}
