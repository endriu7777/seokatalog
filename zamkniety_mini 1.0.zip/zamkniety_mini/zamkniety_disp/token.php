<?php
// Zamknięty mini v1.0 - token.php
    global $token;

    header('Content-Type: image/png');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');

    $width  = 100;
    $height = 28;
    $img    = imagecreatetruecolor($width, $height);

    // Colors — blue/sandy theme
    $bg     = imagecolorallocate($img, 220, 235, 250);
    $fg     = imagecolorallocate($img, 20,  60, 140);
    $noise  = imagecolorallocate($img, 140, 180, 220);

    imagefill($img, 0, 0, $bg);

    // Noise dots
    for ($i = 0; $i < 60; $i++) {
        imagesetpixel($img, random_int(0, $width-1), random_int(0, $height-1), $noise);
    }

    // Text
    $font = __DIR__ . '/../zamkniety_tpl/default/arial.ttf';
    $text = $token ?? 'XXXXXX';

    if (file_exists($font)) {
        imagettftext($img, 14, 0, 8, 20, $fg, $font, $text);
    } else {
        imagestring($img, 5, 10, 6, $text, $fg);
    }

    imagepng($img);
    imagedestroy($img);
    exit;
} else {
    echo 'Wejście bezpośrednie jest niedozwolone.';
