<?php
// klik.php - cichy licznik kliknięć
$id = (int)($_GET['id'] ?? 0);
if ($id > 0) {
    $pdo->prepare("UPDATE {$prefix}wpisy SET klikniecia=klikniecia+1 WHERE id=:id")->execute([':id'=>$id]);
}
http_response_code(204); // No Content - browser shows nothing
exit;
