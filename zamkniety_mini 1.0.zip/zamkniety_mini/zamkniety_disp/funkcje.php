<?php
// Zamknięty mini v1.0 - funkcje.php  (PHP 8.4, PDO)
// WAŻNE: wszystkie funkcje zdefiniowane PRZED ich wywołaniem

// ---- DB helpers ---------------------------------------------
function cfg(PDO $pdo, string $prefix): array {
    $c=[];
    foreach($pdo->query("SELECT nazwa,wartosc FROM {$prefix}konfiguracja") as $r) $c[$r['nazwa']]=$r['wartosc'];
    return $c;
}
function ile(PDO $pdo, string $prefix): array {
    $i=[];
    foreach($pdo->query("SELECT nazwa,ilosc FROM {$prefix}ilosci") as $r) $i[$r['nazwa']]=$r['ilosc'];
    return $i;
}
function tpl(PDO $pdo, string $prefix): array {
    $t=[];
    foreach($pdo->query("SELECT nazwa,wartosc FROM {$prefix}template") as $r) $t[$r['nazwa']]=$r['wartosc'];
    return $t;
}

// ---- SEO URL ------------------------------------------------
function zmiana_url(string $text): string {
    global $cfg;
    $sep = $cfg['m2'] ?? '-';
    // Tekst jest już w UTF-8 (baza utf8mb4) — NIE konwertuj z ISO-8859-2
    $map = [
        'a'=>['à','á','â','ã','ä','å','ā','ą','a','A'],
        'b'=>['b','B'],
        'c'=>['ć','č','ç','c','C'],
        'd'=>['ď','đ','d','D'],
        'e'=>['è','é','ê','ë','ě','ę','e','E'],
        'f'=>['f','F'],
        'g'=>['ğ','g','G'],
        'h'=>['h','H'],
        'i'=>['ì','í','î','ï','ī','i','I'],
        'j'=>['j','J'],
        'k'=>['k','K'],
        'l'=>['ł','ĺ','l','L'],
        'm'=>['m','M'],
        'n'=>['ń','ñ','n','N'],
        'o'=>['ò','ó','ô','õ','ö','ø','ő','o','O'],
        'p'=>['p','P'],
        'q'=>['q','Q'],
        'r'=>['ř','ŕ','r','R'],
        's'=>['ś','š','ş','s','S'],
        't'=>['ť','t','T'],
        'u'=>['ù','ú','û','ü','ů','ű','u','U'],
        'v'=>['v','V'],
        'w'=>['w','W'],
        'x'=>['x','X'],
        'y'=>['ÿ','y','Y'],
        'z'=>['ź','ż','ž','z','Z'],
    ];
    $out='';
    preg_match_all('~.~su',$text,$ch);
    foreach($ch[0] as $c){
        $f=false;
        foreach($map as $rep=>$src){if(in_array($c,$src,true)){$out.=$rep;$f=true;break;}}
        if(!$f){if(preg_match('~[0-9]~',$c))$out.=$c;elseif(in_array($c,[' ',',','.','_','-']))$out.=$sep;}
    }
    $out=preg_replace('~'.preg_quote($sep,'~').'+~',$sep,$out);
    return trim($out,$sep);
}

// ---- URL helpers --------------------------------------------
function kat_link(int $id, string $nazwa, array $cfg): string {
    $m=$cfg['m3']??'kat';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($nazwa).$s.'k'.$id.$e;
    return'index.php?a=kat&amp;id='.$id;
}
function pod_link(int $id, string $nazwa, array $cfg): string {
    $m=$cfg['m4']??'pod';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($nazwa).$s.'p'.$id.$e;
    return'index.php?a=pod&amp;id='.$id;
}
function szcz_link(int $id, string $tytul, array $cfg): string {
    $m=$cfg['m5']??'szcz';$s=str_contains($m,'/')?'/':($cfg['m2']??'-');$e=str_contains($m,'/')?'/':'.html';
    if(($cfg['m1']??0)==1)return'/'.$m.$s.$id.$e;
    if(($cfg['m1']??0)==3)return'/'.zmiana_url($tytul).$s.'s'.$id.$e;
    return'index.php?a=szcz&amp;id='.$id;
}

// ---- Render entry -------------------------------------------
function render_entry(array $li, PDO $pdo, string $prefix, array $cfg, string $nofollow, string $target): void {
    $id     = (int)$li['id'];
    $tytul  = htmlspecialchars($li['tytul'], ENT_QUOTES, 'UTF-8');
    $opis   = koder($li['opis']);
    $url2   = 'http://' . $li['url'] . ($li['uri'] !== '' ? '/' . $li['uri'] : '');
    $u2_e   = htmlspecialchars($url2, ENT_QUOTES, 'UTF-8');
    $data   = date('d-m-Y', (int)$li['data']);
    $det    = htmlspecialchars(szcz_link($id, $li['tytul'], $cfg), ENT_QUOTES, 'UTF-8');
    $w5     = (int)($cfg['w5'] ?? 2);

    // URL do kliknięcia (bezpośredni lub przez redirect go.php)
    if ($w5 === 1) {
        // Linki bezpośrednie - href = prawdziwy URL
        $href = $u2_e;
        $t_attr = !empty($target) ? $target : '';
    } else {
        // Przez go.php (zlicza odwiedziny i przekierowuje)
        $href = htmlspecialchars('index.php?a=go&id=' . $id, ENT_QUOTES, 'UTF-8');
        $t_attr = ' target="_blank"';
    }

    echo '<div class="link_block"><table><tr><td class="wpistd">';

    // Miniaturka strony — statyczne SVG zakodowane base64 (darmowe, bez zewnętrznych usług)
    if ((int)($cfg['min'] ?? 0) === 1) {
        $svg_raw = '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="60" viewBox="0 0 80 60">'
            . '<rect width="80" height="60" fill="#e8f0f8" rx="3"/>'
            . '<rect width="80" height="60" fill="none" stroke="#b0c8e0" stroke-width="1" rx="3"/>'
            . '<line x1="0" y1="0" x2="80" y2="60" stroke="#ccd8e8" stroke-width="0.7"/>'
            . '<line x1="80" y1="0" x2="0" y2="60" stroke="#ccd8e8" stroke-width="0.7"/>'
            . '<rect x="-5" y="18" width="90" height="16" fill="#b82020" opacity="0.88" transform="rotate(-22 40 26)"/>'
            . '<text x="40" y="28" font-family="Arial,Helvetica,sans-serif" font-size="8.5" font-weight="bold" fill="#ffffff" text-anchor="middle" transform="rotate(-22 40 26)" letter-spacing="0.8">ZAMKNIETY</text>'
            . '</svg>';
        $svg_thumb = 'data:image/svg+xml;base64,' . base64_encode($svg_raw);
        echo '<a href="' . $href . '"' . $t_attr . '>'
            . '<img src="' . $svg_thumb . '" '
            . 'class="msn" alt="zamkniety" loading="lazy" '
            . 'width="80" height="60" />'
            . '</a>';
    }

    echo '</td><td class="wpistd">';

    // Tytuł jako link do strony szczegółów wpisu (nie do zewnętrznego URL)
    echo '<a href="' . $det . '" class="out_link"' . $nofollow . '>' . $tytul . '</a>';

    echo '<div class="text_link">' . $opis . '</div>';
    echo '<div class="text_link">' . $u2_e . '</div>';
    echo '<div class="text_link">data: ' . $data;
    if ((int)($cfg['p2'] ?? 0) === 1) {
        echo ' | <a href="' . $det . '" class="in_link">szczeg&oacute;ły</a>';
    }
    echo '</div>';

    // Link zwrotny — pokaż ikonę jeśli wpis ma link zwrotny
    if (!empty($li['link_zwrotny'])) {
        $lz_e = htmlspecialchars($li['link_zwrotny'], ENT_QUOTES, 'UTF-8');
        if ((int)($cfg['link_prz'] ?? 0) === 1) {
            echo '<div class="text_link" style="margin-top:2px;"><span style="font-size:10px;color:#2a8a2a;">✔ link zwrotny</span></div>';
        }
    }

    // Anchor-texty w opisie (bbcode [url=...])
    if ((int)($cfg['anchor'] ?? 0) === 1) {
        // anchor jest już obsługiwany przez koder() / dekoder() w opisie
    }

    // Open Page Rank
    if ((int)($cfg['opr'] ?? 0) === 1 && !empty($cfg['opr_key'])) {
        $opr_domain = parse_url($url2, PHP_URL_HOST) ?: $li['url'];
        $opr_cache_key = 'opr_' . md5($opr_domain);
        $opr_rank = null;
        // Simple file-based cache (24h)
        $opr_cache_file = sys_get_temp_dir() . '/' . $opr_cache_key . '.txt';
        if (file_exists($opr_cache_file) && (time() - filemtime($opr_cache_file)) < 86400) {
            $opr_rank = (int)file_get_contents($opr_cache_file);
        } else {
            $opr_url = 'https://openpagerank.com/api/v1.0/getPageRank?domains%5B0%5D=' . urlencode($opr_domain);
            $opr_ctx = stream_context_create(['http' => [
                'method'  => 'GET',
                'header'  => 'API-OPR: ' . trim($cfg['opr_key']),
                'timeout' => 3,
            ]]);
            $opr_resp = @file_get_contents($opr_url, false, $opr_ctx);
            if ($opr_resp) {
                $opr_json = @json_decode($opr_resp, true);
                $opr_rank = (int)($opr_json['response'][0]['page_rank_integer'] ?? 0);
                @file_put_contents($opr_cache_file, $opr_rank);
            }
        }
        if ($opr_rank !== null) {
            $opr_color = $opr_rank >= 7 ? '#2a8a2a' : ($opr_rank >= 4 ? '#e07a00' : '#7a9aaa');
            echo '<div class="text_link" style="margin-top:2px;">'
                . '<span style="font-size:10px;background:' . $opr_color . ';color:#fff;padding:1px 6px;border-radius:3px;font-weight:bold;">'
                . 'PAGE RANK = ' . $opr_rank
                . '</span></div>';
        }
    }

    echo '</td></tr></table></div>';
}

// ---- CSRF ---------------------------------------------------
function csrf_token(): string {
    if(empty($_SESSION['csrf_token']))$_SESSION['csrf_token']=bin2hex(random_bytes(32));
    return $_SESSION['csrf_token'];
}
function csrf_verify(): bool {
    return hash_equals($_SESSION['csrf_token']??'',$_POST['csrf_token']??'');
}

// ---- BBCode -------------------------------------------------
function dekoder(string $t): string {
    $t=preg_replace('#\[url=(.*?)\](.*?)\[/url\]#si','<a class="out_link_home_cat" href="$1">$2</a>',$t);
    $t=preg_replace('#\[url=(.*?)\]null\[/url\]#si','<a class="out_link_home_cat" href="$1">$1</a>',$t);
    return $t;
}
function koder(string $t): string {
    $t=preg_replace('#\[url=(.*?)\](.*?)\[/url\]#si','$2',$t);
    $t=preg_replace('#\[url=(.*?)\]null\[/url\]#si','$1',$t);
    return $t;
}

// ---- Mini magic ---------------------------------------------
function mini_magic(?string $s): void {
    if ($s === null || $s === '') return;

    // Decode HTML entities so <php> tags work even if stored as &lt;php&gt;
    $decoded = html_entity_decode($s, ENT_QUOTES | ENT_HTML5, 'UTF-8');

    // Find all <php>filename.php</php> blocks
    if (preg_match_all('#<php>\s*(.*?)\s*</php>#si', $decoded, $inc)) {
        // Expose global variables to included files (include inside function loses globals)
        global $pdo, $prefix, $cfg, $tpl, $ile;

        foreach ($inc[1] as $file) {
            $file = trim(strip_tags($file));
            if ($file === '' || !str_ends_with(strtolower($file), '.php')) continue;
            // Security: no directory traversal
            if (str_contains($file, '..') || str_contains($file, '/') || str_contains($file, '\\')) continue;

            $base_paths = [
                rtrim($_SERVER['DOCUMENT_ROOT'] ?? '', '/'),
                rtrim(dirname($_SERVER['SCRIPT_FILENAME'] ?? ''), '/'),
                rtrim(dirname(__FILE__), '/') . '/..',
            ];
            foreach ($base_paths as $base) {
                $path = $base . '/' . $file;
                if (file_exists($path) && is_readable($path)) {
                    include $path;
                    break;
                }
            }
        }
    }

    // Output everything except <php>...</php> blocks
    echo preg_replace('#<php>\s*.*?\s*</php>#si', '', $decoded);
}

// ---- RSS ----------------------------------------------------
function rss_parser(?string $a,?string $b): void {
    global $cfg;
    $url=$a?:($b&&$b!=='0'?$b:'');
    if(!$url)return;
    $rss=@simplexml_load_file($url);
    if(!$rss)return;
    $i=0;
    echo'<div class="text_body_h3">Najnowsze wiadomo&sacute;ci:</div>';
    foreach($rss->channel->item as $item){
        if($i>=(int)($cfg['rss_ilo']??5))break;
        $t=htmlspecialchars((string)$item->title,ENT_QUOTES,'UTF-8');
        $l=htmlspecialchars((string)$item->link,ENT_QUOTES,'UTF-8');
        $d=htmlspecialchars(strip_tags((string)$item->description),ENT_QUOTES,'UTF-8');
        echo'<div class="link_block">';
        if(($cfg['rss_link']??0)==2)echo'<a href="'.$l.'" rel="nofollow"><b>'.$t.'</b></a><br />';
        elseif(($cfg['rss_link']??0)==1)echo'<a href="'.$l.'"><b>'.$t.'</b></a><br />';
        else echo'<b>'.$t.'</b><br />';
        echo $d.'</div>';
        $i++;
    }
}

// ---- Tagi ---------------------------------------------------
function lokalne_tagi(string $slowa): void {
    global $cfg;
    $sep=$cfg['m2']??'-';
    $base=rtrim($cfg['o4']??'','/');
    echo'<div class="text_body_h3">tagi:</div><div class="nav_det">';
    $tags=explode(',',$slowa);$n=count($tags);
    for($i=0;$i<$n;$i++){
        $t=htmlspecialchars(trim($tags[$i]),ENT_QUOTES,'UTF-8');
        echo'<a href="'.$base.'/tag'.$sep.zmiana_url(trim($tags[$i])).$sep.'0.html" class="body_links">'.$t.'</a>';
        if($i<$n-1)echo', ';
    }
    echo'</div>';
}
function globalne_tagi(PDO $pdo,string $prefix): void {
    global $cfg;
    $lim=(int)($cfg['glotag_ilo']??20);$min=(int)($cfg['glotag_min']??0);$sep=$cfg['m2']??'-';
    $base=rtrim($cfg['o4']??'','/');
    $st=$pdo->prepare("SELECT slowo,kod,ilosc FROM {$prefix}tagi WHERE ilosc>:i AND slowo!='' ORDER BY RAND() LIMIT :l");
    $st->bindValue(':i',$min,PDO::PARAM_INT);$st->bindValue(':l',$lim,PDO::PARAM_INT);$st->execute();
    $tags=$st->fetchAll();if(!$tags)return;
    $max=max(array_column($tags,'ilosc'));$avg=array_sum(array_column($tags,'ilosc'))/count($tags);
    echo'<div class="text_body_h3">Popularne tagi:</div><div>';
    foreach($tags as $tag){
        $f=$tag['ilosc']==$max?20:($tag['ilosc']>$avg?16:13);
        echo'<a href="'.$base.'/tag'.$sep.htmlspecialchars($tag['kod'],ENT_QUOTES,'UTF-8').$sep.'0.html" class="out_link" style="font-size:'.$f.'px;">'.htmlspecialchars($tag['slowo'],ENT_QUOTES,'UTF-8').'</a> ('.(int)$tag['ilosc'].') ';
    }
    echo'</div>';
}

// ---- Formularze ---------------------------------------------
function add_cat_form(string $name,PDO $pdo,string $prefix): void {
    global $cfg;
    if((int)($cfg['u1']??0)===3)return;
    $new=($cfg['u1']==1)?'Dodaj nową kategorię':'Zasugeruj nową kategorię';
    $btn=($cfg['u1']==1)?'dodaj':'zasugeruj';
    $ne=htmlspecialchars($name,ENT_QUOTES,'UTF-8');$tok=csrf_token();
    echo'<div class="text_body_h3">'.$new.':</div><form action="index.php?a=op" method="post">';
    echo'<input type="hidden" name="option" value="add_cat" /><input type="hidden" name="csrf_token" value="'.$tok.'" />';
    echo'nazwa: <input type="text" name="name" class="search" value="'.$ne.'" /><input type="submit" class="button" value="'.$btn.'" /></form>';
}
function add_sub_form(string $name,int $cat_id,PDO $pdo,string $prefix): void {
    global $cfg;
    if((int)($cfg['u2']??0)===3)return;
    $new=($cfg['u2']==1)?'Dodaj nową podkategorię':'Zasugeruj nową podkategorię';
    $btn=($cfg['u2']==1)?'dodaj':'zasugeruj';
    $ne=htmlspecialchars($name,ENT_QUOTES,'UTF-8');$tok=csrf_token();
    echo'<div class="text_body_h3">'.$new.':</div><form action="index.php?a=op" method="post">';
    echo'<input type="hidden" name="option" value="add_sub" /><input type="hidden" name="cat_id" value="'.$cat_id.'" /><input type="hidden" name="csrf_token" value="'.$tok.'" />';
    echo'nazwa: <input type="text" name="name" class="search" value="'.$ne.'" /><input type="submit" class="button" value="'.$btn.'" /></form>';
}
function add_link_form(string $name,int $cat_id,int $sub_id): void {
    global $cfg;
    if((int)($cfg['u3']??0)===3)return;
    if($name!==''&&!str_starts_with(strtolower($name),'http'))$name='http://'.$name;
    $new=($cfg['u3']==1)?'Dodaj nową stronę':'Zasugeruj nową stronę';
    $btn=($cfg['u3']==1)?'dodaj':'zasugeruj';
    $ne=htmlspecialchars($name,ENT_QUOTES,'UTF-8');$tok=csrf_token();
    echo'<div class="text_body_h3">'.$new.':</div><form action="index.php?a=op" method="post">';
    echo'<input type="hidden" name="option" value="add_link" /><input type="hidden" name="cat_id" value="'.$cat_id.'" /><input type="hidden" name="sub_id" value="'.$sub_id.'" /><input type="hidden" name="csrf_token" value="'.$tok.'" />';
    echo'adres: <input type="text" class="search" name="url" value="'.$ne.'" /><input type="submit" class="button" value="'.$btn.'" /></form>';
}
function thx(string $info): void {
    disp_header('Informacja','','');
    echo'<div class="text_body_h1">Informacja</div>'.$info.'<br />';
    disp_footer();
}
function html2txt(string $doc): string {
    return strip_tags(preg_replace('@<script[^>]*?>.*?</script>@si','',$doc)??'','<b><i><br><li><ul>');
}

// ---- Sesje --------------------------------------------------
function moje_sesje(): void {
    global $prefix,$ile,$sid,$token,$pdo;
    $sestime=180;
    $sesip=$_SERVER['REMOTE_ADDR']??'';
    $sesuri=urlencode($_SERVER['REQUEST_URI']??'');
    $sesref=urlencode($_SERVER['HTTP_REFERER']??'');
    $sesagent=urlencode($_SERVER['HTTP_USER_AGENT']??'');
    $seshost=urlencode((string)@gethostbyaddr($sesip));
    $range=array_merge(range('A','Z'),range(2,9));
    $token='';
    for($i=0;$i<6;$i++)$token.=$range[random_int(0,count($range)-1)];
    $pdo->prepare("DELETE FROM {$prefix}sesje WHERE czas+:st<:now")->execute([':st'=>$sestime,':now'=>time()]);
    $ex=$pdo->prepare("SELECT COUNT(*) FROM {$prefix}sesje WHERE ident=:sid");
    $ex->execute([':sid'=>$sid]);
    if($ex->fetchColumn()>0){
        $pdo->prepare("UPDATE {$prefix}sesje SET czas=:now,gdzie_jest=:uri,sesref=:ref WHERE ident=:sid")->execute([':now'=>time(),':uri'=>$sesuri,':ref'=>$sesref,':sid'=>$sid]);
    }else{
        $pdo->prepare("INSERT INTO {$prefix}sesje (ip,host,ua,czas,gdzie_jest,sesref,ident,token) VALUES (:ip,:host,:ua,:now,:uri,:ref,:sid,:tok)")->execute([':ip'=>urlencode($sesip),':host'=>$seshost,':ua'=>$sesagent,':now'=>time(),':uri'=>$sesuri,':ref'=>$sesref,':sid'=>$sid,':tok'=>$token]);
        // Zlicz unikalną wizytę IP raz na dobę w tabeli wizyty
        // INSERT IGNORE: jeśli to IP już dziś było — nic nie robi
        try {
            $ins=$pdo->prepare("INSERT IGNORE INTO {$prefix}wizyty (ip,dzien) VALUES (:ip,CURDATE())");
            $ins->execute([':ip'=>$sesip]);
            if($ins->rowCount()>0){
                // Nowe unikalne IP dzisiaj — zwiększ łączny licznik
                $pdo->prepare("INSERT INTO {$prefix}ilosci (nazwa,ilosc) VALUES ('odwiedziny',1) ON DUPLICATE KEY UPDATE ilosc=ilosc+1")->execute();
            }
        } catch(\Exception $e) { /* tabela wizyty może nie istnieć na starych instalacjach */ }
    }
    if(((int)($ile['seslasttime']??0)+60)<time()){
        $cnt=(int)$pdo->query("SELECT COUNT(*) FROM {$prefix}sesje")->fetchColumn();
        $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=:v WHERE nazwa='seslasttime'")->execute([':v'=>time()]);
        $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=:v WHERE nazwa='sescount'")->execute([':v'=>$cnt]);
    }
}

// ---- disp_header / disp_footer ------------------------------
function disp_header(string $mt,string $md,string $mk): void {
    global $cfg,$tpl,$target,$nofollow,$jsc,$sid;
    header('Content-Type: text/html; charset=UTF-8');
    moje_sesje();
    $mt_e=htmlspecialchars($mt,ENT_QUOTES,'UTF-8');
    $md_e=htmlspecialchars(koder($md),ENT_QUOTES,'UTF-8');
    $mk_e=htmlspecialchars($mk,ENT_QUOTES,'UTF-8');
    $main=(int)($tpl['mainwidth']??780);
    $left=(int)($tpl['leftwidth']??0);
    $right=(int)($tpl['rightwidth']??0);
    $lsep=(int)($tpl['leftwidthsep']??0);
    $rsep=(int)($tpl['rightwidthsep']??0);
    $ctr=max(200,$main-$left-$lsep-$rsep-$right);
    ?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8" />
<meta name="robots" content="index,follow" />
<meta name="viewport" content="width=device-width,initial-scale=1" />
<title><?=$mt_e?></title>
<meta name="description" content="<?=$md_e?>" />
<meta name="keywords" content="<?=$mk_e?>" />
<link rel="stylesheet" href="style.css" />
<?=$tpl['stat3']??''?>
<?php if(!empty($jsc)):?><script src="zamkniety_disp/js_blank.js"></script><?php endif;?>
<script src="zamkniety_disp/bbcode4.js"></script>
<script src="zamkniety_disp/adds.js"></script>
<script src="zamkniety_disp/znaki.js"></script>
<script src="zamkniety_disp/podmiana.js"></script>
</head>
<body>
<div class="top"><?=$tpl['top']??''?></div>
<div style="width:<?=$main?>px;text-align:left;margin:0 auto;">
<?php mini_magic($tpl['ads1']??'');?>
<div class="main" style="float:left;width:<?=$main?>px;">
<?php
    if($left>0){
        echo'<div style="float:left;width:'.$left.'px;"><div class="left">';
        foreach(explode('|',$tpl['blockleft']??'') as $bk)mini_magic($tpl[trim($bk)]??'');
        echo'</div></div>';
    }
    if($lsep>0)echo'<div style="float:left;width:'.$lsep.'px;"><img src="zamkniety_img/px.png" alt="" /></div>';
?>
<div style="float:left;width:<?=$ctr?>px;"><div class="text_body">
<?php
}
function disp_footer(): void {
    global $cfg,$tpl;
    $main=(int)($tpl['mainwidth']??780);
    $right=(int)($tpl['rightwidth']??0);
    $rsep=(int)($tpl['rightwidthsep']??0);
    echo'</div></div>';
    if($rsep>0)echo'<div style="float:left;width:'.$rsep.'px;"><img src="zamkniety_img/px.png" alt="" /></div>';
    if($right>0){
        echo'<div style="float:right;width:'.$right.'px;"><div class="right">';
        foreach(explode('|',$tpl['blockright']??'') as $bk)mini_magic($tpl[trim($bk)]??'');
        echo'</div></div>';
    }
    $m6=$cfg['m6']??'inf';
    $inf_url=(($cfg['m1']??0)==1||($cfg['m1']??0)==3)?'/'.$m6.'.html':'index.php?a=inf';
    $pp_url=(($cfg['m1']??0)==1||($cfg['m1']??0)==3)?'/pp.html':'index.php?a=pp';
    $lang_f = !empty($_SESSION['lang']) ? $_SESSION['lang'] : 'pl';
    $reg_txt = ($lang_f==='en') ? 'Terms of Service' : 'Regulamin';
    $pp_txt  = ($lang_f==='en') ? 'Privacy Policy'   : 'Polityka prywatności';
    ?>
</div>
<?php mini_magic($tpl['ads4']??'');?>
<div class="foot" style="float:left;width:<?=$main?>px;">
<?=$tpl['foot']??''?><br />
<a href="<?=htmlspecialchars($inf_url,ENT_QUOTES,'UTF-8')?>" class="foot_links"><?=htmlspecialchars($reg_txt,ENT_QUOTES,'UTF-8')?></a>
 | <a href="<?=htmlspecialchars($pp_url,ENT_QUOTES,'UTF-8')?>" class="foot_links"><?=htmlspecialchars($pp_txt,ENT_QUOTES,'UTF-8')?></a>
</div>
<?=$tpl['stat1']??''?><?=$tpl['stat2']??''?>
<?php
// Cookie notice
if (!empty($cfg['cookie_enable']) && $cfg['cookie_enable'] == '1') {
    $cookie_msg = htmlspecialchars($cfg['cookie_msg'] ?? 'Ta strona używa plików cookie.', ENT_QUOTES, 'UTF-8');
    $lang_c = !empty($_SESSION['lang']) ? $_SESSION['lang'] : 'pl';
    $cookie_close = ($lang_c === 'en') ? 'Close' : 'Zamknij';
    echo '<div id="zm-cookie-bar" style="display:none;position:fixed;bottom:0;left:50%;transform:translateX(-50%);z-index:9999;background:#1a3a6a;color:#fff;padding:14px 44px 14px 20px;border-radius:8px 8px 0 0;max-width:700px;width:90%;font-size:13px;box-shadow:0 -2px 12px rgba(0,0,0,0.2);">';
    echo '<span>' . $cookie_msg . '</span>';
    echo '<button onclick="zmCookieAccept()" style="position:absolute;top:8px;right:10px;background:none;border:none;color:#fff;font-size:18px;cursor:pointer;padding:4px 8px;line-height:1;" title="' . $cookie_close . '">&#10005;</button>';
    echo '</div>';
    echo '<script>
(function(){
    if(localStorage.getItem("zm_cookie_ok")!=="1"){
        document.getElementById("zm-cookie-bar").style.display="block";
    }
})();
function zmCookieAccept(){
    localStorage.setItem("zm_cookie_ok","1");
    document.getElementById("zm-cookie-bar").style.display="none";
}
</script>';
}
?>
</div></body></html>
<?php
}

// ============================================================
// INIT — PDO (NA KOŃCU, po definicjach funkcji)
// ============================================================
try {
    $pdo = new PDO(
        "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4",
        $dbuser,$dbpss,
        [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
         PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
         PDO::ATTR_EMULATE_PREPARES=>false]
    );
} catch(PDOException $e){
    die('<h2>B&#x0142;&aacute;d po&#x0142;&aacute;czenia z baz&aacute; danych.</h2><p>Sprawd&#x017A; dane w zamkniety_inc/config.php</p>');
}

$ile = ile($pdo,$prefix);
$cfg = cfg($pdo,$prefix);
$tpl = tpl($pdo,$prefix);

$target=''; $nofollow=''; $jsc=0;
if(($cfg['w2']??0)==1){
    if(($cfg['w3']??0)==1){$target=' target="_blank"';}
    elseif(($cfg['w3']??0)==2){$jsc=1;}
}
if(($cfg['w4']??0)==1)$nofollow=' rel="nofollow"';
