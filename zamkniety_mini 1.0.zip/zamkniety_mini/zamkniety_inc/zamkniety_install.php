<?php
// ============================================================
// Zamknięty mini v1.0 - Instalator
// PHP 8.4, PDO, UTF-8
// ============================================================

$stop   = '';
$done   = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['option'] ?? '') === 'install') {

    // --- Validate input ---
    $dbhost = trim($_POST['dbhost'] ?? '');
    $dbuser = trim($_POST['dbuser'] ?? '');
    $dbpss  = trim($_POST['dbpss']  ?? '');
    $dbname = trim($_POST['dbname'] ?? '');
    $prefix = preg_replace('/[^a-zA-Z0-9_]/', '', trim($_POST['prefix'] ?? 'zm_'));
    $login  = trim($_POST['login']  ?? '');
    $pass   = trim($_POST['pass']   ?? '');
    $dir    = trim($_POST['dir']    ?? '');

    if ($dbhost === '' || $dbuser === '' || $dbname === '') $stop = 'Wypełnij wszystkie pola bazy danych.';
    if ($login  === '' || $pass  === '')                    $stop = 'Podaj login i hasło administratora.';
    if ($dir    === '')                                     $stop = 'Podaj ścieżkę na dysku do katalogu głównego skryptu.';

    if (empty($stop)) {
        try {
            $pdo = new PDO(
                "mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4",
                $dbuser, $dbpss,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false]
            );
        } catch (PDOException $e) {
            $stop = 'Błąd połączenia z bazą: ' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8');
        }
    }

    if (empty($stop)) {
        // Drop existing tables for fresh install
        $tables = ['blokowane','filtr','ilosci','kategorie','konfiguracja','podkategorie','relacje','sesje','tagi','template','wizyty','wpisy'];
        foreach ($tables as $t) {
            $pdo->exec("DROP TABLE IF EXISTS `{$prefix}{$t}`");
        }

        // === CREATE TABLES ===
        $pdo->exec("CREATE TABLE `{$prefix}blokowane` (
            `id` int NOT NULL AUTO_INCREMENT,
            `adres` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}filtr` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` text,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $pdo->exec("INSERT INTO `{$prefix}filtr` VALUES ('frazy', NULL)");

        $pdo->exec("CREATE TABLE `{$prefix}ilosci` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `ilosc` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        foreach (['kat_a'=>12,'kat_n'=>0,'pod_a'=>36,'pod_n'=>0,'wpi_a'=>8,'wpi_n'=>0,'rel'=>11,'moje'=>0,'seslasttime'=>0,'sescount'=>0,'odwiedziny'=>0] as $n=>$v) {
            $pdo->prepare("INSERT INTO `{$prefix}ilosci` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}kategorie` (
            `id` int NOT NULL AUTO_INCREMENT,
            `nazwa` varchar(255) NOT NULL DEFAULT '',
            `data` int NOT NULL DEFAULT 0,
            `pod_a` int NOT NULL DEFAULT 0,
            `pod_n` int NOT NULL DEFAULT 0,
            `wpi_a` int NOT NULL DEFAULT 0,
            `wpi_n` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `nazwa` (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $sample_cats = [
            [1,'Sport, turystyka',3,1],[2,'Hobby, rozrywka',3,1],[3,'Zdrowie, uroda',3,1],
            [4,'Biznes, ekonomia',3,1],[5,'Budownictwo',3,1],[6,'Edukacja, nauka',3,1],
            [7,'Firmy wg branż',3,1],[8,'Internet, komputery',3,1],[9,'Reklama, marketing',3,1],
            [10,'Motoryzacja',3,1],[11,'Kultura, sztuka',3,1],[12,'RTV, AGD, GSM',3,1],
        ];
        $t = time();
        foreach ($sample_cats as [$id,$nazwa,$pod_a,$akt]) {
            $pdo->prepare("INSERT INTO `{$prefix}kategorie` (id,nazwa,data,pod_a,akt) VALUES (:id,:n,:d,:p,:a)")
                ->execute([':id'=>$id,':n'=>$nazwa,':d'=>$t,':p'=>$pod_a,':a'=>$akt]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}konfiguracja` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $cfg_vals = [
            'o1'=>'Nazwa Twojego katalogu','o2'=>'Opis Twojego katalogu','o3'=>'Słowa kluczowe',
            'o4'=>'http://'.$_SERVER['HTTP_HOST'],'f1'=>'index',
            'g1'=>'3','g2'=>'1','g3'=>'3','g4'=>'1','g5'=>'3',
            'k1'=>'3','k2'=>'1','k3'=>'3','p1'=>'10','p2'=>'1',
            'u1'=>'2','u2'=>'2','u3'=>'2','u4'=>'10','u5'=>'1',
            'w1'=>'1','w2'=>'1','w3'=>'2','w4'=>'2','w5'=>'1','w6'=>'1',
            'm1'=>'3','m2'=>'-','m3'=>'kat','m4'=>'pod','m5'=>'szcz','m6'=>'inf','m7'=>'1','m8'=>'',
            's1'=>'5000','s2'=>'googleNumerWeryf','s3'=>'1',
            'wp'=>'1','iw'=>'1','min'=>'1','pm'=>'1','loktag'=>'1','glotag'=>'0',
            'glotag_min'=>'0','glotag_ilo'=>'20','anchor'=>'0','anchor_ilo'=>'3','anchor_opi'=>'300',
            'dodkat'=>'0','pob_tresc'=>'0','rss'=>'0','rss_kanal'=>'','rss_link'=>'1','rss_ilo'=>'5',
            'link_zwr'=>'0','link_prz'=>'1','link_sor'=>'1','link_adres'=>'http://','link_opis'=>'Link zwrotny',
            'link_anchor_1'=>'Katalog Stron','link_anchor_2'=>'','link_anchor_3'=>'',
            'mail_nadaw'=>'katalog@katalog.pl','mail_odkog'=>'Administrator','mail_chars'=>'UTF-8',
            'maild_tem'=>'Wpis zatwierdzony!','maild_tre'=>'Witaj, Twój wpis został dodany do [MyBB[home]]. Zobacz: [MyBB[id]]',
            'mailu_tem'=>'Wpis odrzucony','mailu_tre'=>'Witaj, Twój wpis nie został dodany do [MyBB[home]].',
            'wersja'=>'zamkniety-mini-v1.0',
            'opr'=>'0','opr_key'=>'',
        ];
        foreach ($cfg_vals as $n => $v) {
            $pdo->prepare("INSERT INTO `{$prefix}konfiguracja` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}podkategorie` (
            `id` int NOT NULL AUTO_INCREMENT,
            `id_kat` int NOT NULL DEFAULT 0,
            `nazwa` varchar(255) NOT NULL DEFAULT '',
            `data` int NOT NULL DEFAULT 0,
            `wpi_a` int NOT NULL DEFAULT 0,
            `wpi_n` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`),
            KEY `nazwa` (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $sample_pods = [
            [6,'Chemia'],[12,'Aparaty cyfrowe'],[12,'Akcesoria gsm'],[8,'Pozycjonowanie'],[8,'Gry komputerowe'],
            [10,'Lakiernik'],[10,'Akcesoria samochodowe'],[6,'Angielski'],[6,'Astronomia'],[12,'Anteny satelitarne'],
            [8,'Katalogi stron'],[3,'Gabinety kosmetyczne'],[3,'Moda'],[2,'Sylwester'],[3,'Kobiety'],
            [10,'Auto ubezpieczenia'],[11,'Aktorzy'],[11,'Film'],[11,'Fotografia'],[1,'Agroturystyka'],
            [1,'Apartamenty'],[1,'Hotele'],[7,'Agencje promocji'],[7,'Aparatura pomiarowa'],[5,'Aranżacja wnętrz'],
            [4,'Agencje pracy'],[4,'Agencje reklamowe'],[2,'Dowcipy'],[2,'Imprezy'],[9,'Reklama'],
            [9,'Marketing'],[9,'Artykuły reklamowe'],[4,'Agencje interaktywne'],[5,'Architektura'],[5,'Automatyka'],
            [7,'Aranżacja wnętrz'],
        ];
        foreach ($sample_pods as [$kat_id,$nazwa]) {
            $pdo->prepare("INSERT INTO `{$prefix}podkategorie` (id_kat,nazwa,data,akt) VALUES (:k,:n,:d,1)")
                ->execute([':k'=>$kat_id,':n'=>$nazwa,':d'=>$t]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}relacje` (
            `id` int NOT NULL AUTO_INCREMENT,
            `id_kat` int NOT NULL DEFAULT 0,
            `id_pod` int NOT NULL DEFAULT 0,
            `id_wpi` int NOT NULL DEFAULT 0,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}sesje` (
            `ip` varchar(255) NOT NULL DEFAULT '',
            `host` varchar(255) NOT NULL DEFAULT '',
            `ua` varchar(255) NOT NULL DEFAULT '',
            `czas` varchar(10) NOT NULL DEFAULT '',
            `gdzie_jest` varchar(255) NOT NULL DEFAULT '',
            `sesref` text NOT NULL,
            `ident` varchar(255) NOT NULL DEFAULT '',
            `token` varchar(255) NOT NULL DEFAULT '',
            KEY `ident` (`ident`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Tabela unikalnych wizyt IP (jedna na IP na dzień)
        $pdo->exec("CREATE TABLE `{$prefix}wizyty` (
            `ip` varchar(45) NOT NULL DEFAULT '',
            `dzien` date NOT NULL,
            PRIMARY KEY (`ip`,`dzien`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}tagi` (
            `id` int NOT NULL AUTO_INCREMENT,
            `slowo` varchar(300) NOT NULL,
            `kod` varchar(300) NOT NULL,
            `ilosc` int NOT NULL DEFAULT 1,
            PRIMARY KEY (`id`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $pdo->exec("CREATE TABLE `{$prefix}template` (
            `nazwa` varchar(100) NOT NULL DEFAULT '',
            `wartosc` text NOT NULL,
            KEY `nazwa` (`nazwa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        $tpl_vals = [
            'top'           => '<span style="font-size:24px;font-weight:bold;color:#fff;">Zamknięty mini v1.0</span>',
            'foot'          => '',
            'blockleft'     => 'blok_menu|blok_wyszukiwarka',
            'blockright'    => '',
            'leftwidth'     => '180',
            'leftwidthsep'  => '5',
            'rightwidth'    => '0',
            'rightwidthsep' => '0',
            'mainwidth'     => '780',
            'center'        => '590',
            'welcome'       => '',
            'stat1'         => '',
            'stat2'         => '',
            'stat3'         => '',
            'ads1'          => '',
            'ads2'          => '',
            'ads3'          => '',
            'ads4'          => '',
            'inf'           => '<p>Tu wpisz treść regulaminu katalogu.</p>',
            'blok_wyszukiwarka' => '<php>formularz.php</php>',
            'blok_menu'     => '<div style="padding:8px 0;"><a href="/" class="in_link_home_cat">Strona główna</a><br /><a href="/inf.html" class="in_link_home_cat">Regulamin</a></div>',
        ];
        foreach ($tpl_vals as $n => $v) {
            $pdo->prepare("INSERT INTO `{$prefix}template` VALUES (:n,:v)")->execute([':n'=>$n,':v'=>$v]);
        }

        $pdo->exec("CREATE TABLE `{$prefix}wpisy` (
            `id` int NOT NULL AUTO_INCREMENT,
            `data` int NOT NULL DEFAULT 0,
            `tytul` varchar(255) NOT NULL DEFAULT '',
            `opis` text NOT NULL,
            `slowa` text NOT NULL,
            `url` varchar(255) NOT NULL DEFAULT '',
            `uri` varchar(255) NOT NULL DEFAULT '',
            `pr` int NOT NULL DEFAULT 0,
            `odslon` int NOT NULL DEFAULT 0,
            `klikniecia` int NOT NULL DEFAULT 0,
            `relacji` int NOT NULL DEFAULT 0,
            `akt` int NOT NULL DEFAULT 0,
            `moje` int NOT NULL DEFAULT 0,
            `mail` varchar(100) NOT NULL DEFAULT '',
            `rss` varchar(255) NOT NULL DEFAULT '',
            `link_zwrotny` varchar(255) NOT NULL DEFAULT '',
            PRIMARY KEY (`id`),
            KEY `tytul` (`tytul`),
            FULLTEXT KEY `search_idx` (`tytul`,`opis`,`slowa`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Write config.php
        $h_dir   = rtrim($dir, '/');
        $config  = "<?php\n";
        $config .= "\$home_dir = " . var_export($h_dir, true) . ";\n";
        $config .= "\$dbhost   = " . var_export($dbhost, true) . ";\n";
        $config .= "\$dbuser   = " . var_export($dbuser, true) . ";\n";
        $config .= "\$dbpss    = " . var_export($dbpss, true) . ";\n";
        $config .= "\$dbname   = " . var_export($dbname, true) . ";\n";
        $config .= "\$prefix   = " . var_export($prefix, true) . ";\n";
        $config .= "\$login    = " . var_export($login, true) . ";\n";
        $config .= "\$pass     = " . var_export($pass, true) . ";\n";

        $config_path = __DIR__ . '/config.php';
        if (file_put_contents($config_path, $config) === false) {
            $stop = 'Nie można zapisać pliku config.php. Sprawdź uprawnienia katalogu zamkniety_inc/.';
        } else {
            $done = true;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>Instalacja — Zamknięty mini v1.0</title>
<style>
body { font-family: Arial, sans-serif; font-size:13px; background:#dce9f5; color:#1a2a3a; padding:30px; }
h1 { color:#1a4a80; }
.box { background:rgba(255,255,255,0.8); border:1px solid rgba(60,130,200,0.3); border-radius:8px; padding:24px; max-width:520px; margin:0 auto; }
label { display:block; margin-top:10px; font-weight:bold; }
input[type=text],input[type=password] { width:100%; padding:6px; border:1px solid #a0c0e0; border-radius:3px; margin-top:3px; }
button { margin-top:16px; padding:8px 20px; background:#2a6ab0; color:#fff; border:none; border-radius:4px; font-size:13px; cursor:pointer; }
.err { color:red; margin-bottom:10px; }
.ok  { color:green; }
</style>
</head>
<body>
<div class="box">
<h1>Zamknięty mini v1.0 — Instalacja</h1>

<?php if ($done): ?>
<p class="ok"><b>Instalacja zakończona pomyślnie!</b></p>
<p>Plik <code>config.php</code> został zapisany w katalogu <code>zamkniety_inc/</code>.</p>
<p><b>Teraz usuń plik <code>zamkniety_inc/zamkniety_install.php</code></b> aby uruchomić skrypt.</p>
<p><a href="../index.php">Przejdź do katalogu</a> | <a href="../zamkniety_admin/">Panel admina</a></p>

<?php else: ?>
<?php if ($stop): ?><p class="err"><?= htmlspecialchars($stop, ENT_QUOTES, 'UTF-8') ?></p><?php endif; ?>

<form method="post" action="zamkniety_install.php">
<input type="hidden" name="option" value="install" />

<label>Host bazy danych:</label>
<input type="text" name="dbhost" value="<?= htmlspecialchars($_POST['dbhost'] ?? 'localhost', ENT_QUOTES, 'UTF-8') ?>" />

<label>Użytkownik bazy:</label>
<input type="text" name="dbuser" value="<?= htmlspecialchars($_POST['dbuser'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />

<label>Hasło bazy:</label>
<input type="password" name="dbpss" />

<label>Nazwa bazy:</label>
<input type="text" name="dbname" value="<?= htmlspecialchars($_POST['dbname'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />

<label>Prefiks tabel (np. <code>zm_</code>):</label>
<input type="text" name="prefix" value="<?= htmlspecialchars($_POST['prefix'] ?? 'zm_', ENT_QUOTES, 'UTF-8') ?>" />

<label>Ścieżka na dysku (bez slash na końcu, np. <code>/home/user/public_html</code>):</label>
<input type="text" name="dir" value="<?= htmlspecialchars($_POST['dir'] ?? '', ENT_QUOTES, 'UTF-8') ?>" />

<label>Login administratora:</label>
<input type="text" name="login" value="<?= htmlspecialchars($_POST['login'] ?? 'admin', ENT_QUOTES, 'UTF-8') ?>" />

<label>Hasło administratora:</label>
<input type="password" name="pass" />

<button type="submit">Zainstaluj</button>
</form>
<?php endif; ?>
</div>
</body>
</html>
