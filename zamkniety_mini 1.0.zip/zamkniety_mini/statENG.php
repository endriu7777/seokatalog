<?php
// statENG.php — Directory statistics (English version)
// Usage in ad box in Appearance: <php>statENG.php</php>

global $pdo, $prefix;
if (empty($pdo) || empty($prefix)) return;

// Load counters from ilosci table
$_se = [];
foreach ($pdo->query("SELECT nazwa, ilosc FROM {$prefix}ilosci") as $r) {
    $_se[$r['nazwa']] = (int)$r['ilosc'];
}

// Daily visits (sessions from last 24h)
try {
    $_sd = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}sesje WHERE czas > :t");
    $_sd->execute([':t' => time() - 86400]);
    $_se_day = (int)$_sd->fetchColumn();
} catch (Exception $e) { $_se_day = 0; }

$_se_total  = (int)($_se['odwiedziny'] ?? 0);
$_se_online = (int)($_se['sescount']   ?? 0);
$_se_wpi_a  = (int)($_se['wpi_a']     ?? 0);
$_se_wpi_n  = (int)($_se['wpi_n']     ?? 0);
$_se_kat    = (int)($_se['kat_a'] ?? 0) + (int)($_se['kat_n'] ?? 0);
$_se_pod    = (int)($_se['pod_a'] ?? 0) + (int)($_se['pod_n'] ?? 0);
?>
<div class="stat_box">
<div class="stat_title">&#128202; Directory Statistics</div>
<table class="stat_table">
<tr><td class="stat_label">Active entries:</td><td class="stat_val"><?php echo $_se_wpi_a; ?></td></tr>
<tr><td class="stat_label">Inactive entries:</td><td class="stat_val"><?php echo $_se_wpi_n; ?></td></tr>
<tr><td class="stat_label">Categories:</td><td class="stat_val"><?php echo $_se_kat; ?></td></tr>
<tr><td class="stat_label">Subcategories:</td><td class="stat_val"><?php echo $_se_pod; ?></td></tr>
<tr class="stat_sep"><td class="stat_label">Total visits:</td><td class="stat_val"><?php echo number_format($_se_total, 0, '.', ','); ?></td></tr>
<tr><td class="stat_label">Today's visits:</td><td class="stat_val"><?php echo $_se_day; ?></td></tr>
<tr><td class="stat_label">Online now:</td><td class="stat_val"><span class="stat_online">&#9679; <?php echo $_se_online; ?></span></td></tr>
</table>
</div>
<style>.stat_box{font-size:12px;color:#2a4a6a;margin:4px 0}.stat_title{font-weight:bold;font-size:13px;color:#1a3a6a;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid rgba(100,160,220,.3)}.stat_table{width:100%;border-collapse:collapse}.stat_label{padding:2px 4px 2px 0;color:#5a7a9a;vertical-align:top}.stat_val{padding:2px 0;font-weight:bold;color:#1a3a6a;text-align:right;white-space:nowrap}.stat_sep td{border-top:1px solid rgba(100,160,220,.2);padding-top:5px}.stat_online{color:#2a8a2a;font-weight:bold}</style>
