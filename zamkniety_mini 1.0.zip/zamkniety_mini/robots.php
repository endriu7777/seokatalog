<?php
// Zamknięty mini v1.0 - robots.php (zliczanie wizyt robotów)
// Netsprint i Szukacz zostały usunięte zgodnie z wymaganiami.
if (file_exists('rob.db')) {
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    $bots = ['googlebot' => 'Google', 'bingbot' => 'Bing', 'yahoo' => 'Yahoo', 'duckduckbot' => 'DuckDuckGo'];
    $found = '';
    foreach ($bots as $needle => $name) {
        if (str_contains($ua, $needle)) { $found = $name; break; }
    }
    if ($found !== '') {
        $data = @file_get_contents('rob.db');
        $counts = $data ? unserialize($data) : [];
        if (!is_array($counts)) $counts = [];
        $counts[$found] = ($counts[$found] ?? 0) + 1;
        @file_put_contents('rob.db', serialize($counts));
    }
}
