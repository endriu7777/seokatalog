<?php
// Zamknięty mini v1.2 - mail_dodano.php
// Wysyła e-mail do użytkownika po zatwierdzeniu wpisu

if (empty($wpis) || empty($cfg)) return;

$temat = $cfg['maild_tem'] ?? 'Wpis zatwierdzony!';
$body  = $cfg['maild_tre'] ?? 'Witaj, Twój wpis został dodany.';

$wpis_id  = (int)($wpis['id'] ?? 0);
// szcz_link already returns leading '/', rtrim o4 to avoid double slash
$wpis_url = rtrim($cfg['o4'] ?? '', '/') . szcz_link($wpis_id, $wpis['tytul'] ?? '', $cfg);

$body = str_replace('[MyBB[email]]', $wpis['mail'] ?? '', $body);
$body = str_replace('[MyBB[home]]',  $cfg['o4'] ?? '', $body);
$body = str_replace('[MyBB[id]]',    $wpis_url,         $body);
$body = str_replace('[MyBB[tytul]]', $wpis['tytul'] ?? '', $body);

$html_mail = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</body></html>';

if (!empty($wpis['mail']) && filter_var($wpis['mail'], FILTER_VALIDATE_EMAIL)) {
    zm_send_mail($cfg, $wpis['mail'], $temat, $html_mail);
}
