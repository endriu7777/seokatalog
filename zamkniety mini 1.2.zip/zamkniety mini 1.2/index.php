<?php
// ============================================================
// Zamknięty mini v1.0
// ============================================================

// --- Szybka obsługa redirectów (PRZED session_start) --------
$_early_a = $_GET['a'] ?? '';
if ($_early_a === 'go' || $_early_a === 'klik' || $_early_a === 'rss') {
    if (file_exists("zamkniety_inc/config.php") && !file_exists("zamkniety_inc/zamkniety_install.php")) {
        require_once("zamkniety_inc/config.php");
        // Minimal PDO init for redirects
        try {
            $pdo = new PDO("mysql:host={$dbhost};dbname={$dbname};charset=utf8mb4", $dbuser, $dbpss,
                [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
        } catch(PDOException $e) { exit; }
        if ($_early_a === 'go')   { include("zamkniety_disp/go.php"); exit; }
        if ($_early_a === 'klik') { include("zamkniety_disp/klik.php"); exit; }
        if ($_early_a === 'rss')  { include("zamkniety_disp/rss.php"); exit; }
    }
    exit;
}
// --- Koniec szybkiej obsługi --------------------------------


if (file_exists("zamkniety_inc/config.php")) {
    if (!file_exists("zamkniety_inc/zamkniety_install.php")) {

        session_start();
        $sid = session_id();

        // Frontend language switcher
        if (!empty($_GET['set_lang']) && in_array($_GET['set_lang'], ['pl','en'], true)) {
            $_SESSION['lang'] = $_GET['set_lang'];
            $back = strtok($_SERVER['HTTP_REFERER'] ?? 'index.php', '?') ?: 'index.php';
            header('Location: ' . $back); exit;
        }

        require_once("zamkniety_inc/config.php");
        require_once("zamkniety_disp/funkcje.php");

        // Redirect only if o4 is set and differs AND we're not already on the right host
        // (Disabled by default to avoid redirect loops during setup)
        // Uncomment and configure only when o4 is correctly set in admin config
        /*
        if (!empty($cfg['o4']) && $cfg['o4'] !== 'http://' && !str_contains($cfg['o4'], $_SERVER['HTTP_HOST'] ?? '')) {
            header("Location: " . $cfg['o4']);
            exit;
        }
        */

        $a = isset($_GET['a']) ? $_GET['a'] : '';

        switch ($a) {

            default:
                include("zamkniety_disp/home.php");
                break;

            case "kat":
                include("zamkniety_disp/kat.php");
                break;

            case "pod":
                include("zamkniety_disp/pod.php");
                break;

            case "szcz":
                include("zamkniety_disp/szcz.php");
                break;

            case "inf":
                include("zamkniety_disp/inf.php");
                break;

            case "pp":
                include("zamkniety_disp/pp.php");
                break;

            case "paypal":
                include("zamkniety_disp/paypal.php");
                break;

            case "paypal_ipn":
                include("zamkniety_disp/paypal_ipn.php");
                break;

            case "stripe":
                include("zamkniety_disp/stripe.php");
                break;

            case "stripe_webhook":
                include("zamkniety_disp/stripe_webhook.php");
                break;

            case "p24":
                include("zamkniety_disp/p24.php");
                break;

            case "p24_ipn":
                include("zamkniety_disp/p24_ipn.php");
                break;

            case "op":
                include("zamkniety_disp/op.php");
                break;

            case "search":
                include("zamkniety_disp/search.php");
                break;

            case "go":
            case "klik":
                // Obsługiwane wcześniej (przed session_start)
                header('Location: /'); exit;
                break;

            case "pr":
                include("zamkniety_disp/prz.php");
                break;

            case "token":
                include("zamkniety_disp/token.php");
                break;

            case "rss":
                // Obsługiwany wcześniej (przed session_start)
                header('Location: /'); exit;
                break;

            case "mapa":
                include("zamkniety_disp/mapa.php");
                break;
        }

    } else {
        require_once("zamkniety_inc/zamkniety_install.php");
    }
} else {
    echo "Plik konfiguracyjny nie istnieje. Przeprowadź instalację.";
}
?>
