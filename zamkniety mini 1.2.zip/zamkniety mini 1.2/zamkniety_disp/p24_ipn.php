<?php
// Zamknięty mini v1.2 - p24_ipn.php
// Przelewy24 IPN (notification) handler

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$raw    = file_get_contents('php://input');
$params = [];
if (!empty($raw)) {
    @json_decode($raw) ? ($params = json_decode($raw, true)) : parse_str($raw, $params);
}
if (empty($params)) $params = $_POST;

$mid     = $cfg['p24_merchant_id'] ?? '';
$crc     = $cfg['p24_crc']         ?? '';
$amount  = (int)($cfg['p24_price'] ?? 0);
$currency= $cfg['p24_currency']    ?? 'PLN';
$mode    = $cfg['p24_mode']        ?? 'sandbox';
$api_url = ($mode === 'live') ? 'https://secure.przelewy24.pl' : 'https://sandbox.przelewy24.pl';

$session_id = $params['sessionId'] ?? '';
$order_id   = $params['orderId']   ?? '';
$p24_amount = (int)($params['amount'] ?? 0);

if (!$session_id) { echo 'OK'; exit; }

// Verify amount
if ($amount > 0 && $p24_amount !== $amount) { echo 'OK'; exit; }

// Find pending record
$pending_row = $pdo->prepare("SELECT * FROM {$prefix}payments_pending WHERE session_id=:sid LIMIT 1");
$pending_row->execute([':sid' => $session_id]);
$pending = $pending_row->fetch();
if (!$pending) { echo 'OK'; exit; }

// Verify transaction with P24 API
$pos_id   = $cfg['p24_pos_id'] ?? $mid;
$api_key  = $cfg['p24_api_key'] ?? '';
$sign_data = json_encode([
    'sessionId'  => $session_id,
    'orderId'    => (int)$order_id,
    'amount'     => $p24_amount,
    'currency'   => $currency,
    'crc'        => $crc,
], JSON_UNESCAPED_SLASHES);
$sign = hash('sha384', $sign_data);

$verify_data = ['merchantId'=>(int)$mid,'posId'=>(int)($pos_id?:$mid),'sessionId'=>$session_id,'amount'=>$p24_amount,'currency'=>$currency,'orderId'=>(int)$order_id,'sign'=>$sign];
$auth = base64_encode($pos_id . ':' . $api_key);
$ctx = stream_context_create(['http'=>['method'=>'PUT','header'=>"Content-Type: application/json\r\nAuthorization: Basic {$auth}\r\n",'content'=>json_encode($verify_data),'timeout'=>15,'ignore_errors'=>true]]);
$resp = @file_get_contents($api_url . '/api/v1/transaction/verify', false, $ctx);
$result = $resp ? @json_decode($resp, true) : null;

if (!empty($result['data']['status']) && $result['data']['status'] === 'success') {
    zm_payment_activate($pdo, $prefix, $cfg, $pending['token']);
}

echo 'OK';
exit;
