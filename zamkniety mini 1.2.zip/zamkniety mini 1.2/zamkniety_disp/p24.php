<?php
// Zamknięty mini v1.2 - p24.php
// Przelewy24 payment integration

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$action  = $_GET['action'] ?? '';
$base    = rtrim($cfg['o4'] ?? ('http://'.($_SERVER['HTTP_HOST']??'')), '/');
$mode    = $cfg['p24_mode'] ?? 'sandbox';
$api_url = ($mode === 'live') ? 'https://secure.przelewy24.pl' : 'https://sandbox.przelewy24.pl';

function p24_api(string $url, array $data, array $cfg): ?array {
    $mid      = $cfg['p24_merchant_id'] ?? '';
    $pos_id   = $cfg['p24_pos_id']      ?? $mid;
    $api_key  = $cfg['p24_api_key']     ?? '';
    $auth     = base64_encode($pos_id . ':' . $api_key);
    $ctx = stream_context_create(['http' => [
        'method'        => 'POST',
        'header'        => "Content-Type: application/json\r\nAuthorization: Basic {$auth}\r\n",
        'content'       => json_encode($data),
        'timeout'       => 15,
        'ignore_errors' => true,
    ]]);
    $resp = @file_get_contents($url, false, $ctx);
    return $resp ? @json_decode($resp, true) : null;
}

// ============================================================
// REGISTER & REDIRECT to Przelewy24
// ============================================================
if ($action === 'pay') {
    $token    = $_GET['token'] ?? '';
    if (!$token) { header('Location: index.php'); exit; }

    $pending_row = $pdo->prepare("SELECT * FROM {$prefix}payments_pending WHERE token=:tok LIMIT 1");
    $pending_row->execute([':tok'=>$token]);
    $pending = $pending_row->fetch();
    if (!$pending) { header('Location: index.php'); exit; }

    $d        = json_decode($pending['data'], true);
    $mid      = $cfg['p24_merchant_id'] ?? '';
    $pos_id   = $cfg['p24_pos_id']      ?? $mid;
    $amount   = (int)($cfg['p24_price'] ?? 0);
    $currency = $cfg['p24_currency']    ?? 'PLN';
    $crc      = $cfg['p24_crc']         ?? '';
    $email    = $d['email'] ?? 'noreply@example.com';
    $desc     = 'Dodanie wpisu do katalogu';
    $notify   = $base . '/index.php?a=p24_ipn';
    $return   = $base . '/index.php?a=p24&action=success&token=' . urlencode($token);
    $session  = 'zm_' . $token;

    // Sign: hash(sha384, json of specific fields)
    $sign_data = json_encode([
        'sessionId'  => $session,
        'merchantId' => (int)$mid,
        'amount'     => $amount,
        'currency'   => $currency,
        'crc'        => $crc,
    ], JSON_UNESCAPED_SLASHES);
    $sign = hash('sha384', $sign_data);

    $register_data = [
        'merchantId'  => (int)$mid,
        'posId'       => (int)($pos_id ?: $mid),
        'sessionId'   => $session,
        'amount'      => $amount,
        'currency'    => $currency,
        'description' => $desc,
        'email'       => $email,
        'country'     => 'PL',
        'language'    => 'pl',
        'urlReturn'   => $return,
        'urlStatus'   => $notify,
        'sign'        => $sign,
    ];

    $result = p24_api($api_url . '/api/v1/transaction/register', $register_data, $cfg);

    if (!empty($result['data']['token'])) {
        $p24_token = $result['data']['token'];
        $pdo->prepare("UPDATE {$prefix}payments_pending SET session_id=:sid WHERE token=:tok")
            ->execute([':sid'=>$session, ':tok'=>$token]);
        $redirect = $api_url . '/trnRequest/' . $p24_token;
        header('Location: ' . $redirect); exit;
    }

    // Error
    disp_header(fl('error_title'), '', '');
    echo '<div class="text_body_h1">' . fl('error_title') . '</div>';
    echo '<p>' . htmlspecialchars($cfg['pp_msg_error'] ?? 'Payment error.', ENT_QUOTES, 'UTF-8') . '</p>';
    if (!empty($result['error'])) echo '<p><small>' . htmlspecialchars(is_string($result['error']) ? $result['error'] : json_encode($result['error']), ENT_QUOTES, 'UTF-8') . '</small></p>';
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);
    disp_footer();
    exit;
}

// ============================================================
// SUCCESS — return from Przelewy24 (user redirect, not IPN)
// ============================================================
if ($action === 'success') {
    $msg = htmlspecialchars($cfg['pp_msg_pending'] ?? 'Płatność przyjęta. Twój wpis zostanie aktywowany wkrótce.', ENT_QUOTES, 'UTF-8');
    disp_header(fl('info_title'), '', '');
    echo '<div class="text_body_h1">✅ ' . fl('info_title') . '</div><p>' . $msg . '</p>';
    echo '<p><a href="' . htmlspecialchars($base, ENT_QUOTES, 'UTF-8') . '" class="button">← ' . fl('info_title') . '</a></p>';
    disp_footer();
    exit;
}

header('Location: index.php');
exit;
