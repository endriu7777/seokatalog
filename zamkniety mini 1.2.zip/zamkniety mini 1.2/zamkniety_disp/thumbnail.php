<?php
// Zamknięty mini v1.2 - thumbnail.php
// Bezpieczne generowanie miniaturek stron www
// Zabezpieczenia: tylko obrazki, walidacja GD, losowa nazwa, .htaccess protection

/**
 * Pobiera i zapisuje miniaturkę dla podanego URL
 * Zwraca nazwę pliku (np. "abc123.jpg") lub pusty string przy błędzie
 *
 * Metody (w kolejności prób):
 * 1. og:image z meta tagów strony
 * 2. Favicon (jako mała ikona)
 * 3. Fallback: pusty string (pokaże statyczne SVG)
 */
function zm_fetch_thumbnail(string $site_url, string $home_dir): string
{
    $thumb_dir = rtrim($home_dir, '/') . '/miniaturki';

    // Upewnij się że katalog istnieje i jest zabezpieczony
    zm_ensure_thumb_dir($thumb_dir);

    // 1. Spróbuj og:image z HTML strony
    $ctx = stream_context_create(['http' => [
        'timeout'       => 6,
        'ignore_errors' => true,
        'user_agent'    => 'Mozilla/5.0 (compatible; ZamknietyCatalog/1.2)',
    ]]);
    $html = @file_get_contents($site_url, false, $ctx);

    if ($html) {
        $html_flat = str_replace(["\r", "\n"], ' ', $html);
        // og:image
        if (preg_match('#<meta[^>]+property=["\']og:image["\'][^>]+content=["\'](https?://[^"\'>\s]+)["\']#si', $html_flat, $m) ||
            preg_match('#<meta[^>]+content=["\'](https?://[^"\'>\s]+)["\'][^>]+property=["\']og:image["\']#si', $html_flat, $m)) {
            $img_url = html_entity_decode($m[1], ENT_QUOTES, 'UTF-8');
            $result = zm_download_validate_save($img_url, $thumb_dir, 160, 120);
            if ($result) return $result;
        }
    }

    // 2. Favicon jako miniaturka (mała, ale lepsza niż nic)
    $parsed = parse_url($site_url);
    $base   = ($parsed['scheme'] ?? 'http') . '://' . ($parsed['host'] ?? '');
    $favicon_urls = [
        $base . '/favicon.ico',
        $base . '/favicon.png',
        'https://www.google.com/s2/favicons?domain=' . urlencode($parsed['host'] ?? '') . '&sz=64',
    ];
    foreach ($favicon_urls as $fav_url) {
        $result = zm_download_validate_save($fav_url, $thumb_dir, 64, 64);
        if ($result) return $result;
    }

    return '';
}

/**
 * Pobiera obrazek z URL, waliduje go przez GD, zapisuje bezpiecznie
 * Zwraca nazwę pliku lub pusty string
 */
function zm_download_validate_save(string $img_url, string $thumb_dir, int $max_w, int $max_h): string
{
    if (!filter_var($img_url, FILTER_VALIDATE_URL)) return '';
    if (!preg_match('#^https?://#', $img_url)) return '';

    $ctx = stream_context_create(['http' => [
        'timeout'       => 5,
        'ignore_errors' => true,
        'follow_location' => true,
        'max_redirects' => 3,
        'user_agent'    => 'Mozilla/5.0 (compatible; ZamknietyCatalog/1.2)',
    ]]);
    $raw = @file_get_contents($img_url, false, $ctx);
    if (!$raw || strlen($raw) < 100) return '';

    // WALIDACJA BEZPIECZEŃSTWA — tylko obrazki przez GD
    // Sprawdź magic bytes
    $magic = substr($raw, 0, 12);
    $is_image = (
        substr($magic, 0, 3) === "\xFF\xD8\xFF"   ||  // JPEG
        substr($magic, 0, 8) === "\x89PNG\r\n\x1A\n" || // PNG
        substr($magic, 0, 6) === 'GIF87a' || substr($magic, 0, 6) === 'GIF89a' || // GIF
        substr($magic, 0, 4) === 'RIFF'            ||  // WEBP
        substr($magic, 0, 4) === "\x00\x00\x01\x00"    // ICO
    );
    if (!$is_image) return '';

    // Sprawdź przez GD (ostateczna walidacja - GD nie wczyta PHP jako obrazek)
    if (!function_exists('imagecreatefromstring')) return '';
    $img_src = @imagecreatefromstring($raw);
    if (!$img_src) return '';

    $src_w = imagesx($img_src);
    $src_h = imagesy($img_src);

    // Twórz miniaturkę 160x120 (zachowaj proporcje, background #e8f0f8)
    $thumb_w = 160;
    $thumb_h = 120;
    $ratio   = min($thumb_w / max(1, $src_w), $thumb_h / max(1, $src_h));
    $new_w   = (int)round($src_w * $ratio);
    $new_h   = (int)round($src_h * $ratio);
    $off_x   = (int)(($thumb_w - $new_w) / 2);
    $off_y   = (int)(($thumb_h - $new_h) / 2);

    $canvas = imagecreatetruecolor($thumb_w, $thumb_h);
    $bg = imagecolorallocate($canvas, 232, 240, 248); // #e8f0f8
    imagefill($canvas, 0, 0, $bg);
    imagecopyresampled($canvas, $img_src, $off_x, $off_y, 0, 0, $new_w, $new_h, $src_w, $src_h);
    imagedestroy($img_src);

    // Zapisz jako JPEG (zawsze .jpg — niezależnie od źródła)
    $filename = bin2hex(random_bytes(12)) . '.jpg';
    $filepath = $thumb_dir . '/' . $filename;
    $ok = imagejpeg($canvas, $filepath, 85);
    imagedestroy($canvas);

    if (!$ok || !file_exists($filepath)) return '';

    // Dodatkowa weryfikacja — getimagesize na zapisanym pliku
    $info = @getimagesize($filepath);
    if (!$info) {
        @unlink($filepath);
        return '';
    }

    return $filename;
}

/**
 * Upewnia się że katalog miniaturki istnieje i jest zabezpieczony
 */
function zm_ensure_thumb_dir(string $thumb_dir): void
{
    if (!is_dir($thumb_dir)) {
        @mkdir($thumb_dir, 0755, true);
    }
    // Zapisz .htaccess blokujący wykonanie PHP
    $htaccess = $thumb_dir . '/.htaccess';
    if (!file_exists($htaccess)) {
        file_put_contents($htaccess,
            "# Blokuj wykonanie skryptów PHP w tym katalogu\n" .
            "<FilesMatch \"\\.ph(p[3-9]?|tml|ar)$\">\n" .
            "    Deny from all\n" .
            "</FilesMatch>\n" .
            "<IfModule mod_php.c>\n" .
            "    php_flag engine off\n" .
            "</IfModule>\n" .
            "Options -ExecCGI\n" .
            "AddHandler cgi-script .php .php3 .php4 .php5 .phtml .pl .py .rb\n"
        );
    }
    // index.php blokujący listowanie
    $index = $thumb_dir . '/index.php';
    if (!file_exists($index)) {
        file_put_contents($index, '<?php http_response_code(403); exit;');
    }
}

/**
 * Zwraca URL do miniaturki lub null
 */
function zm_thumb_url(string $filename, array $cfg): ?string
{
    if (empty($filename)) return null;
    $base = rtrim($cfg['o4'] ?? '', '/');
    return $base . '/miniaturki/' . $filename;
}

/**
 * Usuwa plik miniaturki z dysku
 */
function zm_thumb_delete(string $filename, string $home_dir): void
{
    if (empty($filename)) return;
    $path = rtrim($home_dir, '/') . '/miniaturki/' . $filename;
    if (file_exists($path) && preg_match('/^[a-f0-9]{24}\.jpg$/', $filename)) {
        @unlink($path);
    }
}
