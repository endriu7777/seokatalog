<?php
// Zamknięty mini v1.2 - paypal.php
// PayPal Standard payment handler

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$action = $_GET['action'] ?? '';
$base   = rtrim($cfg['o4'] ?? ('http://'.($_SERVER['HTTP_HOST']??'')), '/');

if ($action === 'pay') {
    $token    = $_GET['token'] ?? '';
    if (!$token) { header('Location: index.php'); exit; }

    $mode     = $cfg['pp_mode']      ?? 'sandbox';
    $email    = $cfg['pp_email']     ?? '';
    $price    = number_format((float)($cfg['pp_price'] ?? 0), 2, '.', '');
    $currency = $cfg['pp_currency']  ?? 'PLN';
    $item     = $cfg['pp_item_name'] ?? 'Directory entry submission';
    $pp_url   = ($mode === 'live') ? 'https://www.paypal.com/cgi-bin/webscr' : 'https://www.sandbox.paypal.com/cgi-bin/webscr';
    $return   = $base . '/index.php?a=paypal&action=success&token=' . urlencode($token);
    $cancel   = $base . '/index.php?a=paypal&action=cancel&token=' . urlencode($token);
    $ipn      = $base . '/index.php?a=paypal_ipn';

    // Update pending with token reference in session_id
    $pdo->prepare("UPDATE {$prefix}payments_pending SET session_id=:sid WHERE token=:tok")
        ->execute([':sid'=>'pp_'.$token, ':tok'=>$token]);

    disp_header('PayPal', '', '');
    echo '<p>' . htmlspecialchars($cfg['pp_msg_pending'] ?? 'Redirecting to PayPal...', ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<form id="ppf" action="' . htmlspecialchars($pp_url, ENT_QUOTES, 'UTF-8') . '" method="post">';
    echo '<input type="hidden" name="cmd"           value="_xclick">';
    echo '<input type="hidden" name="business"      value="' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="item_name"     value="' . htmlspecialchars($item, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="item_number"   value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="custom"        value="' . htmlspecialchars($token, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="amount"        value="' . $price . '">';
    echo '<input type="hidden" name="currency_code" value="' . htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="return"        value="' . htmlspecialchars($return, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="cancel_return" value="' . htmlspecialchars($cancel, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="notify_url"    value="' . htmlspecialchars($ipn, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="charset"       value="UTF-8">';
    echo '<input type="hidden" name="no_shipping"   value="1">';
    echo '<noscript><button type="submit">→ PayPal</button></noscript>';
    echo '</form><script>document.getElementById("ppf").submit();</script>';
    disp_footer();
    exit;
}

if ($action === 'success') {
    $msg = htmlspecialchars($cfg['pp_msg_pending'] ?? 'Payment received. Your entry will be activated shortly.', ENT_QUOTES, 'UTF-8');
    disp_header(fl('info_title'), '', '');
    echo '<div class="text_body_h1">✅ ' . fl('info_title') . '</div><p>' . $msg . '</p>';
    echo '<p><a href="' . htmlspecialchars($base, ENT_QUOTES, 'UTF-8') . '" class="button">← ' . fl('info_title') . '</a></p>';
    disp_footer(); exit;
}

if ($action === 'cancel') {
    $token = $_GET['token'] ?? '';
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);
    $msg = htmlspecialchars($cfg['pp_msg_error'] ?? 'Payment cancelled.', ENT_QUOTES, 'UTF-8');
    disp_header(fl('error_title'), '', '');
    echo '<div class="text_body_h1">⚠️ ' . fl('error_title') . '</div><p>' . $msg . '</p>';
    echo '<p><a href="index.php" class="button">← ' . fl('info_title') . '</a></p>';
    disp_footer(); exit;
}

header('Location: index.php'); exit;
