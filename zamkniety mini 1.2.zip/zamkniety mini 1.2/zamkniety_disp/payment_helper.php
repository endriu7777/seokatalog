<?php
// Zamknięty mini v1.2 - payment_helper.php
// Wspólne funkcje obsługi płatności

/**
 * Zapisuje dane wpisu tymczasowo w payments_pending
 * Zwraca token do identyfikacji transakcji
 */
function zm_payment_save_pending(PDO $pdo, string $prefix, string $provider, string $session_id,
    int $cat_id, int $sub_id, array $entry_data): string
{
    // Usuń stare (>2h)
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE created < :t")
        ->execute([':t' => time() - 7200]);

    $token = bin2hex(random_bytes(32));
    $pdo->prepare("INSERT INTO {$prefix}payments_pending
        (token,provider,session_id,cat_id,sub_id,data,created)
        VALUES (:tok,:prov,:sid,:cat,:sub,:data,:now)")
        ->execute([
            ':tok'  => $token,
            ':prov' => $provider,
            ':sid'  => $session_id,
            ':cat'  => $cat_id,
            ':sub'  => $sub_id,
            ':data' => json_encode($entry_data, JSON_UNESCAPED_UNICODE),
            ':now'  => time(),
        ]);
    return $token;
}

/**
 * Po udanej płatności — pobiera dane z pending i zapisuje wpis do bazy
 * Zwraca id nowego wpisu lub false
 */
function zm_payment_activate(PDO $pdo, string $prefix, array $cfg, string $token): int|false
{
    $row = $pdo->prepare("SELECT * FROM {$prefix}payments_pending WHERE token=:tok LIMIT 1");
    $row->execute([':tok' => $token]);
    $pending = $row->fetch();
    if (!$pending) return false;

    $d       = json_decode($pending['data'], true);
    $cat_id  = (int)$pending['cat_id'];
    $sub_id  = (int)$pending['sub_id'];
    $akt     = ($cfg['u3'] == 1) ? '1' : '0';
    $akt2    = ($cfg['u3'] == 1) ? 'wpi_a' : 'wpi_n';
    $tytul   = $d['tytul']      ?? '';
    $opis    = $d['opis']       ?? '';
    $slowa   = $d['slowa']      ?? '';
    $url     = $d['url']        ?? '';
    $uri     = $d['uri']        ?? '';
    $email   = $d['email']      ?? '';
    $rss     = $d['rss']        ?? '';
    $lz      = $d['link_zwr']   ?? '';

    // Check for duplicate
    $dup = $pdo->prepare("SELECT id FROM {$prefix}wpisy WHERE url=:u AND uri=:uri LIMIT 1");
    $dup->execute([':u'=>$url, ':uri'=>$uri]);
    if ($dup->fetch()) {
        $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);
        return false;
    }

    if (!empty($cfg['pm']) && $cfg['pm'] == 1) {
        $stmt = $pdo->prepare("INSERT INTO {$prefix}wpisy (data,tytul,opis,slowa,url,uri,pr,relacji,akt,mail,rss,link_zwrotny) VALUES (:d,:t,:o,:s,:u,:uri,'-9','1',:akt,:m,:rss,:lz)");
        $stmt->execute([':d'=>time(),':t'=>$tytul,':o'=>$opis,':s'=>$slowa,':u'=>$url,':uri'=>$uri,':akt'=>$akt,':m'=>$email,':rss'=>$rss,':lz'=>$lz]);
    } else {
        $stmt = $pdo->prepare("INSERT INTO {$prefix}wpisy (data,tytul,opis,slowa,url,uri,pr,relacji,akt,rss,link_zwrotny) VALUES (:d,:t,:o,:s,:u,:uri,'-9','1',:akt,:rss,:lz)");
        $stmt->execute([':d'=>time(),':t'=>$tytul,':o'=>$opis,':s'=>$slowa,':u'=>$url,':uri'=>$uri,':akt'=>$akt,':rss'=>$rss,':lz'=>$lz]);
    }
    $wpi_id = (int)$pdo->lastInsertId();

    $pdo->prepare("INSERT INTO {$prefix}relacje (id_kat,id_pod,id_wpi) VALUES (:k,:p,:w)")->execute([':k'=>$cat_id,':p'=>$sub_id,':w'=>$wpi_id]);
    $pdo->prepare("UPDATE {$prefix}kategorie SET {$akt2}={$akt2}+1 WHERE id=:id")->execute([':id'=>$cat_id]);
    $pdo->prepare("UPDATE {$prefix}podkategorie SET {$akt2}={$akt2}+1 WHERE id=:id")->execute([':id'=>$sub_id]);
    $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa=:n")->execute([':n'=>$akt2]);
    $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='rel'")->execute();

    // Generate thumbnail if enabled
    if (!empty($cfg['min']) && $cfg['min'] == '1' && !empty($d['og_image'])) {
        require_once __DIR__ . '/thumbnail.php';
        $hdir = defined('home_dir') ? home_dir : dirname(__DIR__);
        global $home_dir;
        $hdir2 = $home_dir ?? dirname(__DIR__);
        $thumb = zm_download_validate_save($d['og_image'], rtrim($hdir2,'/').'/miniaturki', 160, 120);
        if ($thumb) {
            zm_ensure_thumb_dir(rtrim($hdir2,'/').'/miniaturki');
            $pdo->prepare("UPDATE {$prefix}wpisy SET thumb=:t WHERE id=:id")->execute([':t'=>$thumb,':id'=>$wpi_id]);
        }
    }

    // Tags
    if ($cfg['u3'] == 1 && !empty($slowa)) {
        foreach (explode(',', $slowa) as $tag_raw) {
            $tag_trim = trim($tag_raw);
            if ($tag_trim === '') continue;
            $tag_kod = preg_replace('/[^a-z0-9\-]/','',str_replace(' ','-',mb_strtolower($tag_trim,'UTF-8')));
            $ex = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}tagi WHERE slowo=:s");
            $ex->execute([':s'=>$tag_trim]);
            if ($ex->fetchColumn() < 1) {
                $pdo->prepare("INSERT INTO {$prefix}tagi (slowo,kod,ilosc) VALUES (:s,:k,1)")->execute([':s'=>$tag_trim,':k'=>$tag_kod]);
            } else {
                $pdo->prepare("UPDATE {$prefix}tagi SET ilosc=ilosc+1 WHERE slowo=:s")->execute([':s'=>$tag_trim]);
            }
        }
    }

    // Delete pending record
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);

    return $wpi_id;
}

/**
 * Zwraca które metody płatności są aktywne i ich ceny
 */
function zm_active_payments(array $cfg): array
{
    $methods = [];
    if (!empty($cfg['pp_enable']) && $cfg['pp_enable']=='1' && (float)($cfg['pp_price']??0)>0)
        $methods['paypal'] = ['price'=>(float)$cfg['pp_price'], 'currency'=>$cfg['pp_currency']??'PLN', 'label'=>'PayPal'];
    if (!empty($cfg['str_enable']) && $cfg['str_enable']=='1' && (int)($cfg['str_price']??0)>0)
        $methods['stripe'] = ['price'=>(int)$cfg['str_price']/100, 'currency'=>$cfg['str_currency']??'PLN', 'label'=>'Stripe'];
    if (!empty($cfg['p24_enable']) && $cfg['p24_enable']=='1' && (int)($cfg['p24_price']??0)>0)
        $methods['p24'] = ['price'=>(int)$cfg['p24_price']/100, 'currency'=>$cfg['p24_currency']??'PLN', 'label'=>'Przelewy24'];
    return $methods;
}
