<?php
// Zamknięty mini v1.2 - stripe.php
// Stripe Checkout integration

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$action = $_GET['action'] ?? '';
$base   = rtrim($cfg['o4'] ?? ('http://'.($_SERVER['HTTP_HOST']??'')), '/');

// ============================================================
// CREATE CHECKOUT SESSION — redirect to Stripe
// ============================================================
if ($action === 'pay') {
    $token = $_GET['token'] ?? '';
    if (!$token) { header('Location: index.php'); exit; }

    $sk       = $cfg['str_sk']       ?? '';
    $price    = (int)($cfg['str_price'] ?? 0);   // in cents/grosze
    $currency = strtolower($cfg['str_currency'] ?? 'pln');
    $item     = 'Directory entry';
    $mode     = $cfg['str_mode'] ?? 'test';
    $success  = $base . '/index.php?a=stripe&action=success&token=' . urlencode($token);
    $cancel   = $base . '/index.php?a=stripe&action=cancel&token=' . urlencode($token);

    // Create Stripe Checkout Session via REST API
    $post_data = http_build_query([
        'payment_method_types[0]'            => 'card',
        'line_items[0][price_data][currency]' => $currency,
        'line_items[0][price_data][product_data][name]' => $item,
        'line_items[0][price_data][unit_amount]' => $price,
        'line_items[0][quantity]'            => '1',
        'mode'                               => 'payment',
        'success_url'                        => $success,
        'cancel_url'                         => $cancel,
        'metadata[token]'                    => $token,
        'client_reference_id'               => $token,
    ]);

    $ctx = stream_context_create(['http' => [
        'method'  => 'POST',
        'header'  => "Authorization: Bearer {$sk}\r\nContent-Type: application/x-www-form-urlencoded\r\n",
        'content' => $post_data,
        'timeout' => 15,
        'ignore_errors' => true,
    ]]);
    $resp = @file_get_contents('https://api.stripe.com/v1/checkout/sessions', false, $ctx);
    $sess = $resp ? @json_decode($resp, true) : null;

    if (!empty($sess['url'])) {
        // Update pending with Stripe session ID
        $pdo->prepare("UPDATE {$prefix}payments_pending SET session_id=:sid WHERE token=:tok")
            ->execute([':sid'=>$sess['id'], ':tok'=>$token]);
        header('Location: ' . $sess['url']); exit;
    }

    // Stripe API error
    disp_header(fl('error_title'), '', '');
    echo '<div class="text_body_h1">' . fl('error_title') . '</div>';
    echo '<p>' . htmlspecialchars($cfg['pp_msg_error'] ?? 'Payment error.', ENT_QUOTES, 'UTF-8') . '</p>';
    if (!empty($sess['error']['message'])) echo '<p><small>' . htmlspecialchars($sess['error']['message'], ENT_QUOTES, 'UTF-8') . '</small></p>';
    echo '<p><a href="index.php" class="button">← ' . fl('info_title') . '</a></p>';
    // Clean up pending
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);
    disp_footer();
    exit;
}

// ============================================================
// SUCCESS — redirect back from Stripe after payment
// ============================================================
if ($action === 'success') {
    $token = $_GET['token'] ?? '';
    // Stripe Checkout guarantees payment completed at this URL,
    // but we wait for webhook to activate. Show pending message.
    $msg = htmlspecialchars($cfg['pp_msg_pending'] ?? 'Payment received. Your entry will be activated shortly.', ENT_QUOTES, 'UTF-8');
    disp_header(fl('info_title'), '', '');
    echo '<div class="text_body_h1">✅ ' . fl('info_title') . '</div>';
    echo '<p>' . $msg . '</p>';
    echo '<p><a href="' . htmlspecialchars($base, ENT_QUOTES, 'UTF-8') . '" class="button">← ' . fl('info_title') . '</a></p>';
    disp_footer();
    exit;
}

// ============================================================
// CANCEL — user cancelled on Stripe
// ============================================================
if ($action === 'cancel') {
    $token = $_GET['token'] ?? '';
    // Delete pending entry - payment was cancelled
    $pdo->prepare("DELETE FROM {$prefix}payments_pending WHERE token=:tok")->execute([':tok'=>$token]);
    $msg = htmlspecialchars($cfg['pp_msg_error'] ?? 'Payment cancelled.', ENT_QUOTES, 'UTF-8');
    disp_header(fl('error_title'), '', '');
    echo '<div class="text_body_h1">⚠️ ' . fl('error_title') . '</div>';
    echo '<p>' . $msg . '</p>';
    echo '<p><a href="index.php" class="button">← ' . fl('info_title') . '</a></p>';
    disp_footer();
    exit;
}

header('Location: index.php');
exit;
