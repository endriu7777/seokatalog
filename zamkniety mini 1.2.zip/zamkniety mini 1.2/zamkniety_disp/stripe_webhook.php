<?php
// Zamknięty mini v1.2 - stripe_webhook.php
// Stripe webhook handler — checkout.session.completed

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$payload   = file_get_contents('php://input');
$sig       = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';
$wh_secret = $cfg['str_whsecret'] ?? '';

if (empty($payload)) { http_response_code(200); exit; }

// Verify Stripe webhook signature
$verified = false;
if ($wh_secret && $sig) {
    $parts = [];
    foreach (explode(',', $sig) as $part) {
        [$k, $v] = array_pad(explode('=', $part, 2), 2, '');
        $parts[$k][] = $v;
    }
    $timestamp = $parts['t'][0] ?? 0;
    // Reject events older than 5 minutes
    if (abs(time() - (int)$timestamp) < 300) {
        $signed_payload = $timestamp . '.' . $payload;
        $expected = hash_hmac('sha256', $signed_payload, $wh_secret);
        foreach ($parts['v1'] ?? [] as $v1) {
            if (hash_equals($expected, $v1)) { $verified = true; break; }
        }
    }
} else {
    // No webhook secret configured — accept all (not recommended for production)
    $verified = true;
}

if (!$verified) { http_response_code(400); exit; }

$event = @json_decode($payload, true);
if (!$event) { http_response_code(400); exit; }

if ($event['type'] === 'checkout.session.completed') {
    $session = $event['data']['object'];
    $token   = $session['client_reference_id'] ?? ($session['metadata']['token'] ?? '');
    if ($token) {
        zm_payment_activate($pdo, $prefix, $cfg, $token);
    }
}

http_response_code(200);
exit;
