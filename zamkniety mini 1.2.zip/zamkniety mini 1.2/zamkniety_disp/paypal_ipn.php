<?php
// Zamknięty mini v1.2 - paypal_ipn.php
// PayPal IPN handler

global $pdo, $prefix, $cfg;
require_once __DIR__ . '/payment_helper.php';

$mode    = $cfg['pp_mode']  ?? 'sandbox';
$pp_host = ($mode === 'live') ? 'ipnpb.paypal.com' : 'ipnpb.sandbox.paypal.com';
$raw     = file_get_contents('php://input');
if (empty($raw)) { http_response_code(200); exit; }

// Verify with PayPal
$ctx = stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/x-www-form-urlencoded\r\n",'content'=>'cmd=_notify-validate&'.$raw,'timeout'=>15,'ignore_errors'=>true]]);
$vr = @file_get_contents('https://'.$pp_host.'/cgi-bin/webscr', false, $ctx);
if ($vr !== 'VERIFIED') { http_response_code(200); exit; }

parse_str($raw, $ipn);
$status   = $ipn['payment_status'] ?? '';
$receiver = strtolower($ipn['receiver_email'] ?? '');
$our_mail = strtolower($cfg['pp_email'] ?? '');
$paid     = (float)($ipn['mc_gross'] ?? 0);
$expected = (float)($cfg['pp_price'] ?? 0);
$currency = $ipn['mc_currency'] ?? '';
$token    = $ipn['custom'] ?? ($ipn['item_number'] ?? '');

if ($receiver !== $our_mail) { http_response_code(200); exit; }
if ($status !== 'Completed') { http_response_code(200); exit; }
if ($expected > 0 && abs($paid - $expected) > 0.01) { http_response_code(200); exit; }
if (!$token) { http_response_code(200); exit; }

zm_payment_activate($pdo, $prefix, $cfg, $token);
http_response_code(200);
exit;
