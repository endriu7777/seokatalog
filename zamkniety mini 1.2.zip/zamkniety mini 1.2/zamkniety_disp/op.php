<?php
// Zamknięty mini v1.0 - op.php (obsługa formularzy dodawania)
// Wywoływany przez index.php jako: include("zamkniety_disp/op.php");
// Zmienne $pdo, $prefix, $cfg, $sid, $tpl, $ile dostępne z funkcje.php

$option = $_POST['option'] ?? '';

if ($option === '') {
    // Brak opcji POST - przekieruj na stronę główną
    header('Location: index.php');
    exit;
}

// CSRF weryfikacja dla wszystkich akcji POST
if (!csrf_verify()) {
    die('Nieprawidłowy token CSRF. Odśwież stronę i spróbuj ponownie.');
}

switch ($option) {

    // ============================================================
    case 'add_cat':
    // ============================================================
        $stop = null;
        check_add_cat($pdo, $prefix, $cfg, $sid, $stop);
        if (empty($stop)) {
            $akt  = ($cfg['u1'] == 1) ? '1' : '0';
            $akt2 = ($cfg['u1'] == 1) ? 'kat_a' : 'kat_n';
            $info = ($cfg['u1'] == 1)
                ? fl('thx_add_cat') . ' '
                : fl('thx_sugg_cat');

            $stmt = $pdo->prepare("INSERT INTO {$prefix}kategorie (nazwa,data,akt) VALUES (:nazwa,:data,:akt)");
            $stmt->execute([':nazwa' => $_POST['name'] ?? '', ':data' => time(), ':akt' => $akt]);
            $new_id = (int)$pdo->lastInsertId();
            $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa=:n")->execute([':n' => $akt2]);

            if ($cfg['u1'] == 1) {
                $kat_href = htmlspecialchars(kat_link($new_id, $_POST['name'] ?? '', $cfg), ENT_QUOTES, 'UTF-8');
                $kat_name = htmlspecialchars($_POST['name'] ?? '', ENT_QUOTES, 'UTF-8');
                $info .= ' Przejdź do <a href="/" class="body_links">strony głównej</a> lub do <a href="' . $kat_href . '" class="body_links">' . $kat_name . '</a>.';
            }
            thx($info);
        } else {
            disp_header(fl('error_title'), '', '');
            echo '<div class="text_body_h1">' . fl('error_title') . '</div><p>' . htmlspecialchars($stop, ENT_QUOTES, 'UTF-8') . '</p>';
            disp_footer();
        }
        break;

    // ============================================================
    case 'add_sub':
    // ============================================================
        $stop = null;
        check_add_sub($pdo, $prefix, $cfg, $sid, $stop);
        if (empty($stop)) {
            $akt    = ($cfg['u2'] == 1) ? '1' : '0';
            $akt2   = ($cfg['u2'] == 1) ? 'pod_a' : 'pod_n';
            $info   = ($cfg['u2'] == 1)
                ? fl('thx_add_sub')
                : fl('thx_sugg_sub');
            $cat_id = (int)($_POST['cat_id'] ?? 0);

            $stmt = $pdo->prepare("INSERT INTO {$prefix}podkategorie (nazwa,id_kat,data,akt) VALUES (:nazwa,:kat,:data,:akt)");
            $stmt->execute([':nazwa' => $_POST['name'] ?? '', ':kat' => $cat_id, ':data' => time(), ':akt' => $akt]);
            $pdo->prepare("UPDATE {$prefix}kategorie SET {$akt2}={$akt2}+1 WHERE id=:id")->execute([':id' => $cat_id]);
            $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa=:n")->execute([':n' => $akt2]);
            thx($info);
        } else {
            disp_header(fl('error_title'), '', '');
            echo '<div class="text_body_h1">' . fl('error_title') . '</div><p>' . htmlspecialchars($stop, ENT_QUOTES, 'UTF-8') . '</p>';
            disp_footer();
        }
        break;

    // ============================================================
    case 'add_link':
    // ============================================================
        require_once __DIR__ . '/payment_helper.php';
        $stop     = null;
        $stop1    = null;
        $id_wpisu = null;
        $wpi_akt  = null;
        $url      = '';
        $uri      = '';
        $cat_id   = (int)($_POST['cat_id'] ?? 0);
        $sub_id   = (int)($_POST['sub_id'] ?? 0);

        check_add_link($pdo, $prefix, $cfg, $sid, $stop, $id_wpisu, $wpi_akt, $url, $uri);

        if ($stop === 'rel_0') {
            // Wpis istnieje, tylko dodaj relację
            $wpi_akt2 = ($wpi_akt == 1) ? 'wpi_a' : 'wpi_n';
            $info = ($wpi_akt == 1)
                ? fl('thx_rel_active')
                : fl('thx_rel_pending');
            $pdo->prepare("UPDATE {$prefix}wpisy SET relacji=relacji+1 WHERE id=:id")->execute([':id' => $id_wpisu]);
            $pdo->prepare("INSERT INTO {$prefix}relacje (id_kat,id_pod,id_wpi) VALUES (:k,:p,:w)")->execute([':k'=>$cat_id,':p'=>$sub_id,':w'=>$id_wpisu]);
            $pdo->prepare("UPDATE {$prefix}kategorie SET {$wpi_akt2}={$wpi_akt2}+1 WHERE id=:id")->execute([':id'=>$cat_id]);
            $pdo->prepare("UPDATE {$prefix}podkategorie SET {$wpi_akt2}={$wpi_akt2}+1 WHERE id=:id")->execute([':id'=>$sub_id]);
            $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='rel'")->execute();
            thx($info);

        } elseif (!empty($stop)) {
            // Błąd walidacji URL
            disp_header(fl('error_title'), '', '');
            echo '<div class="text_body_h1">' . fl('error_title') . '</div><p>' . htmlspecialchars($stop, ENT_QUOTES, 'UTF-8') . '</p>';
            disp_footer();

        } else {
            // Nowy wpis — pobierz dane strony i zapisz
            check_addok_link($pdo, $prefix, $cfg, $sid, $stop1, $url, $uri);

            if (!empty($stop1)) {
                disp_header(fl('error_title'), '', '');
                echo '<div class="text_body_h1">' . fl('error_title') . '</div><p>' . htmlspecialchars($stop1, ENT_QUOTES, 'UTF-8') . '</p>';
                // Pokaż formularz ponownie z wypełnionymi danymi
                $ne = htmlspecialchars('http://' . $url . ($uri ? '/' . $uri : ''), ENT_QUOTES, 'UTF-8');
                echo '<div class="add_block">';
                addok_link_form($url, $uri, $cat_id, $sub_id, $_POST['tytul'] ?? '', $_POST['opis'] ?? '', $_POST['slowa'] ?? '');
                echo '</div>';
                disp_footer();
            } else {
                // Sprawdź akceptację regulaminu jeśli wymagana
                if (!empty($cfg['terms_required']) && $cfg['terms_required'] == '1') {
                    if (($_POST['terms_check'] ?? '') !== '1') {
                        disp_header('Błąd', '', '');
                        echo '<div class="text_body_h1">Błąd</div>';
                        echo '<p>' . fl('err_terms') . '</p>';
                        disp_footer();
                        exit;
                    }
                }
                $akt      = ($cfg['u3'] == 1) ? '1' : '0';
                $akt2     = ($cfg['u3'] == 1) ? 'wpi_a' : 'wpi_n';
                $info     = ($cfg['u3'] == 1)
                    ? fl('thx_add_entry')
                    : fl('thx_sugg_entry');
                $tytul    = $_POST['tytul']        ?? '';
                $opis     = $_POST['opis']         ?? '';
                $slowa    = $_POST['slowa']        ?? '';
                $email    = $_POST['email']        ?? '';
                $rss_url  = $_POST['rss']          ?? '';
                $link_zwr = $_POST['link_zwrotny'] ?? '';

                // Check active payment methods
                $active_payments = zm_active_payments($cfg);

                if (!empty($active_payments)) {
                    // PAYMENT REQUIRED — store entry data temporarily, redirect to payment
                    $chosen_method = $_POST['payment_method'] ?? array_key_first($active_payments);
                    if (!isset($active_payments[$chosen_method])) {
                        $chosen_method = array_key_first($active_payments);
                    }

                    $entry_data = [
                        'tytul'    => $tytul,
                        'opis'     => $opis,
                        'slowa'    => $slowa,
                        'url'      => $url,
                        'uri'      => $uri,
                        'email'    => $email,
                        'rss'      => $rss_url,
                        'link_zwr' => $link_zwr,
                        'og_image' => $_POST['_og_image'] ?? '',
                    ];

                    $token = zm_payment_save_pending($pdo, $prefix, $chosen_method, '', $cat_id, $sub_id, $entry_data);
                    $base  = rtrim($cfg['o4'] ?? '', '/');

                    switch ($chosen_method) {
                        case 'paypal':
                            header('Location: ' . $base . '/index.php?a=paypal&action=pay&token=' . urlencode($token));
                            break;
                        case 'stripe':
                            header('Location: ' . $base . '/index.php?a=stripe&action=pay&token=' . urlencode($token));
                            break;
                        case 'p24':
                            header('Location: ' . $base . '/index.php?a=p24&action=pay&token=' . urlencode($token));
                            break;
                        default:
                            header('Location: index.php');
                    }
                    exit;

                } else {
                    // NO PAYMENT — save entry directly (free)
                    if ($cfg['pm'] == 1) {
                        $stmt = $pdo->prepare("INSERT INTO {$prefix}wpisy (data,tytul,opis,slowa,url,uri,pr,relacji,akt,mail,rss,link_zwrotny) VALUES (:d,:t,:o,:s,:u,:uri,'-9','1',:akt,:m,:rss,:lz)");
                        $stmt->execute([':d'=>time(),':t'=>$tytul,':o'=>$opis,':s'=>$slowa,':u'=>$url,':uri'=>$uri,':akt'=>$akt,':m'=>$email,':rss'=>$rss_url,':lz'=>$link_zwr]);
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO {$prefix}wpisy (data,tytul,opis,slowa,url,uri,pr,relacji,akt,rss,link_zwrotny) VALUES (:d,:t,:o,:s,:u,:uri,'-9','1',:akt,:rss,:lz)");
                        $stmt->execute([':d'=>time(),':t'=>$tytul,':o'=>$opis,':s'=>$slowa,':u'=>$url,':uri'=>$uri,':akt'=>$akt,':rss'=>$rss_url,':lz'=>$link_zwr]);
                    }
                    $id_wpisu = (int)$pdo->lastInsertId();

                    if ($cfg['u3'] == 1 && !empty($slowa)) {
                        foreach (explode(',', $slowa) as $tag_raw) {
                            $tag_trim = trim($tag_raw);
                            if ($tag_trim === '') continue;
                            $tag_kod = zmiana_url($tag_trim);
                            $ex = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}tagi WHERE slowo=:s");
                            $ex->execute([':s' => $tag_trim]);
                            if ($ex->fetchColumn() < 1) {
                                $pdo->prepare("INSERT INTO {$prefix}tagi (slowo,kod,ilosc) VALUES (:s,:k,1)")->execute([':s'=>$tag_trim,':k'=>$tag_kod]);
                            } else {
                                $pdo->prepare("UPDATE {$prefix}tagi SET ilosc=ilosc+1 WHERE slowo=:s")->execute([':s'=>$tag_trim]);
                            }
                        }
                    }

                    // Thumbnail generation for free entries
                    if (!empty($cfg['min']) && $cfg['min'] == '1') {
                        require_once __DIR__ . '/thumbnail.php';
                        global $home_dir;
                        $og_img = $_POST['_og_image'] ?? '';
                        $site_full = 'http://' . $url . ($uri ? '/' . $uri : '');
                        $hdir = $home_dir ?? dirname(__DIR__);
                        $thumb = '';
                        if ($og_img) {
                            $thumb = zm_download_validate_save($og_img, rtrim($hdir,'/').'/miniaturki', 160, 120);
                            zm_ensure_thumb_dir(rtrim($hdir,'/').'/miniaturki');
                        }
                        if (!$thumb) {
                            $thumb = zm_fetch_thumbnail($site_full, $hdir);
                        }
                        if ($thumb) {
                            $pdo->prepare("UPDATE {$prefix}wpisy SET thumb=:t WHERE id=:id")->execute([':t'=>$thumb,':id'=>$id_wpisu]);
                        }
                    }
                    $pdo->prepare("INSERT INTO {$prefix}relacje (id_kat,id_pod,id_wpi) VALUES (:k,:p,:w)")->execute([':k'=>$cat_id,':p'=>$sub_id,':w'=>$id_wpisu]);
                    $pdo->prepare("UPDATE {$prefix}kategorie SET {$akt2}={$akt2}+1 WHERE id=:id")->execute([':id'=>$cat_id]);
                    $pdo->prepare("UPDATE {$prefix}podkategorie SET {$akt2}={$akt2}+1 WHERE id=:id")->execute([':id'=>$sub_id]);
                    $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa=:n")->execute([':n'=>$akt2]);
                    $pdo->prepare("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='rel'")->execute();

                    if (!empty($cfg['pm']) && $cfg['pm'] == 1 && !empty($cfg['mail_admin'])) {
                        if (!function_exists('zm_send_mail')) @include_once dirname(__DIR__) . '/zamkniety_admin/mail_send.php';
                        if (function_exists('zm_send_mail')) {
                            $admin_body = '<p>Nowy wpis <b>' . htmlspecialchars($tytul, ENT_QUOTES, 'UTF-8') . '</b> oczekuje na zatwierdzenie.</p><p>URL: http://' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '</p>';
                            zm_send_mail($cfg, $cfg['mail_admin'], 'Nowy wpis: ' . $tytul, $admin_body);
                        }
                    }
                    thx($info);
                }
            }
        }
        break;

    default:
        header('Location: index.php');
        exit;
}

// ============================================================
// Funkcje walidacji
// ============================================================

function check_add_cat(PDO $pdo, string $prefix, array $cfg, string $sid, ?string &$stop): void
{
    if ((int)($cfg['u1'] ?? 0) === 3) { $stop = 'Dodawanie kategorii jest wyłączone.'; return; }

    $name = htmlspecialchars(preg_replace('/\s+/', ' ', trim(strip_tags($_POST['name'] ?? ''))), ENT_QUOTES, 'UTF-8');
    $name = substr($name, 0, 255);
    $_POST['name'] = $name;

    if ($name === '')       { $stop = 'Nazwa kategorii nie może być pusta.'; return; }
    if (strlen($name) < 2) { $stop = 'Nazwa kategorii jest zbyt krótka (minimum 2 znaki).'; return; }

    $st = $pdo->prepare("SELECT id, akt FROM {$prefix}kategorie WHERE nazwa=:n LIMIT 1");
    $st->execute([':n' => $name]);
    $row = $st->fetch();
    if ($row) {
        $stop = ($row['akt'] == 1)
            ? 'Taka kategoria już istnieje w katalogu.'
            : 'Taka kategoria została już zgłoszona i oczekuje na aktywację przez Administratora.';
        return;
    }

}

function check_add_sub(PDO $pdo, string $prefix, array $cfg, string $sid, ?string &$stop): void
{
    if ((int)($cfg['u2'] ?? 0) === 3) { $stop = fl('err_sub_add_off'); return; }

    $name   = htmlspecialchars(preg_replace('/\s+/', ' ', trim(strip_tags($_POST['name'] ?? ''))), ENT_QUOTES, 'UTF-8');
    $name   = substr($name, 0, 255);
    $cat_id = (int)($_POST['cat_id'] ?? 0);
    $_POST['name'] = $name;

    if ($name === '')       { $stop = fl('err_sub_empty'); return; }
    if (strlen($name) < 2) { $stop = fl('err_sub_short'); return; }

    $st = $pdo->prepare("SELECT id, akt FROM {$prefix}podkategorie WHERE nazwa=:n AND id_kat=:k LIMIT 1");
    $st->execute([':n' => $name, ':k' => $cat_id]);
    $row = $st->fetch();
    if ($row) {
        $stop = ($row['akt'] == 1)
            ? fl('err_sub_exists')
            : fl('err_sub_pending');
        return;
    }

}

function check_add_link(PDO $pdo, string $prefix, array $cfg, string $sid, ?string &$stop, ?int &$id_wpisu, ?int &$wpi_akt, string &$url, string &$uri): void
{
    if ((int)($cfg['u3'] ?? 0) === 3) { $stop = 'Dodawanie wpisów jest wyłączone.'; return; }

    // Sanitize URL
    $raw = trim(strip_tags($_POST['url'] ?? ''));
    $raw = str_replace(['"', "'", ' '], '', $raw);
    // Strip protocol
    $raw = preg_replace('#^https?://#i', '', $raw);

    if ($raw === '')       { $stop = fl('err_url_empty'); return; }
    if (strlen($raw) < 4) { $stop = fl('err_url_short'); return; }

    // Split domain/uri
    $parts = explode('/', $raw, 2);
    $url   = strtolower($parts[0]);
    $uri   = isset($parts[1]) ? rtrim($parts[1], '/') : '';

    // Walidacja domeny: musi zawierać kropkę i prawidłowe TLD (min 2 znaki po ostatniej kropce)
    $dot_pos = strrpos($url, '.');
    if ($dot_pos === false) {
        $stop = fl('err_url_nodot');
        return;
    }
    $tld = substr($url, $dot_pos + 1);
    if (strlen($tld) < 2 || !ctype_alpha($tld)) {
        $stop = fl('err_url_tld');
        return;
    }
    if ($dot_pos === 0 || $dot_pos === strlen($url) - 1) {
        $stop = 'Podany adres www jest nieprawidłowy.';
        return;
    }

    // Check blocked domains
    $domain_parts = array_reverse(explode('.', $url));
    $domain2      = ($domain_parts[1] ?? '') . '.' . ($domain_parts[0] ?? '');
    $blok = $pdo->prepare("SELECT id FROM {$prefix}blokowane WHERE adres=:a1 OR adres=:a2 LIMIT 1");
    $blok->execute([':a1' => $url, ':a2' => '*.' . $domain2]);
    if ($blok->fetch()) {
        $stop = fl('err_blocked');
        return;
    }

    // Check if entry already exists
    $wpi = $pdo->prepare("SELECT id, akt, relacji FROM {$prefix}wpisy WHERE url=:u AND uri=:uri LIMIT 1");
    $wpi->execute([':u' => $url, ':uri' => $uri]);
    $row = $wpi->fetch();

    if ($row) {
        $id_wpisu = (int)$row['id'];
        $cat_id   = (int)($_POST['cat_id'] ?? 0);
        $sub_id   = (int)($_POST['sub_id'] ?? 0);
        $max_rel  = (int)($cfg['u4'] ?? 10);

        $rel = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}relacje WHERE id_kat=:k AND id_pod=:p AND id_wpi=:w");
        $rel->execute([':k'=>$cat_id,':p'=>$sub_id,':w'=>$id_wpisu]);

        if ($rel->fetchColumn() == 0 && ($max_rel == 0 || (int)$row['relacji'] < $max_rel)) {
            $stop    = 'rel_0';
            $wpi_akt = (int)$row['akt'];
        } else {
            $stop = fl('err_entry_exists');
        }
        return;
    }

    // Token check (CAPTCHA)
}

function check_addok_link(PDO $pdo, string $prefix, array $cfg, string $sid, ?string &$stop1, string $url, string $uri): void
{
    if ((int)($cfg['u3'] ?? 0) === 3) { $stop1 = 'Dodawanie wpisów jest wyłączone.'; return; }

    $tytul = '';
    $opis  = '';
    $slowa = '';

    // Jeśli to ponowne wysłanie formularza (err=1), użyj danych z POST
    if (($_POST['err'] ?? '') == '1') {
        $tytul = $_POST['tytul'] ?? '';
        $opis  = $_POST['opis']  ?? '';
        $slowa = $_POST['slowa'] ?? '';
    } else {
        // Spróbuj pobrać meta tagi ze strony
        $site_url = 'http://' . $url . ($uri ? '/' . $uri : '');
        $ctx      = stream_context_create(['http' => ['timeout' => 8, 'ignore_errors' => true]]);
        $tresc    = @file_get_contents($site_url, false, $ctx);

        if ($tresc !== false && $tresc !== '') {
            $tresc = str_replace(["\r", "\n"], ' ', $tresc);
            // Title
            if (preg_match('#<title[^>]*>(.*?)</title>#si', $tresc, $mt)) {
                $tytul = html_entity_decode(strip_tags($mt[1]), ENT_QUOTES, 'UTF-8');
            }
            // Description
            if (preg_match('#<meta[^>]+name=["\']description["\'][^>]+content=["\'](.*?)["\']#si', $tresc, $md)) {
                $opis = html_entity_decode(strip_tags($md[1]), ENT_QUOTES, 'UTF-8');
            }
            // Keywords
            if (preg_match('#<meta[^>]+name=["\']keywords["\'][^>]+content=["\'](.*?)["\']#si', $tresc, $mk)) {
                $slowa = html_entity_decode(strip_tags($mk[1]), ENT_QUOTES, 'UTF-8');
            }
            // og:image for thumbnail
            if (preg_match('#<meta[^>]+property=["\']og:image["\'][^>]+content=["\'](https?://[^"\'>\s]+)["\']#si', $tresc, $mog) ||
                preg_match('#<meta[^>]+content=["\'](https?://[^"\'>\s]+)["\'][^>]+property=["\']og:image["\']#si', $tresc, $mog)) {
                $_POST['_og_image'] = html_entity_decode($mog[1], ENT_QUOTES, 'UTF-8');
            }
        } else {
            // Nie można pobrać strony — pokaż formularz do ręcznego wypełnienia
            $stop1 = 'connect_error';
        }
    }

    // Sanitize
    $tytul = htmlspecialchars(substr(preg_replace('/\s+/', ' ', trim($tytul)), 0, 255), ENT_QUOTES, 'UTF-8');
    $opis  = htmlspecialchars(substr(preg_replace('/\s+/', ' ', trim($opis)),  0, 2000), ENT_QUOTES, 'UTF-8');
    $slowa = htmlspecialchars(substr(preg_replace('/\s+/', ' ', trim($slowa)), 0, 500), ENT_QUOTES, 'UTF-8');

    $_POST['tytul'] = $tytul;
    $_POST['opis']  = $opis;
    $_POST['slowa'] = $slowa;

    if ($stop1 === 'connect_error') return;

    // Sprawdź wypełnienie pól
    if ($tytul === '' || $opis === '' || $slowa === '') {
        $stop1 = fl('fetch_error');
        return;
    }

    // Sprawdź link zwrotny gdy wymagany (link_zwr=1)
    if ((int)($cfg['link_zwr'] ?? 0) === 1) {
        $lz = trim($_POST['link_zwrotny'] ?? '');
        if ($lz === '') {
            $stop1 = fl('err_backlink_req');
            return;
        }
        // Sprawdź czy strona z linkiem faktycznie zawiera link do katalogu
        $lz_adres = $cfg['link_adres'] ?? ($cfg['o4'] ?? '');
        $lz_domain = parse_url($lz_adres, PHP_URL_HOST) ?: $lz_adres;
        if ($lz_domain) {
            $lz_ctx = stream_context_create(['http' => ['timeout' => 6, 'ignore_errors' => true]]);
            $lz_content = @file_get_contents($lz, false, $lz_ctx);
            if ($lz_content === false || $lz_content === '') {
                $stop1 = fl('err_backlink_404');
                return;
            }
            if (!str_contains(strtolower($lz_content), strtolower($lz_domain))) {
                $stop1 = fl('err_backlink_miss');
                return;
            }
        }
        $_POST['link_zwrotny'] = $lz;
    } elseif ((int)($cfg['link_zwr'] ?? 0) === 2) {
        // Nieobowiązkowy — zapisz jeśli podano
        $_POST['link_zwrotny'] = trim($_POST['link_zwrotny'] ?? '');
    }

    // Sprawdź zakazane frazy
    $flt = $pdo->prepare("SELECT wartosc FROM {$prefix}filtr WHERE nazwa='frazy' LIMIT 1");
    $flt->execute();
    $flt_row = $flt->fetch();
    if (!empty($flt_row['wartosc'])) {
        $all_text = strtoupper($tytul . ' ' . $opis . ' ' . $slowa);
        foreach (explode("\n", str_replace("\r", '', $flt_row['wartosc'])) as $zak) {
            $zak = trim($zak);
            if ($zak !== '' && str_contains($all_text, strtoupper($zak))) {
                $stop1 = fl('err_filter');
                return;
            }
        }
    }
}

function addok_link_form(string $url, string $uri, int $cat_id, int $sub_id, string $tytul, string $opis, string $slowa): void
{
    global $cfg;
    $csrf = csrf_token();
    $full_url = htmlspecialchars('http://' . $url . ($uri ? '/' . $uri : ''), ENT_QUOTES, 'UTF-8');
    $btn = ($cfg['u3'] == 1) ? fl('btn_add_entry') : fl('btn_sugg_entry');
    echo '<div class="text_body_h3">' . fl('fill_data') . '</div>';
    echo '<form action="index.php?a=op" method="post">';
    echo '<input type="hidden" name="option"      value="add_link" />';
    echo '<input type="hidden" name="csrf_token"  value="' . $csrf . '" />';
    echo '<input type="hidden" name="cat_id"      value="' . $cat_id . '" />';
    echo '<input type="hidden" name="sub_id"      value="' . $sub_id . '" />';
    echo '<input type="hidden" name="url"         value="' . htmlspecialchars($url, ENT_QUOTES, 'UTF-8') . '" />';
    echo '<input type="hidden" name="err"         value="1" />';
    echo '<p><b>' . fl('field_url') . '</b> ' . $full_url . '</p>';
    echo '<p><b>' . fl('field_title') . '</b><br /><input type="text" name="tytul" value="' . htmlspecialchars($tytul, ENT_QUOTES, 'UTF-8') . '" class="formdodaj" /></p>';
    echo '<p><b>' . fl('field_desc') . '</b><br /><textarea name="opis" class="formdodaj" rows="4">' . htmlspecialchars($opis, ENT_QUOTES, 'UTF-8') . '</textarea></p>';
    echo '<p><b>' . fl('field_keywords') . '</b><br /><textarea name="slowa" class="formdodaj" rows="2">' . htmlspecialchars($slowa, ENT_QUOTES, 'UTF-8') . '</textarea></p>';
    if ($cfg['pm'] == 1) {
        echo '<p><b>' . fl('field_email') . '</b><br /><input type="text" name="email" value="' . htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') . '" class="formdodaj" /></p>';
    }
    // Pole link zwrotny — pokazuj gdy link_zwr=1 (obowiązkowy) lub link_zwr=2 (nieobowiązkowy)
    if ((int)($cfg['link_zwr'] ?? 0) >= 1) {
        $lz_opis = htmlspecialchars($cfg['link_opis'] ?? 'Wstaw link zwrotny do naszego katalogu na swojej stronie.', ENT_QUOTES, 'UTF-8');
        $lz_adres = htmlspecialchars($cfg['link_adres'] ?? ($cfg['o4'] ?? ''), ENT_QUOTES, 'UTF-8');
        $lz_req = ($cfg['link_zwr'] == 1) ? ' <span style="color:red;">*</span>' : ' <span style="color:#999;">(nieobowiązkowy)</span>';
        echo '<div style="background:rgba(220,235,250,0.5);border:1px solid #b0c8e0;border-radius:4px;padding:10px;margin:8px 0;">';
        echo '<p style="margin:0 0 6px 0;"><b>Link zwrotny' . $lz_req . ':</b></p>';
        echo '<p style="font-size:12px;color:#5a7a9a;margin:0 0 6px 0;">' . $lz_opis . '</p>';
        // Show anchor texts if configured
        $anchors = array_filter([
            $cfg['link_anchor_1'] ?? '',
            $cfg['link_anchor_2'] ?? '',
            $cfg['link_anchor_3'] ?? '',
        ]);
        if ($anchors && $lz_adres) {
            echo '<p style="font-size:12px;color:#5a7a9a;margin:0 0 6px 0;">Przykładowy kod linka:<br>';
            foreach ($anchors as $anchor) {
                echo '<code>&lt;a href=&quot;' . $lz_adres . '&quot;&gt;' . htmlspecialchars($anchor, ENT_QUOTES, 'UTF-8') . '&lt;/a&gt;</code><br>';
            }
            echo '</p>';
        }
        $lz_val = htmlspecialchars($_POST['link_zwrotny'] ?? '', ENT_QUOTES, 'UTF-8');
        echo '<input type="text" name="link_zwrotny" value="' . $lz_val . '" class="formdodaj" placeholder="https://twoja-strona.pl/strona-z-linkiem" />';
        echo '</div>';
    }
    // Wybór metody płatności
    require_once __DIR__ . '/payment_helper.php';
    $active_payments = zm_active_payments($cfg);
    if (!empty($active_payments)) {
        echo '<div style="background:rgba(255,248,220,0.8);border:1px solid #e0c040;border-radius:6px;padding:12px 16px;margin:10px 0;">';
        echo '<p style="margin:0 0 8px 0;font-weight:bold;font-size:13px;">💳 ' . fl('pay_choose') . '</p>';
        $first = true;
        foreach ($active_payments as $method => $info) {
            $price_str = number_format($info['price'], 2, ',', '') . ' ' . $info['currency'];
            $checked = $first ? ' checked' : '';
            $icons = ['paypal'=>'🅿️','stripe'=>'💳','p24'=>'🏦'];
            $icon = $icons[$method] ?? '💳';
            echo '<label style="display:block;margin:4px 0;cursor:pointer;">';
            echo '<input type="radio" name="payment_method" value="' . $method . '"' . $checked . '> ';
            echo $icon . ' <b>' . htmlspecialchars($info['label'], ENT_QUOTES, 'UTF-8') . '</b>';
            echo ' — <span style="color:#2a8a2a;font-weight:bold;">' . $price_str . '</span>';
            echo '</label>';
            $first = false;
        }
        echo '</div>';
    }

    // Checkbox regulaminu/polityki prywatności
    if (!empty($cfg['terms_required']) && $cfg['terms_required'] == '1') {
        $m6 = $cfg['m6'] ?? 'inf';
        $inf_url = (($cfg['m1']??0)==1||($cfg['m1']??0)==3) ? '/'.$m6.'.html' : 'index.php?a=inf';
        $pp_url  = (($cfg['m1']??0)==1||($cfg['m1']??0)==3) ? '/pp.html' : 'index.php?a=pp';
        $lang    = !empty($_SESSION['lang']) ? $_SESSION['lang'] : 'pl';
        if ($lang === 'en') {
            $terms_text = sprintf(fl('terms_text'), $inf_url, $pp_url);
        } else {
            $terms_text = sprintf(fl('terms_text'), $inf_url, $pp_url);
        }
        echo '<p style="margin:10px 0;">';
        echo '<label style="display:flex;align-items:flex-start;gap:8px;cursor:pointer;">';
        echo '<input type="checkbox" name="terms_check" value="1" style="margin-top:3px;" required />';
        echo '<span style="font-size:13px;">' . $terms_text . ' <span style="color:red;">*</span></span>';
        echo '</label></p>';
    }
    echo '<input type="submit" class="button" value="' . $btn . '" />';
    echo '</form>';
}

function check_token(PDO $pdo, string $prefix, string $sid, ?string &$stop): void
{
    $token_post = htmlspecialchars(strip_tags(trim($_POST['token'] ?? '')), ENT_QUOTES, 'UTF-8');
    if ($token_post === '') { $stop = 'Wprowadź kod z obrazka.'; return; }
    $ses = $pdo->prepare("SELECT token FROM {$prefix}sesje WHERE ident=:sid LIMIT 1");
    $ses->execute([':sid' => $sid]);
    $row = $ses->fetch();
    if (empty($row['token']) || !hash_equals($row['token'], $token_post)) {
        $stop = 'Kod z obrazka jest niepoprawny. Spróbuj ponownie.';
    }
}

// ============================================================
// Google reCAPTCHA verification helper
// Reads settings from zamkniety_inc/security.json
// ============================================================
function verify_recaptcha(string $action = 'submit'): bool
{
    $sec_file = dirname(__DIR__) . '/zamkniety_inc/security.json';
    if (!file_exists($sec_file)) return true; // nie skonfigurowane = przepuść

    $sec = json_decode(file_get_contents($sec_file), true) ?: [];
    if (empty($sec['captcha_enabled'])) return true;

    $secret = $sec['captcha_secret'] ?? '';
    $mode   = $sec['captcha_mode']   ?? 'v2';
    if ($secret === '') return true;

    $token_field = ($mode === 'v3') ? 'g-recaptcha-response' : 'g-recaptcha-response';
    $token       = $_POST[$token_field] ?? '';
    if ($token === '') return false;

    $ctx  = stream_context_create(['http' => ['method'=>'POST','timeout'=>5,
        'content'=>http_build_query(['secret'=>$secret,'response'=>$token])]]);
    $resp = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $ctx);
    if ($resp === false) return false;

    $data = json_decode($resp, true) ?: [];
    if (empty($data['success'])) return false;

    if ($mode === 'v3') {
        $min_score = (float)($sec['captcha_v3_score'] ?? 0.5);
        if (($data['score'] ?? 0) < $min_score) return false;
    }
    return true;
}

function get_recaptcha_html(): string
{
    $sec_file = dirname(__DIR__) . '/zamkniety_inc/security.json';
    if (!file_exists($sec_file)) return '';
    $sec = json_decode(file_get_contents($sec_file), true) ?: [];
    if (empty($sec['captcha_enabled'])) return '';

    $site_key = $sec['captcha_site_key'] ?? '';
    $mode     = $sec['captcha_mode']     ?? 'v2';
    $label    = htmlspecialchars($sec['captcha_msg_label'] ?? 'Weryfikacja CAPTCHA', ENT_QUOTES, 'UTF-8');
    if ($site_key === '') return '';

    if ($mode === 'v2') {
        return '<div style="margin:8px 0;"><p style="font-size:12px;margin-bottom:4px;">'.$label.'</p>'
            . '<script src="https://www.google.com/recaptcha/api.js" async defer></script>'
            . '<div class="g-recaptcha" data-sitekey="'.htmlspecialchars($site_key,ENT_QUOTES,'UTF-8').'"></div></div>';
    } elseif ($mode === 'v2_invisible') {
        return '<script src="https://www.google.com/recaptcha/api.js" async defer></script>'
            . '<input type="hidden" id="g-recaptcha-response" name="g-recaptcha-response">'
            . '<script>function onSubmit(token){document.getElementById("zm_form").submit();}</script>';
    } elseif ($mode === 'v3') {
        return '<script src="https://www.google.com/recaptcha/api.js?render='.htmlspecialchars($site_key,ENT_QUOTES,'UTF-8').'"></script>'
            . '<input type="hidden" name="g-recaptcha-response" id="g-recaptcha-response-v3">'
            . '<script>grecaptcha.ready(function(){grecaptcha.execute("'.htmlspecialchars($site_key,ENT_QUOTES,'UTF-8').'",{action:"submit"}).then(function(token){document.getElementById("g-recaptcha-response-v3").value=token;});});</script>';
    }
    return '';
}
