<?php
$home_dir = '/var/www/domains/k/ka/kat/katalog.buz.cba.pl';
$dbhost   = 'localhost';
$dbuser   = 'katalogfirm123';
$dbpss    = 'sonyrxd5';
$dbname   = 'katalogfirm_c0_pl';
$prefix   = 'zm_';
$login    = 'admin123';
$pass     = 'admin123';
