<?php
// Zamknięty mini v1.1 - lang_switch.php
// Przełącznik języka frontendu (PL/EN)
// Użycie w zakładce Wygląd: <php>lang_switch.php</php>

$lang    = $_SESSION['lang'] ?? 'pl';
$current = strtoupper($lang);
$referer = $_SERVER['HTTP_REFERER'] ?? 'index.php';

// Handle language switch via ?set_lang=
if (!empty($_GET['set_lang']) && in_array($_GET['set_lang'], ['pl','en'], true)
    && session_status() === PHP_SESSION_ACTIVE) {
    $_SESSION['lang'] = $_GET['set_lang'];
    // Redirect back without set_lang param
    $back = strtok($referer, '?') ?: 'index.php';
    header('Location: ' . $back);
    exit;
}
?>
<div style="padding:6px 0;font-size:12px;">
<?php if ($lang !== 'pl'): ?>
    <a href="?set_lang=pl" style="text-decoration:none;" title="Polski">🇵🇱 PL</a>
<?php else: ?>
    <span style="font-weight:bold;color:#2a6ab0;">🇵🇱 PL</span>
<?php endif; ?>
 | 
<?php if ($lang !== 'en'): ?>
    <a href="?set_lang=en" style="text-decoration:none;" title="English">🇬🇧 EN</a>
<?php else: ?>
    <span style="font-weight:bold;color:#2a6ab0;">🇬🇧 EN</span>
<?php endif; ?>
</div>
