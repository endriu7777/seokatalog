<?php
// Zamknięty mini v1.0 - xml_export.php (panel admina)
if (file_exists("../zamkniety_inc/config.php")) {
    if (!file_exists("../zamkniety_inc/zamkniety_install.php")) {
        include("../zamkniety_inc/config.php");
        if (!function_exists("administrator")) { require_once __DIR__ . "/admin_functions.php"; }
        session_start();
        if (!function_exists("t")) { require_once __DIR__ . "/lang.php"; }
        if (!administrator()) { header("Location: index.php"); exit; }

        $a = $_GET['a'] ?? '';

        switch ($a) {
            case 'mapy_stron':
                // Google XML Sitemap — używa tych samych funkcji URL co frontend
                header('Content-Type: application/xml; charset=UTF-8');
                header('Content-Disposition: attachment; filename="sitemap.xml"');

                $base    = rtrim($cfg['o4'] ?? ('http://' . ($_SERVER['HTTP_HOST'] ?? '')), '/');
                $m1      = (int)($cfg['m1'] ?? 0);
                $sep     = $cfg['m2'] ?? '-';

                // Helper: buduje URL kategorii tak samo jak kat_link()
                $url_kat = function(int $id, string $nazwa) use ($base, $m1, $sep, $cfg): string {
                    $m = $cfg['m3'] ?? 'kat';
                    $s = str_contains($m, '/') ? '/' : $sep;
                    $e = str_contains($m, '/') ? '/' : '.html';
                    if ($m1 === 1) return $base . '/' . $m . $s . $id . $e;
                    if ($m1 === 3) return $base . '/' . zmiana_url($nazwa) . $s . 'k' . $id . $e;
                    return $base . '/index.php?a=kat&id=' . $id;
                };
                $url_pod = function(int $id, string $nazwa) use ($base, $m1, $sep, $cfg): string {
                    $m = $cfg['m4'] ?? 'pod';
                    $s = str_contains($m, '/') ? '/' : $sep;
                    $e = str_contains($m, '/') ? '/' : '.html';
                    if ($m1 === 1) return $base . '/' . $m . $s . $id . $e;
                    if ($m1 === 3) return $base . '/' . zmiana_url($nazwa) . $s . 'p' . $id . $e;
                    return $base . '/index.php?a=pod&id=' . $id;
                };
                $url_wpi = function(int $id, string $tytul) use ($base, $m1, $sep, $cfg): string {
                    $m = $cfg['m5'] ?? 'szcz';
                    $s = str_contains($m, '/') ? '/' : $sep;
                    $e = str_contains($m, '/') ? '/' : '.html';
                    if ($m1 === 1) return $base . '/' . $m . $s . $id . $e;
                    if ($m1 === 3) return $base . '/' . zmiana_url($tytul) . $s . 's' . $id . $e;
                    return $base . '/index.php?a=szcz&id=' . $id;
                };

                echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
                echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";

                // Strona główna
                echo "<url><loc>" . htmlspecialchars($base . '/', ENT_XML1, 'UTF-8') . "</loc><priority>1.0</priority></url>\n";

                // Kategorie i podkategorie
                $kats = $pdo->query("SELECT id, nazwa FROM {$prefix}kategorie WHERE akt='1' ORDER BY nazwa");
                while ($kat = $kats->fetch()) {
                    $loc = htmlspecialchars($url_kat((int)$kat['id'], $kat['nazwa']), ENT_XML1, 'UTF-8');
                    echo "<url><loc>{$loc}</loc><priority>0.8</priority></url>\n";

                    $pods = $pdo->prepare("SELECT id, nazwa FROM {$prefix}podkategorie WHERE id_kat=:k AND akt='1'");
                    $pods->execute([':k' => $kat['id']]);
                    while ($pod = $pods->fetch()) {
                        $loc2 = htmlspecialchars($url_pod((int)$pod['id'], $pod['nazwa']), ENT_XML1, 'UTF-8');
                        echo "<url><loc>{$loc2}</loc><priority>0.6</priority></url>\n";
                    }
                }

                // Wpisy (max 50000 — limit Google)
                $wpisy = $pdo->query("SELECT id, tytul, data FROM {$prefix}wpisy WHERE akt='1' ORDER BY data DESC LIMIT 50000");
                while ($wpi = $wpisy->fetch()) {
                    $loc3    = htmlspecialchars($url_wpi((int)$wpi['id'], $wpi['tytul']), ENT_XML1, 'UTF-8');
                    $lastmod = date('Y-m-d', (int)$wpi['data']);
                    echo "<url><loc>{$loc3}</loc><lastmod>{$lastmod}</lastmod><priority>0.5</priority></url>\n";
                }

                echo '</urlset>' . "\n";
                exit;

            default:
                admin_site_header();
                echo '<div class="admin-section-title">' . t('xml_sitemap_title') . '</div>';
                echo '<p style="color:#5a7a9a;font-size:13px;">' . t('xml_sitemap_desc') . '</p>';

                // Show current URL mode info
                $m1 = (int)($cfg['m1'] ?? 0);
                $mode_label = match($m1) {
                    3 => t('sitemap_url_mode_3'),
                    1 => t('sitemap_url_mode_1'),
                    default => t('sitemap_url_mode_0'),
                };
                echo '<div style="background:rgba(220,235,250,0.5);border:1px solid #b0c8e0;border-radius:4px;padding:8px 12px;margin:10px 0;font-size:12px;color:#3a6a9a;">';
                echo t('sitemap_url_mode') . ': <b>' . $mode_label . '</b>';
                echo '</div>';

                // Count entries
                $cnt_kats = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}kategorie WHERE akt='1'")->fetchColumn();
                $cnt_pods = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}podkategorie WHERE akt='1'")->fetchColumn();
                $cnt_wpi  = (int)$pdo->query("SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt='1'")->fetchColumn();
                $cnt_total = 1 + $cnt_kats + $cnt_pods + $cnt_wpi;

                echo '<p style="font-size:13px;">' . t('sitemap_count') . ' <b>' . $cnt_total . '</b> ' . t('sitemap_count_url') . ': ';
                echo '1 ' . t('sitemap_count_home') . ' + ' . $cnt_kats . ' ' . t('sitemap_count_cats') . ' + ' . $cnt_pods . ' ' . t('sitemap_count_pods') . ' + ' . $cnt_wpi . ' ' . t('sitemap_count_entries') . '</p>';
                echo '<p><a href="xml_export.php?a=mapy_stron" class="btn">' . t('xml_sitemap_btn') . '</a></p>';

                // Ping Google / Bing hint
                $sitemap_url = htmlspecialchars(rtrim($cfg['o4'] ?? '', '/') . '/sitemap.xml', ENT_QUOTES, 'UTF-8');
                echo '<div style="background:#e8f4e8;border:1px solid #80c080;border-radius:6px;padding:12px 16px;margin-top:14px;font-size:13px;line-height:2;">';
                echo '<b>' . t('sitemap_how') . '</b><br>';
                echo t('sitemap_step1') . '<br>';
                echo t('sitemap_step2') . '<br>';
                echo t('sitemap_step3') . '<br>';
                echo '</div>';
                echo '<div style="background:#fff8e0;border:1px solid #e0c040;border-radius:4px;padding:10px 14px;margin-top:10px;font-size:12px;">';
                echo '&#128279; Google Search Console: <a href="https://search.google.com/search-console" target="_blank">search.google.com/search-console</a> &rarr; Mapy witryny &rarr; <code>' . $sitemap_url . '</code><br>';
                echo '&#128279; Bing Webmaster Tools: <a href="https://www.bing.com/webmasters" target="_blank">bing.com/webmasters</a>';
                echo '</div>';

                admin_site_footer();
        }
    } else { echo "Plik instalacyjny istnieje."; }
} else { echo "Brak config.php"; }
