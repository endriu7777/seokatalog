<?php
// Zamknięty mini v1.1 - Panel Administracyjny

$config_file  = __DIR__ . '/../zamkniety_inc/config.php';
$install_file = __DIR__ . '/../zamkniety_inc/zamkniety_install.php';

if (!file_exists($config_file)) {
    die('Brak config.php. <a href="../zamkniety_inc/zamkniety_install.php">Instalacja</a>');
}
if (file_exists($install_file)) {
    die('Usuń plik <b>zamkniety_inc/zamkniety_install.php</b> aby uruchomić panel.');
}

require_once $config_file;
session_start();
require_once __DIR__ . '/lang.php';
require_once __DIR__ . '/admin_functions.php';

if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['admin_csrf'];

function admin_csrf_verify(): bool {
    return isset($_SESSION['admin_csrf'])
        && hash_equals($_SESSION['admin_csrf'], $_POST['csrf_token'] ?? '');
}

$a = $_GET['a'] ?? '';

// Wyloguj
if ($a === 'logout') {
    setcookie('loginn', '', time()-3600, '/');
    setcookie('passs',  '', time()-3600, '/');
    header('Location: index.php'); exit;
}

// ---- Logowanie -----------------------------------------------
if (!administrator()) {
    $login_error = false;
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['option'] ?? '') === 'login') {
        $pl = $_POST['login'] ?? '';
        $pp = $_POST['pass']  ?? '';
        if ($pl !== '' && $pp !== '' && $pl === $login && $pp === $pass) {
            $sec = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            $lt  = time() + 3600 * 8;
            setcookie('loginn', $login, $lt, '/', '', $sec, true);
            setcookie('passs',  $pass,  $lt, '/', '', $sec, true);
            header('Location: index.php'); exit;
        }
        $login_error = true;
    }
    ?>
<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8">
<meta name="robots" content="noindex,nofollow">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Panel admina — Zamknięty mini v1.1</title>
<style>
*,*::before,*::after{box-sizing:border-box}
body{font-family:Arial,sans-serif;font-size:14px;margin:0;padding:0;
  background:linear-gradient(160deg,#c8dff5 0%,#dce9f5 60%,#e8e0d0 100%);
  min-height:100vh;display:flex;align-items:center;justify-content:center}
.lb{background:rgba(255,255,255,0.92);border:1px solid rgba(60,130,200,0.3);
  border-radius:10px;padding:36px 40px;width:340px;
  box-shadow:0 8px 32px rgba(30,80,160,0.15)}
.lt{font-size:18px;font-weight:bold;color:#1a4a80;margin-bottom:4px;text-align:center}
.ls{font-size:12px;color:#7a9aaa;text-align:center;margin-bottom:22px}
label{display:block;font-size:12px;font-weight:bold;color:#2a4a6a;margin:10px 0 3px}
input[type=text],input[type=password]{width:100%;padding:9px 12px;
  border:1px solid rgba(60,130,200,0.4);border-radius:4px;font-size:13px;
  background:rgba(255,255,255,0.9);color:#1a2a3a;outline:none}
input:focus{border-color:#3a80c0;box-shadow:0 0 0 2px rgba(58,128,192,0.15)}
.btn{display:block;width:100%;margin-top:18px;padding:10px;
  background:linear-gradient(180deg,#3a80c0,#1a4a80);
  color:#fff;border:none;border-radius:4px;font-size:14px;font-weight:bold;cursor:pointer}
.btn:hover{background:linear-gradient(180deg,#5090d0,#2a6ab0)}
.err{background:rgba(200,40,40,0.1);border:1px solid rgba(200,40,40,0.3);
  color:#8a1a1a;border-radius:4px;padding:8px 12px;font-size:12px;margin-top:12px}
.lsw{text-align:right;margin-bottom:10px;font-size:11px}
.lsw a{color:#3a80c0;text-decoration:none;margin-left:6px}
</style></head><body>
<div class="lb">
  <div class="lsw">
    <a href="?set_lang=pl">🇵🇱 PL</a>
    <a href="?set_lang=en">🇬🇧 EN</a>
  </div>
  <div class="lt">🔐 Zamknięty mini v1.1</div>
  <div class="ls"><?= t('panel_title') ?></div>
  <form method="post" action="index.php">
    <input type="hidden" name="option" value="login" />
    <label for="fl"><?= t('login_label') ?></label>
    <input type="text" id="fl" name="login"
      value="<?= htmlspecialchars($_POST['login']??'',ENT_QUOTES,'UTF-8') ?>"
      autocomplete="username" autofocus />
    <label for="fp"><?= t('password_label') ?></label>
    <input type="password" id="fp" name="pass" autocomplete="current-password" />
    <button type="submit" class="btn"><?= t('login_btn') ?></button>
  </form>
  <?php if ($login_error): ?>
  <div class="err">❌ <?= t('login_error') ?></div>
  <?php endif; ?>
</div></body></html>
<?php
    exit;
}

// ============================================================
// POST ACTIONS
// ============================================================
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['option'])) {
    if (!admin_csrf_verify()) die(t('err_csrf'));

    switch ($_POST['option']) {

        case 'dodaj_kat':
            $n = substr(preg_replace('/\s+/',' ',trim(strip_tags($_POST['kat']??''))),0,255);
            if (strlen($n) < 2) { header('Location: index.php?a=kategorie&err=2'); exit; }
            $st = $pdo->prepare("SELECT id FROM {$prefix}kategorie WHERE nazwa=:n");
            $st->execute([':n'=>$n]);
            if ($st->fetch()) { header('Location: index.php?a=kategorie&err=3'); exit; }
            $pdo->prepare("INSERT INTO {$prefix}kategorie (nazwa,data,akt) VALUES (:n,:d,'1')")
                ->execute([':n'=>$n,':d'=>time()]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='kat_a'");
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'dodaj_pod':
            $n   = substr(preg_replace('/\s+/',' ',trim(strip_tags($_POST['pod']??''))),0,255);
            $kid = (int)($_POST['kat_id']??0);
            if (strlen($n) < 2) { header('Location: index.php?a=kategorie&err=5'); exit; }
            $pdo->prepare("INSERT INTO {$prefix}podkategorie (nazwa,id_kat,data,akt) VALUES (:n,:k,:d,'1')")
                ->execute([':n'=>$n,':k'=>$kid,':d'=>time()]);
            $pdo->prepare("UPDATE {$prefix}kategorie SET pod_a=pod_a+1 WHERE id=:id")
                ->execute([':id'=>$kid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='pod_a'");
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'save_cfg':
            // Map of field name => allowed values or regex
            $fields = [
                'o1','o2','o3','o4','f1',
                'g1','g2','g3','g4','g5',
                'k1','k2','k3',
                'p1','p2',
                'u1','u2','u3','u4',
                'w1','w2','w3','w4','w5','w6',
                'm1','m2','m3','m4','m5','m6','m7','m8',
                's1','s2','s3',
                'wp','iw','min','pm','loktag','glotag','glotag_min','glotag_ilo',
                'anchor','anchor_ilo','anchor_opi','dodkat','pob_tresc',
                'rss','rss_kanal','rss_link','rss_ilo',
                'link_zwr','link_prz','link_sor','link_adres','link_opis',
                'link_anchor_1','link_anchor_2','link_anchor_3',
                'mail_nadaw','mail_odkog','mail_chars','mail_method','mail_admin',
                'smtp_host','smtp_port','smtp_user','smtp_pass','smtp_secure',
                'maild_tem','maild_tre','mailu_tem','mailu_tre',
                'wersja',
                'opr', 'opr_key',
            ];
            // Radio fields that should default to '0' if not in POST (no radio selected)
            $radio_fields = ['g1','g2','g3','g4','g5','k1','k2','k3','p1','p2',
                'u1','u2','u3','u4','w1','w2','w3','w4','w5','w6',
                'm1','m2','m7','s3','wp','iw','min','pm','loktag','glotag',
                'anchor','dodkat','pob_tresc','rss','rss_link','link_zwr','link_prz','link_sor',
                'opr','mail_method','smtp_secure'];
            foreach ($fields as $k) {
                if (!array_key_exists($k, $_POST)) {
                    // Radio button not in POST = nothing selected
                    // For radio fields default to '0', for text fields keep existing DB value
                    if (in_array($k, $radio_fields, true)) {
                        $v = '0';
                    } else {
                        continue; // Don't overwrite existing text values if field missing from POST
                    }
                } else {
                    $v = trim($_POST[$k]);
                }
                $v = substr($v, 0, 255);
                $pdo->prepare("INSERT INTO {$prefix}konfiguracja (nazwa, wartosc) VALUES (:n, :v)
                    ON DUPLICATE KEY UPDATE wartosc=:v2")
                    ->execute([':n'=>$k, ':v'=>$v, ':v2'=>$v]);
            }
            header('Location: index.php?a=cfg&saved=1'); exit;

        case 'kat_toggle':
            $kid = (int)($_POST['kid']??0);
            $st  = $pdo->prepare("SELECT akt FROM {$prefix}kategorie WHERE id=:id");
            $st->execute([':id'=>$kid]); $row = $st->fetch();
            if ($row) {
                $na = ($row['akt']==1)?0:1;
                $nc = $na?'kat_a':'kat_n'; $oc = $na?'kat_n':'kat_a';
                $pdo->prepare("UPDATE {$prefix}kategorie SET akt=:a WHERE id=:id")->execute([':a'=>$na,':id'=>$kid]);
                $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='$nc'");
                $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc-1 WHERE nazwa='$oc'");
            }
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'kat_approve':
            // Zatwierdź sugerowaną kategorię (akt 0->1)
            $kid = (int)($_POST['kid'] ?? 0);
            if ($kid > 0) {
                $st = $pdo->prepare("SELECT akt FROM {$prefix}kategorie WHERE id=:id");
                $st->execute([':id' => $kid]); $row = $st->fetch();
                if ($row && $row['akt'] == 0) {
                    $pdo->prepare("UPDATE {$prefix}kategorie SET akt=1 WHERE id=:id")->execute([':id' => $kid]);
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='kat_a'");
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='kat_n'");
                }
            }
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'pod_approve':
            // Zatwierdź sugerowaną podkategorię (akt 0->1)
            $pid = (int)($_POST['pid'] ?? 0);
            if ($pid > 0) {
                $st = $pdo->prepare("SELECT akt, id_kat FROM {$prefix}podkategorie WHERE id=:id");
                $st->execute([':id' => $pid]); $row = $st->fetch();
                if ($row && $row['akt'] == 0) {
                    $pdo->prepare("UPDATE {$prefix}podkategorie SET akt=1 WHERE id=:id")->execute([':id' => $pid]);
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='pod_a'");
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='pod_n'");
                    $pdo->prepare("UPDATE {$prefix}kategorie SET pod_a=pod_a+1, pod_n=GREATEST(0,pod_n-1) WHERE id=:id")->execute([':id' => $row['id_kat']]);
                }
            }
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'pod_del':
            // Usuń sugerowaną podkategorię
            $pid = (int)($_POST['pid'] ?? 0);
            if ($pid > 0) {
                $st = $pdo->prepare("SELECT akt, id_kat FROM {$prefix}podkategorie WHERE id=:id");
                $st->execute([':id' => $pid]); $row = $st->fetch();
                if ($row) {
                    $pdo->prepare("DELETE FROM {$prefix}podkategorie WHERE id=:id")->execute([':id' => $pid]);
                    $col = ($row['akt'] == 1) ? 'pod_a' : 'pod_n';
                    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='$col'");
                    $kat_col = ($row['akt'] == 1) ? 'pod_a' : 'pod_n';
                    $pdo->prepare("UPDATE {$prefix}kategorie SET {$kat_col}=GREATEST(0,{$kat_col}-1) WHERE id=:id")->execute([':id' => $row['id_kat']]);
                }
            }
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'kat_del':
            $kid = (int)($_POST['kid']??0);
            $pdo->prepare("DELETE FROM {$prefix}kategorie WHERE id=:id")->execute([':id'=>$kid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc-1 WHERE nazwa='kat_a'");
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'wpi_approve':
            $wid = (int)($_POST['wid']??0);
            // Pobierz dane wpisu PRZED zatwierdzeniem (potrzebujemy slowa i sprawdzenia akt=0)
            $wrow = $pdo->prepare("SELECT slowa FROM {$prefix}wpisy WHERE id=:id AND akt=0");
            $wrow->execute([':id'=>$wid]);
            $wdata = $wrow->fetch();
            $pdo->prepare("UPDATE {$prefix}wpisy SET akt=1 WHERE id=:id")->execute([':id'=>$wid]);
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='wpi_a'");
            $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc-1 WHERE nazwa='wpi_n'");
            // Aktualizuj liczniki wpi_a/wpi_n w kategoriach i podkategoriach
            $rels = $pdo->prepare("SELECT id_kat, id_pod FROM {$prefix}relacje WHERE id_wpi=:id");
            $rels->execute([':id' => $wid]);
            foreach ($rels->fetchAll() as $rel) {
                $pdo->prepare("UPDATE {$prefix}kategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id' => $rel['id_kat']]);
                $pdo->prepare("UPDATE {$prefix}podkategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id' => $rel['id_pod']]);
            }
            // Dodaj tagi do tabeli tagi (pomijane przy u3!=1 w op.php)
            if ($wdata && !empty($wdata['slowa'])) {
                foreach (explode(',', $wdata['slowa']) as $tag_raw) {
                    $tag_trim = trim($tag_raw);
                    if ($tag_trim === '') continue;
                    $tag_kod = preg_replace('/[^a-z0-9\-]/','',str_replace(' ','-',mb_strtolower($tag_trim,'UTF-8')));
                    $ex = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}tagi WHERE slowo=:s");
                    $ex->execute([':s' => $tag_trim]);
                    if ($ex->fetchColumn() < 1) {
                        $pdo->prepare("INSERT INTO {$prefix}tagi (slowo,kod,ilosc) VALUES (:s,:k,1)")->execute([':s'=>$tag_trim,':k'=>$tag_kod]);
                    } else {
                        $pdo->prepare("UPDATE {$prefix}tagi SET ilosc=ilosc+1 WHERE slowo=:s")->execute([':s'=>$tag_trim]);
                    }
                }
            }
            // Wyślij mail do użytkownika jeśli pm=1 i wpis ma adres email
            if (!empty($cfg['pm']) && $cfg['pm'] == 1) {
                $wpis = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE id=:id");
                $wpis->execute([':id' => $wid]);
                $wpis = $wpis->fetch();
                if ($wpis && !empty($wpis['mail'])) {
                    if (!function_exists('zm_send_mail')) require_once __DIR__ . '/mail_send.php';
                    include __DIR__ . '/mail_dodano.php';
                }
            }
            header('Location: index.php?err=0'); exit;

        case 'kat_move':
            $kid = (int)($_POST['kid']??0);
            $dir = ($_POST['dir']??'') === 'up' ? 'up' : 'down';
            // Sort by sort_order if exists, else by id
            // We store sort order in the 'data' field offset trick: 
            // Use a dedicated sort approach - swap data timestamps to change order
            $all_kats = $pdo->query("SELECT id, data FROM {$prefix}kategorie ORDER BY data DESC, id DESC")->fetchAll(PDO::FETCH_ASSOC);
            $ids = array_column($all_kats, 'id');
            $pos = array_search($kid, $ids);
            if ($pos !== false) {
                $swap_pos = ($dir === 'up') ? $pos - 1 : $pos + 1;
                if ($swap_pos >= 0 && $swap_pos < count($ids)) {
                    $swap_id = $ids[$swap_pos];
                    // Swap data values (used as sort order)
                    $d1 = $all_kats[$pos]['data'];
                    $d2 = $all_kats[$swap_pos]['data'];
                    if ($d1 === $d2) { $d1 += 1; } // ensure different
                    $pdo->prepare("UPDATE {$prefix}kategorie SET data=:d WHERE id=:id")->execute([':d'=>$d2,':id'=>$kid]);
                    $pdo->prepare("UPDATE {$prefix}kategorie SET data=:d WHERE id=:id")->execute([':d'=>$d1,':id'=>$swap_id]);
                }
            }
            header('Location: index.php?a=kategorie&err=0'); exit;

        case 'wpi_del':
            $wid = (int)($_POST['wid']??0);
            // Check status before delete so we can update the right counter
            $wdel = $pdo->prepare("SELECT akt FROM {$prefix}wpisy WHERE id=:id");
            $wdel->execute([':id'=>$wid]); $wdel_row = $wdel->fetch();
            $pdo->prepare("DELETE FROM {$prefix}wpisy WHERE id=:id")->execute([':id'=>$wid]);
            $pdo->prepare("DELETE FROM {$prefix}relacje WHERE id_wpi=:id")->execute([':id'=>$wid]);
            if ($wdel_row) {
                $dcol = ((int)$wdel_row['akt'] === 1) ? 'wpi_a' : 'wpi_n';
                $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='$dcol'");
            }
            header('Location: index.php?err=0'); exit;
    }
}

// ============================================================
// GET - render
// ============================================================
$err = (int)($_GET['err'] ?? -1);
$err_msgs = [0=>t('err_0'),1=>t('err_1'),2=>t('err_2'),3=>t('err_3'),5=>t('err_5')];

// Helper: cfg value with default
function cfgv(array $cfg, string $key, string $def=''): string {
    return htmlspecialchars($cfg[$key] ?? $def, ENT_QUOTES, 'UTF-8');
}
// Helper: radio buttons
function cfg_radio(string $name, array $cfg, array $options, string $current_key): string {
    $cur = $cfg[$current_key] ?? '';
    $out = '';
    foreach ($options as $val => $label) {
        $checked = ($cur == $val) ? ' checked' : '';
        $out .= '<label style="margin-right:12px;font-weight:normal;">'
              . '<input type="radio" name="' . $name . '" value="' . htmlspecialchars($val,ENT_QUOTES,'UTF-8') . '"' . $checked . '> '
              . htmlspecialchars($label,ENT_QUOTES,'UTF-8') . '</label>';
    }
    return $out;
}

admin_site_header();
define('ZAMKNIETY_ADMIN_HEADER_SENT', true);

if ($err >= 0 && isset($err_msgs[$err])) {
    $c = ($err===0) ? 'green' : '#c00';
    echo '<div style="color:'.$c.';font-weight:bold;margin-bottom:10px;">'.$err_msgs[$err].'</div>';
}

switch ($a) {

// ============================================================
// DASHBOARD
// ============================================================
default:
    // Auto-synchronize counters with real DB counts (prevents stale wpi_n etc.)
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=1) WHERE nazwa='wpi_a'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}wpisy WHERE akt=0) WHERE nazwa='wpi_n'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}kategorie WHERE akt=1) WHERE nazwa='kat_a'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}kategorie WHERE akt=0) WHERE nazwa='kat_n'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}podkategorie WHERE akt=1) WHERE nazwa='pod_a'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=(SELECT COUNT(*) FROM {$prefix}podkategorie WHERE akt=0) WHERE nazwa='pod_n'");
    // Ensure new config keys exist (for existing installations)
    $new_cfg_defaults = ['opr' => '0', 'opr_key' => '', 'mail_method' => 'mail', 'mail_admin' => '', 'smtp_host' => '', 'smtp_port' => '587', 'smtp_user' => '', 'smtp_pass' => '', 'smtp_secure' => 'tls', 'cookie_enable' => '0', 'cookie_msg' => 'Ta strona używa plików cookie w celu poprawnego działania.', 'terms_required' => '0', 'pp_enable' => '0', 'pp_mode' => 'sandbox', 'pp_email' => '', 'pp_client_id' => '', 'pp_secret' => '', 'pp_price' => '0.00', 'pp_currency' => 'PLN', 'pp_item_name' => 'Dodanie wpisu do katalogu', 'pp_return_url' => '', 'pp_cancel_url' => '', 'pp_msg_pending' => 'Twój wpis został zapisany. Dokończ płatność aby był widoczny.', 'pp_msg_success' => 'Dziękujemy za płatność! Twój wpis zostanie aktywowany.', 'pp_msg_error' => 'Wystąpił błąd płatności. Spróbuj ponownie.'];
    foreach ($new_cfg_defaults as $_ck => $_cv) {
        $pdo->prepare("INSERT IGNORE INTO {$prefix}konfiguracja (nazwa, wartosc) VALUES (:n, :v)")
            ->execute([':n' => $_ck, ':v' => $_cv]);
    }
    // Reload fresh counts after sync
    $ile = admin_ile($pdo, $prefix);
    $cfg = array_merge($cfg, (function() use ($pdo, $prefix) {
        $c = [];
        foreach ($pdo->query("SELECT nazwa,wartosc FROM {$prefix}konfiguracja") as $r) $c[$r['nazwa']] = $r['wartosc'];
        return $c;
    })());

    echo '<div class="admin-section-title">'.t('dashboard_title').'</div>';
    // Stats
    echo '<div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:16px;">';
    $stats = [
        ['🗂️', t('categories'),   ($ile['kat_a']??0)+($ile['kat_n']??0)],
        ['📁', t('subcategories'), ($ile['pod_a']??0)+($ile['pod_n']??0)],
        ['🔗', t('entries'),       ($ile['wpi_a']??0)+($ile['wpi_n']??0)],
        ['👁️', 'Online',          $ile['sescount']??0],
    ];
    foreach ($stats as [$ic,$lb,$cnt]) {
        echo '<div style="background:rgba(255,255,255,0.7);border:1px solid var(--border);border-radius:6px;padding:14px 20px;min-width:130px;text-align:center;">'
            .'<div style="font-size:24px;">'.$ic.'</div>'
            .'<div style="font-size:20px;font-weight:bold;color:var(--blue-dark);">'.(int)$cnt.'</div>'
            .'<div style="font-size:11px;color:#7a9aaa;">'.$lb.'</div>'
            .'</div>';
    }
    echo '</div>';

    // Donation block
    $lang = admin_get_lang();
    echo '<div style="background:rgba(255,255,255,0.7);border:1px solid var(--border);border-radius:8px;padding:16px 20px;margin-bottom:16px;text-align:center;">';
    echo '<form action="https://www.paypal.com/donate" method="post" target="_blank" style="display:inline-block;margin-bottom:8px;">';
    echo '<input type="hidden" name="hosted_button_id" value="TPTCHCJAALCWL" />';
    echo '<input type="image" src="https://www.paypalobjects.com/en_US/i/btn/btn_donate_SM.gif" border="0" name="submit" title="PayPal - The safer, easier way to pay online!" alt="Donate with PayPal button" />';
    echo '<img alt="" border="0" src="https://www.paypal.com/en_PL/i/scr/pixel.gif" width="1" height="1" />';
    echo '</form>';
    echo '<div style="font-size:13px;font-weight:bold;color:#1a4a80;margin-bottom:4px;">' . t('donate_title') . '</div>';
    echo '<div style="font-size:11px;color:#7a9aaa;">' . t('donate_note') . '</div>';
    echo '</div>';

    // Pending entries
    $pend = $pdo->query("SELECT * FROM {$prefix}wpisy WHERE akt='0' ORDER BY data DESC LIMIT 5");
    $pend_rows = $pend->fetchAll();
    if ($pend_rows) {
        echo '<div class="admin-section-title" style="font-size:14px;">⏳ '.t('pending_entries').' ('.count($pend_rows).')</div>';
        echo '<table class="admin-table"><tr><th>'.t('col_title').'</th><th>'.t('col_url').'</th><th>'.t('col_date').'</th><th>'.t('col_actions').'</th></tr>';
        foreach ($pend_rows as $row) {
            $t_e = htmlspecialchars($row['tytul'],ENT_QUOTES,'UTF-8');
            $u_e = htmlspecialchars('http://'.$row['url'].'/'.$row['uri'],ENT_QUOTES,'UTF-8');
            $d_e = date('d-m-Y',(int)$row['data']);
            echo '<tr><td>'.$t_e.'</td><td><a href="'.$u_e.'" target="_blank">'.$u_e.'</a></td><td>'.$d_e.'</td><td>';
            echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="wpi_approve"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.(int)$row['id'].'"><button type="submit" class="btn" style="padding:3px 8px;font-size:11px;">✅</button></form> ';
            echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="wpi_del"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.(int)$row['id'].'"><button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;" onclick="return confirm(\''.t('confirm_delete_entry').'\')">🗑️</button></form>';
            echo '</td></tr>';
        }
        echo '</table>';
    }
    break;

// ============================================================
// KATEGORIE
// ============================================================
case 'kategorie':
    echo '<div class="admin-section-title">📂 '.t('categories').' / '.t('subcategories').'</div>';

    if ($err >= 0 && isset($err_msgs[$err])) {
        $c = ($err===0)?'green':'#c00';
        echo '<div style="color:'.$c.';font-weight:bold;margin-bottom:10px;">'.$err_msgs[$err].'</div>';
    }

    // ===== PENDING CATEGORY SUGGESTIONS =====
    $pend_kats = $pdo->query("SELECT * FROM {$prefix}kategorie WHERE akt='0' ORDER BY data DESC")->fetchAll();
    $pend_pods = $pdo->query("SELECT p.*, k.nazwa as kat_nazwa FROM {$prefix}podkategorie p LEFT JOIN {$prefix}kategorie k ON k.id=p.id_kat WHERE p.akt='0' ORDER BY p.data DESC")->fetchAll();

    if ($pend_kats || $pend_pods) {
        echo '<div style="background:rgba(255,240,200,0.7);border:1px solid rgba(200,150,0,0.4);border-radius:6px;padding:14px 16px;margin-bottom:16px;">';
        echo '<div style="font-weight:bold;font-size:14px;color:#7a4a00;margin-bottom:10px;">⏳ ' . t('sugg_pending') . '</div>';

        if ($pend_kats) {
            echo '<b style="font-size:12px;color:#5a4a00;">' . t('sugg_cats') . ' (' . count($pend_kats) . ')</b>';
            echo '<table class="admin-table" style="margin:6px 0 12px 0;">';
            echo '<tr><th>' . t('col_category') . '</th><th>' . t('col_date') . '</th><th>' . t('col_actions') . '</th></tr>';
            foreach ($pend_kats as $row) {
                $n_e = htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8');
                $d_e = date('d-m-Y', (int)$row['data']);
                echo '<tr><td><b>' . $n_e . '</b></td><td>' . $d_e . '</td><td style="white-space:nowrap;">';
                // Approve
                echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                    . '<input type="hidden" name="option" value="kat_approve">'
                    . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
                    . '<input type="hidden" name="kid" value="' . (int)$row['id'] . '">'
                    . '<button type="submit" class="btn" style="padding:3px 8px;font-size:11px;" title="' . t('activate') . '">✅ ' . t('activate') . '</button>'
                    . '</form> ';
                // Delete
                echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                    . '<input type="hidden" name="option" value="kat_del">'
                    . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
                    . '<input type="hidden" name="kid" value="' . (int)$row['id'] . '">'
                    . '<button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;" onclick="return confirm(\'' . t('confirm_delete') . '\')" title="' . t('delete') . '">🗑️</button>'
                    . '</form>';
                echo '</td></tr>';
            }
            echo '</table>';
        }

        if ($pend_pods) {
            echo '<b style="font-size:12px;color:#5a4a00;">' . t('sugg_subcats') . ' (' . count($pend_pods) . ')</b>';
            echo '<table class="admin-table" style="margin:6px 0 4px 0;">';
            echo '<tr><th>' . t('col_subcat') . '</th><th>' . t('col_category') . '</th><th>' . t('col_date') . '</th><th>' . t('col_actions') . '</th></tr>';
            foreach ($pend_pods as $row) {
                $n_e  = htmlspecialchars($row['nazwa'], ENT_QUOTES, 'UTF-8');
                $kn_e = htmlspecialchars($row['kat_nazwa'] ?? '—', ENT_QUOTES, 'UTF-8');
                $d_e  = date('d-m-Y', (int)$row['data']);
                echo '<tr><td><b>' . $n_e . '</b></td><td>' . $kn_e . '</td><td>' . $d_e . '</td><td style="white-space:nowrap;">';
                // Approve
                echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                    . '<input type="hidden" name="option" value="pod_approve">'
                    . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
                    . '<input type="hidden" name="pid" value="' . (int)$row['id'] . '">'
                    . '<button type="submit" class="btn" style="padding:3px 8px;font-size:11px;">✅ ' . t('activate') . '</button>'
                    . '</form> ';
                // Delete
                echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                    . '<input type="hidden" name="option" value="pod_del">'
                    . '<input type="hidden" name="csrf_token" value="' . $csrf . '">'
                    . '<input type="hidden" name="pid" value="' . (int)$row['id'] . '">'
                    . '<button type="submit" class="btn btn-danger" style="padding:3px 8px;font-size:11px;" onclick="return confirm(\'' . t('confirm_delete') . '\')">🗑️</button>'
                    . '</form>';
                echo '</td></tr>';
            }
            echo '</table>';
        }
        echo '</div>';
    }

    // Add category form
    echo '<div style="background:rgba(255,255,255,0.6);border:1px solid var(--border);border-radius:6px;padding:12px 16px;margin-bottom:16px;">';
    echo '<b>➕ '.t('new_category').'</b><br/><br/>';
    echo '<form method="post" action="index.php?a=kategorie" style="display:flex;gap:8px;align-items:center;">';
    echo '<input type="hidden" name="option" value="dodaj_kat"><input type="hidden" name="csrf_token" value="'.$csrf.'">';
    echo '<input type="text" name="kat" placeholder="'.t('cat_name_placeholder').'" style="width:280px;" />';
    echo '<button type="submit" class="btn" style="width:auto;padding:8px 16px;">+ '.t('add').'</button></form></div>';

    // Category list with inline subcategory expand
    $kats = $pdo->query("SELECT * FROM {$prefix}kategorie ORDER BY data DESC, id DESC")->fetchAll();
    if ($kats) {
        echo '<table class="admin-table">';
        echo '<tr><th>'.t('col_category').'</th><th>'.t('col_active').'</th><th>'.t('col_entries').'</th><th>'.t('col_subcats').'</th><th>'.t('col_actions').'</th></tr>';
        foreach ($kats as $row) {
            $n_e = htmlspecialchars($row['nazwa'],ENT_QUOTES,'UTF-8');
            $al  = $row['akt'] ? '<span style="color:green;">✅</span>' : '<span style="color:#aaa;">⬜</span>';
            $kid = (int)$row['id'];
            echo '<tr>';
            echo '<td><a href="#" onclick="toggleSub('.$kid.');return false;">▶</a> '.$n_e.'</td>';
            echo '<td>'.$al.'</td><td>'.(int)$row['wpi_a'].'</td><td>'.(int)$row['pod_a'].'</td>';
            echo '<td style="white-space:nowrap;">';
            // Move UP
            echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                .'<input type="hidden" name="option" value="kat_move">'
                .'<input type="hidden" name="csrf_token" value="'.$csrf.'">'
                .'<input type="hidden" name="kid" value="'.$kid.'">'
                .'<input type="hidden" name="dir" value="up">'
                .'<button type="submit" class="btn" style="padding:2px 7px;font-size:13px;background:#5a8ab0;" title="'.t('move_up').'">▲</button>'
                .'</form> ';
            // Move DOWN
            echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                .'<input type="hidden" name="option" value="kat_move">'
                .'<input type="hidden" name="csrf_token" value="'.$csrf.'">'
                .'<input type="hidden" name="kid" value="'.$kid.'">'
                .'<input type="hidden" name="dir" value="down">'
                .'<button type="submit" class="btn" style="padding:2px 7px;font-size:13px;background:#5a8ab0;" title="'.t('move_down').'">▼</button>'
                .'</form> ';
            // Toggle active
            echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                .'<input type="hidden" name="option" value="kat_toggle">'
                .'<input type="hidden" name="csrf_token" value="'.$csrf.'">'
                .'<input type="hidden" name="kid" value="'.$kid.'">'
                .'<button type="submit" class="btn" style="padding:2px 7px;font-size:11px;" title="'.t('toggle_active').'">🔄</button>'
                .'</form> ';
            // Delete
            echo '<form method="post" action="index.php?a=kategorie" style="display:inline">'
                .'<input type="hidden" name="option" value="kat_del">'
                .'<input type="hidden" name="csrf_token" value="'.$csrf.'">'
                .'<input type="hidden" name="kid" value="'.$kid.'">'
                .'<button type="submit" class="btn btn-danger" style="padding:2px 7px;font-size:11px;" onclick="return confirm(\''.t('confirm_delete_cat').'\')" title="'.t('delete').'">🗑️</button>'
                .'</form>';
            echo '</td></tr>';

            // Inline subcategories row (hidden by default)
            echo '<tr id="sub_'.$kid.'" style="display:none;background:rgba(220,235,250,0.5);">';
            echo '<td colspan="5" style="padding:8px 16px;">';
            // Subcategory list
            $pods = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id_kat=:k ORDER BY nazwa");
            $pods->execute([':k'=>$kid]);
            $pods_rows = $pods->fetchAll();
            if ($pods_rows) {
                echo '<table style="width:100%;font-size:12px;"><tr><th>'.t('col_subcat').'</th><th>'.t('col_active2').'</th><th>'.t('col_entries2').'</th><th>'.t('col_actions').'</th></tr>';
                foreach ($pods_rows as $p) {
                    $pn = htmlspecialchars($p['nazwa'],ENT_QUOTES,'UTF-8');
                    $pa = $p['akt'] ? '✅' : '⬜';
                    $pid = (int)$p['id'];
                    echo '<tr><td>'.$pn.'</td><td>'.$pa.'</td><td>'.(int)$p['wpi_a'].'</td>';
                    echo '<td><a href="index.php?a=pod_edit&id='.$pid.'" style="font-size:11px;">edytuj</a></td></tr>';
                }
                echo '</table>';
            }
            // Add subcategory form
            echo '<form method="post" action="index.php?a=kategorie" style="margin-top:8px;display:flex;gap:6px;align-items:center;">';
            echo '<input type="hidden" name="option" value="dodaj_pod"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="kat_id" value="'.$kid.'">';
            echo '<input type="text" name="pod" placeholder="'.t('new_subcat_placeholder').'" style="width:220px;font-size:12px;" />';
            echo '<button type="submit" class="btn" style="width:auto;padding:5px 12px;font-size:12px;">'.t('add_subcat_btn').'</button></form>';
            echo '</td></tr>';
        }
        echo '</table>';
    }
    echo '<script>function toggleSub(id){var r=document.getElementById("sub_"+id);r.style.display=r.style.display==="none"?"table-row":"none";}</script>';
    break;

// ============================================================
// KONFIGURACJA
// ============================================================
case 'cfg':
    echo '<div class="admin-section-title">⚙️ '.t('config_title').'</div>';
    if (($_GET['saved']??'')==='1')
        echo '<div style="color:green;margin-bottom:8px;">✅ '.t('saved').'</div>';

    // Ensure opr/opr_key exist in DB for existing installations (BEFORE rendering form)
    $cfg_new_keys = ['opr' => '0', 'opr_key' => '', 'mail_method' => 'mail', 'mail_admin' => '', 'smtp_host' => '', 'smtp_port' => '587', 'smtp_user' => '', 'smtp_pass' => '', 'smtp_secure' => 'tls', 'cookie_enable' => '0', 'cookie_msg' => 'Ta strona używa plików cookie.', 'terms_required' => '0'];
    foreach ($cfg_new_keys as $_ck => $_cv) {
        $pdo->prepare("INSERT IGNORE INTO {$prefix}konfiguracja (nazwa, wartosc) VALUES (:n, :v)")
            ->execute([':n' => $_ck, ':v' => $_cv]);
    }
    // Reload cfg to get any newly inserted defaults
    $cfg = (function() use ($pdo, $prefix) {
        $c = [];
        foreach ($pdo->query("SELECT nazwa,wartosc FROM {$prefix}konfiguracja") as $r) {
            $c[$r['nazwa']] = $r['wartosc'];
        }
        return $c;
    })();

    $c = $cfg; // shortcut - now guaranteed to have opr/opr_key

    echo '<form method="post" action="index.php?a=cfg">';
    echo '<input type="hidden" name="option" value="save_cfg" />';
    echo '<input type="hidden" name="csrf_token" value="'.htmlspecialchars($csrf,ENT_QUOTES,'UTF-8').'" />';

    // --- Helper functions for rendering
    $row_text = function(string $label, string $name, string $hint='', int $maxlen=255) use ($c) {
        $v = htmlspecialchars($c[$name]??'',ENT_QUOTES,'UTF-8');
        echo '<tr><td class="cfg-label">'.$label.'</td><td class="cfg-val">';
        echo '<input type="text" name="'.$name.'" value="'.$v.'" maxlength="'.$maxlen.'" class="cfg-input" />';
        if ($hint) echo '<div class="cfg-hint">'.$hint.'</div>';
        echo '</td></tr>';
    };
    $row_textarea = function(string $label, string $name, string $hint='') use ($c) {
        $v = htmlspecialchars($c[$name]??'',ENT_QUOTES,'UTF-8');
        echo '<tr><td class="cfg-label">'.$label.'</td><td class="cfg-val">';
        echo '<textarea name="'.$name.'" rows="3" class="cfg-input">'.$v.'</textarea>';
        if ($hint) echo '<div class="cfg-hint">'.$hint.'</div>';
        echo '</td></tr>';
    };
    $row_radio = function(string $label, string $name, array $opts, string $hint='') use ($c) {
        $cur = $c[$name]??'';
        echo '<tr><td class="cfg-label">'.$label.'</td><td class="cfg-val">';
        foreach ($opts as $val=>$lbl) {
            $chk = ($cur==$val)?' checked':'';
            echo '<label class="cfg-radio"><input type="radio" name="'.$name.'" value="'.htmlspecialchars($val,ENT_QUOTES,'UTF-8').'"'.$chk.'> '
                .htmlspecialchars($lbl,ENT_QUOTES,'UTF-8').'</label>';
        }
        if ($hint) echo '<div class="cfg-hint">'.$hint.'</div>';
        echo '</td></tr>';
    };

    ?>
    <style>
    .cfg-section{font-size:15px;font-weight:bold;color:var(--blue-dark,#1a4a80);
      background:rgba(168,204,238,0.3);padding:8px 12px;margin:16px 0 0 0;
      border-left:4px solid var(--blue-mid,#3a80c0);border-radius:0 4px 4px 0;}
    .cfg-table{width:100%;border-collapse:collapse;margin-bottom:4px;}
    .cfg-table tr:hover td{background:rgba(200,225,250,0.2);}
    .cfg-label{width:280px;padding:7px 12px;font-size:12px;font-weight:bold;
      color:#2a4a6a;vertical-align:top;border-bottom:1px solid rgba(60,130,200,0.1);}
    .cfg-val{padding:5px 8px;border-bottom:1px solid rgba(60,130,200,0.1);}
    .cfg-input{width:100%;max-width:440px;padding:5px 8px;border:1px solid rgba(60,130,200,0.35);
      border-radius:3px;font-size:12px;background:rgba(255,255,255,0.85);color:#1a2a3a;}
    .cfg-input:focus{border-color:#3a80c0;outline:none;}
    .cfg-hint{font-size:11px;color:#7a9aaa;margin-top:2px;}
    .cfg-radio{margin-right:14px;font-size:12px;font-weight:normal;cursor:pointer;}
    textarea.cfg-input{resize:vertical;min-height:60px;}
    </style>

    <?php

    // ===== INFORMACJE OGÓLNE =====
    echo '<div class="cfg-section">'.t('cfg_general').'</div><table class="cfg-table">';
    $row_text(t('cfg_dir_title'),'o1',t('cfg_dir_title_h'));
    $row_text(t('cfg_dir_desc'),'o2',t('cfg_dir_desc_h'),255);
    $row_text(t('cfg_dir_kw'),'o3',t('cfg_dir_kw_h'),255);
    $row_text(t('cfg_dir_url'),'o4',t('cfg_dir_url_h'));
    $row_text(t('cfg_main_file'),'f1',t('cfg_main_file_h'));
    echo '</table>';

    // ===== STRONA GŁÓWNA =====
    echo '<div class="cfg-section">'.t('cfg_homepage').'</div><table class="cfg-table">';
    $row_radio(t('cfg_cols'),'g1',['1'=>'1','2'=>'2','3'=>'3','4'=>'4']);
    $row_radio(t('cfg_show_sub'),'g2',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_how_many_sub'),'g3',['3'=>'3','6'=>'6','9'=>'9']);
    $row_radio(t('cfg_sub_layout'),'g4',['1'=>t('cfg_sub_layout_col'),'2'=>t('cfg_sub_layout_row')]);
    $row_radio(t('cfg_entry_count'),'g5',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_entry_count2'),'iw',['1'=>t('cfg_yes'),'0'=>t('cfg_no')],t('cfg_entry_count_h'));
    echo '</table>';

    // ===== KATEGORIE =====
    echo '<div class="cfg-section">'.t('cfg_categories').'</div><table class="cfg-table">';
    $row_radio(t('cfg_subcols'),'k1',['1'=>'1','2'=>'2','3'=>'3','4'=>'4']);
    $row_radio(t('cfg_recent'),'k2',['1'=>t('cfg_yes'),'0'=>t('cfg_no')],t('cfg_recent_h'));
    $row_radio(t('cfg_recent_how'),'k3',['3'=>'3','6'=>'6','9'=>'9']);
    echo '</table>';

    // ===== PODKATEGORIE I SZCZEGÓŁY =====
    echo '<div class="cfg-section">'.t('cfg_subcats').'</div><table class="cfg-table">';
    $row_radio(t('cfg_perpage'),'p1',['10'=>'10','15'=>'15','20'=>'20']);
    $row_radio(t('cfg_thumbs'),'min',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_details'),'p2',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    echo '</table>';

    // ===== PRAWA UŻYTKOWNIKÓW =====
    echo '<div class="cfg-section">'.t('cfg_users').'</div><table class="cfg-table">';
    $row_radio(t('cfg_addcat'),'u1',['1'=>t('cfg_yes'),'2'=>t('cfg_sugg'),'3'=>t('cfg_no')]);
    $row_radio(t('cfg_addsub'),'u2',['1'=>t('cfg_yes'),'2'=>t('cfg_sugg'),'3'=>t('cfg_no')]);
    $row_radio(t('cfg_addentry'),'u3',['1'=>t('cfg_yes'),'2'=>t('cfg_sugg'),'3'=>t('cfg_no')]);
    $row_radio(t('cfg_maxsub'),'u4',['1'=>'1','3'=>'3','10'=>'10','0'=>t('cfg_maxsub_none')]);
    echo '</table>';

    // ===== OPCJE ZAAWANSOWANE =====
    echo '<div class="cfg-section">'.t('cfg_advanced').'</div><table class="cfg-table">';
    $row_radio(t('cfg_fetch'),'w1',['1'=>'file_get_contents','2'=>'fopen','3'=>'cURL']);
    $row_radio(t('cfg_newtab'),'w2',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_newtab_method'),'w3',['1'=>t('cfg_newtab_html'),'2'=>t('cfg_newtab_js')]);
    $row_radio(t('cfg_nofollow'),'w4',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_direct'),'w5',['1'=>t('cfg_direct_yes'),'2'=>t('cfg_direct_no')]);
    $row_radio(t('cfg_mail_notify'),'pm',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    echo '</table>';

    // ===== PRZYJAZNE URLe =====
    echo '<div class="cfg-section">'.t('cfg_urls').'</div><table class="cfg-table">';
    $row_radio(t('cfg_url_rewrite'),'m1',['3'=>t('cfg_url_seo'),'1'=>t('cfg_url_mod'),'0'=>t('cfg_url_off')]);
    $row_radio(t('cfg_url_sep'),'m2',['-'=>t('cfg_url_sep_dash'),'_'=>t('cfg_url_sep_under'),','=>t('cfg_url_sep_comma')]);
    $row_text(t('cfg_url_cat'),'m3',t('cfg_url_cat_h'));
    $row_text(t('cfg_url_sub'),'m4',t('cfg_url_sub_h'));
    $row_text(t('cfg_url_det'),'m5',t('cfg_url_det_h'));
    $row_text(t('cfg_url_inf'),'m6',t('cfg_url_inf_h'));
    $row_radio(t('cfg_url_errmode'),'m7',['1'=>t('cfg_url_err1'),'2'=>t('cfg_url_err2'),'3'=>t('cfg_url_err3')]);
    echo '</table>';

    // ===== MAPY STRON XML =====
    echo '<div class="cfg-section">'.t('cfg_sitemap').'</div><table class="cfg-table">';
    $row_text(t('cfg_sitemap_perfile'),'s1',t('cfg_sitemap_perfile_h'));
    $row_text(t('cfg_sitemap_google'),'s2','');
    $row_radio(t('cfg_sitemap_type'),'s3',['1'=>'.xml','2'=>t('cfg_sitemap_gz')]);
    echo '</table>';

    // ===== MODYFIKACJE =====
    echo '<div class="cfg-section">'.t('cfg_tags').'</div><table class="cfg-table">';
    $row_radio(t('cfg_loktag'),'loktag',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_glotag'),'glotag',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_text(t('cfg_glotag_min'),'glotag_min',t('cfg_glotag_min_h'));
    $row_text(t('cfg_glotag_ilo'),'glotag_ilo',t('cfg_glotag_ilo_h'));
    $row_radio(t('cfg_anchor'),'anchor',['1'=>t('cfg_yes'),'0'=>t('cfg_no')],t('cfg_anchor_h'));
    $row_text(t('cfg_anchor_ilo'),'anchor_ilo','');
    $row_text(t('cfg_anchor_opi'),'anchor_opi',t('cfg_anchor_opi_h'));
    $row_radio(t('cfg_dodkat'),'dodkat',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_rss'),'rss',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_text(t('cfg_rss_kanal'),'rss_kanal',t('cfg_rss_kanal_h'));
    $row_radio(t('cfg_rss_link'),'rss_link',['1'=>t('cfg_rss_link1'),'2'=>t('cfg_rss_link2'),'0'=>t('cfg_rss_link0')]);
    $row_text(t('cfg_rss_ilo'),'rss_ilo','');
    $row_radio(t('cfg_pob_tresc'),'pob_tresc',['1'=>t('cfg_yes'),'0'=>t('cfg_no')],t('cfg_pob_tresc_h'));
    echo '</table>';

    // ===== LINK ZWROTNY =====
    echo '<div class="cfg-section">'.t('cfg_backlink').'</div><table class="cfg-table">';
    $row_radio(t('cfg_link_zwr'),'link_zwr',['0'=>t('cfg_link_zwr0'),'1'=>t('cfg_link_zwr1'),'2'=>t('cfg_link_zwr2')]);
    $row_radio(t('cfg_link_sor'),'link_sor',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_radio(t('cfg_link_prz'),'link_prz',['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
    $row_text(t('cfg_link_adres'),'link_adres',t('cfg_link_adres_h'));
    $row_text(t('cfg_link_opis'),'link_opis',t('cfg_link_opis_h'),255);
    $row_text(t('cfg_anchor1'),'link_anchor_1','');
    $row_text(t('cfg_anchor2'),'link_anchor_2','');
    $row_text(t('cfg_anchor3'),'link_anchor_3','');
    echo '</table>';

    // ===== POWIADOMIENIA EMAIL =====
    echo '<div class="cfg-section">'.t('cfg_email').'</div><table class="cfg-table">';
    $row_text(t('cfg_mail_from'),'mail_nadaw',t('cfg_mail_from_h'));
    $row_text(t('cfg_mail_name'),'mail_odkog',t('cfg_mail_name_h'));
    $row_text(t('cfg_mail_enc'),'mail_chars',t('cfg_mail_enc_h'));
    $row_text(t('cfg_mail_add_sub'),'maild_tem','');
    $row_textarea(t('cfg_mail_add_body'),'maild_tre',t('cfg_mail_add_body_h'));
    $row_text(t('cfg_mail_del_sub'),'mailu_tem','');
    $row_textarea(t('cfg_mail_del_body'),'mailu_tre','');
    echo '</table>';

    // ===== METODA WYSYŁKI =====
    echo '<div class="cfg-section">' . t('cfg_mail_method_section') . '</div><table class="cfg-table">';
    $row_radio(t('cfg_mail_method'), 'mail_method', ['mail'=>t('cfg_mail_method_mail'), 'smtp'=>t('cfg_mail_method_smtp')], t('cfg_mail_method_h'));
    $row_text(t('cfg_mail_admin'), 'mail_admin', t('cfg_mail_admin_h'));
    echo '</table>';

    // ===== USTAWIENIA SMTP =====
    echo '<div class="cfg-section">' . t('cfg_smtp_section') . '</div><table class="cfg-table">';
    $row_text(t('cfg_smtp_host'), 'smtp_host', t('cfg_smtp_host_h'));
    $row_text(t('cfg_smtp_port'), 'smtp_port', t('cfg_smtp_port_h'));
    $row_radio(t('cfg_smtp_secure'), 'smtp_secure', ['tls'=>t('cfg_smtp_tls'), 'ssl'=>t('cfg_smtp_ssl'), ''=>t('cfg_smtp_none')], '');
    $row_text(t('cfg_smtp_user'), 'smtp_user', t('cfg_smtp_user_h'));
    $row_text(t('cfg_smtp_pass'), 'smtp_pass', t('cfg_smtp_pass_h'));
    echo '</table>';

    // ===== OPEN PAGE RANK =====
    echo '<div class="cfg-section">&#128200; ' . t('cfg_opr') . '</div><table class="cfg-table">';
    $row_radio(t('cfg_opr'), 'opr', ['1' => t('cfg_yes'), '0' => t('cfg_no')], t('cfg_opr_hint'));
    $row_text(t('cfg_opr_key'), 'opr_key', t('cfg_opr_key_hint'));
    echo '</table>';

    echo '<br/><button type="submit" class="btn" style="width:auto;padding:10px 32px;">&#128190; '.t('save').'</button>';
    echo '</form>';
    break;

// ============================================================
// PLATNOSCI
// ============================================================
case 'cookie':
    // Save cookie settings
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['option'] ?? '') === 'save_cookie') {
        if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('CSRF error');
        $pdo->prepare("INSERT INTO {$prefix}konfiguracja (nazwa,wartosc) VALUES ('cookie_enable',:v) ON DUPLICATE KEY UPDATE wartosc=:v2")
            ->execute([':v'=>($_POST['cookie_enable']??'0'), ':v2'=>($_POST['cookie_enable']??'0')]);
        $pdo->prepare("INSERT INTO {$prefix}konfiguracja (nazwa,wartosc) VALUES ('cookie_msg',:v) ON DUPLICATE KEY UPDATE wartosc=:v2")
            ->execute([':v'=>substr(strip_tags($_POST['cookie_msg']??''),0,500), ':v2'=>substr(strip_tags($_POST['cookie_msg']??''),0,500)]);
        $pdo->prepare("INSERT INTO {$prefix}konfiguracja (nazwa,wartosc) VALUES ('terms_required',:v) ON DUPLICATE KEY UPDATE wartosc=:v2")
            ->execute([':v'=>($_POST['terms_required']??'0'), ':v2'=>($_POST['terms_required']??'0')]);
        header('Location: index.php?a=cookie&saved=1'); exit;
    }
    echo '<div class="admin-section-title">🍪 ' . t('cookie_title') . '</div>';
    if (($_GET['saved']??'') === '1') echo '<div style="color:green;margin-bottom:10px;">✅ ' . t('cookie_saved') . '</div>';
    $cfg_r = [];
    foreach ($pdo->query("SELECT nazwa,wartosc FROM {$prefix}konfiguracja") as $r) $cfg_r[$r['nazwa']]=$r['wartosc'];
    echo '<form method="post" action="index.php?a=cookie">';
    echo '<input type="hidden" name="option" value="save_cookie">';
    echo '<input type="hidden" name="csrf_token" value="'.$csrf.'">';
    echo '<table class="cfg-table" style="max-width:600px;">';
    // Cookie enable
    $ce = $cfg_r['cookie_enable'] ?? '0';
    echo '<tr><td class="cfg-label"><b>' . t('cookie_enable') . '</b></td><td class="cfg-val">';
    echo '<label class="cfg-radio"><input type="radio" name="cookie_enable" value="1"' . ($ce=='1'?' checked':'') . '> ' . t('cfg_yes') . '</label>';
    echo '<label class="cfg-radio"><input type="radio" name="cookie_enable" value="0"' . ($ce!='1'?' checked':'') . '> ' . t('cfg_no') . '</label>';
    echo '</td></tr>';
    // Cookie message
    $cm = htmlspecialchars($cfg_r['cookie_msg'] ?? t('cookie_message_default'), ENT_QUOTES, 'UTF-8');
    echo '<tr><td class="cfg-label"><b>' . t('cookie_message_label') . '</b></td><td class="cfg-val">';
    echo '<textarea name="cookie_msg" rows="3" style="width:100%;font-size:12px;border:1px solid #b0c8e0;border-radius:3px;padding:5px;">' . $cm . '</textarea>';
    echo '</td></tr>';
    // Terms required
    $tr2 = $cfg_r['terms_required'] ?? '0';
    echo '<tr><td class="cfg-label"><b>' . t('terms_accept') . ' ' . t('terms_link_text') . '</b> — ' . t('terms_required') . '</td><td class="cfg-val">';
    echo '<label class="cfg-radio"><input type="radio" name="terms_required" value="1"' . ($tr2=='1'?' checked':'') . '> ' . t('cfg_yes') . '</label>';
    echo '<label class="cfg-radio"><input type="radio" name="terms_required" value="0"' . ($tr2!='1'?' checked':'') . '> ' . t('cfg_no') . '</label>';
    echo '</td></tr>';
    echo '</table>';
    echo '<br/><button type="submit" class="btn" style="width:auto;padding:10px 32px;">💾 ' . t('save') . '</button>';
    echo '</form>';
    break;

case 'payments':
    // Save PayPal settings
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['option'] ?? '') === 'save_paypal') {
        if (!hash_equals($csrf, $_POST['csrf_token'] ?? '')) die('CSRF error');
        $pp_fields = [
            'pp_enable','pp_mode','pp_email','pp_client_id','pp_secret',
            'pp_price','pp_currency','pp_return_url','pp_cancel_url',
            'pp_item_name','pp_msg_pending','pp_msg_success','pp_msg_error',
        ];
        foreach ($pp_fields as $f) {
            $v = substr(strip_tags(trim($_POST[$f] ?? '')), 0, 500);
            $pdo->prepare("INSERT INTO {$prefix}konfiguracja (nazwa,wartosc) VALUES (:n,:v) ON DUPLICATE KEY UPDATE wartosc=:v2")
                ->execute([':n'=>$f, ':v'=>$v, ':v2'=>$v]);
        }
        header('Location: index.php?a=payments&ptab=paypal&saved=1'); exit;
    }

    echo '<div class="admin-section-title">&#128179; ' . t('payments_title') . '</div>';
    $pay_tab = $_GET['ptab'] ?? 'paypal';

    // Sub-tabs
    echo '<div style="display:flex;gap:0;margin:12px 0 0 0;border-bottom:2px solid var(--blue-light,#a8ccee);">';
    foreach (['paypal'=>t('pay_tab_paypal'),'stripe'=>t('pay_tab_stripe'),'p24'=>t('pay_tab_p24')] as $pt=>$plabel) {
        $ps = ($pay_tab===$pt) ? 'background:rgba(255,255,255,0.9);font-weight:bold;border-bottom:2px solid white;' : 'background:rgba(200,220,240,0.4);';
        echo '<a href="index.php?a=payments&ptab='.$pt.'" style="padding:8px 20px;text-decoration:none;color:var(--blue-dark,#1a4a80);'.$ps.'">'.$plabel.'</a>';
    }
    echo '</div>';
    echo '<div style="background:rgba(255,255,255,0.75);border:1px solid var(--border);border-top:none;padding:20px 24px;border-radius:0 0 6px 6px;">';

    if ($pay_tab === 'paypal') {
        if (($_GET['saved']??'') === '1') echo '<div style="color:green;margin-bottom:12px;">✅ ' . t('pp_saved') . '</div>';

        // Load current PayPal config
        $pp = [];
        foreach ($pdo->query("SELECT nazwa,wartosc FROM {$prefix}konfiguracja WHERE nazwa LIKE 'pp_%'") as $r) {
            $pp[$r['nazwa']] = $r['wartosc'];
        }
        $pp_defaults = [
            'pp_enable'=>'0','pp_mode'=>'sandbox','pp_email'=>'','pp_client_id'=>'',
            'pp_secret'=>'','pp_price'=>'0.00','pp_currency'=>'PLN',
            'pp_return_url'=>'','pp_cancel_url'=>'',
            'pp_item_name'   => t('pp_item_name_def'),
            'pp_msg_pending' => t('pp_msg_pending_def'),
            'pp_msg_success' => t('pp_msg_success_def'),
            'pp_msg_error'   => t('pp_msg_error_def'),
        ];
        foreach ($pp_defaults as $k=>$v) if (!isset($pp[$k])) $pp[$k]=$v;

        // IPN URL
        $ipn_url = rtrim($cfg['o4'] ?? ('http://'.($_SERVER['HTTP_HOST']??'')), '/') . '/index.php?a=paypal_ipn';

        echo '<form method="post" action="index.php?a=payments&ptab=paypal">';
        echo '<input type="hidden" name="option" value="save_paypal">';
        echo '<input type="hidden" name="csrf_token" value="'.$csrf.'">';

        // How it works box
        echo '<div style="background:#e8f4e8;border:1px solid #80c080;border-radius:6px;padding:12px 16px;margin-bottom:16px;font-size:12px;line-height:1.9;">';
        echo '<b>' . t('pp_how_title') . '</b><br>';
        echo '1️⃣ ' . t('pp_how_1') . '<br>';
        echo '2️⃣ ' . t('pp_how_2') . '<br>';
        echo '3️⃣ ' . t('pp_how_3') . '<br>';
        echo '4️⃣ ' . t('pp_how_4') . '<br>';
        echo '5️⃣ ' . t('pp_how_5') . '<br>';
        echo '</div>';

        // IPN URL info
        echo '<div style="background:#fff8e0;border:1px solid #e0c040;border-radius:4px;padding:10px 14px;margin-bottom:16px;font-size:12px;">';
        echo '<b>' . t('pp_ipn_url') . '</b><br>';
        echo '<code style="background:#f0f0f0;padding:3px 8px;border-radius:3px;user-select:all;">' . htmlspecialchars($ipn_url, ENT_QUOTES,'UTF-8') . '</code>';
        echo '<br><small>' . t('pp_ipn_enter') . '</small>';
        echo '</div>';

        // Config table
        $r_text = function(string $label, string $name, string $hint='', string $type='text') use ($pp) {
            $v = htmlspecialchars($pp[$name]??'', ENT_QUOTES,'UTF-8');
            echo '<tr><td class="cfg-label"><b>'.$label.'</b>';
            if ($hint) echo '<div class="cfg-hint">'.$hint.'</div>';
            echo '</td><td class="cfg-val">';
            if ($type==='textarea') echo '<textarea name="'.$name.'" rows="2" style="width:100%;font-size:12px;border:1px solid #b0c8e0;border-radius:3px;padding:4px;">'.$v.'</textarea>';
            else echo '<input type="'.$type.'" name="'.$name.'" value="'.$v.'" class="cfg-input" />';
            echo '</td></tr>';
        };
        $r_radio = function(string $label, string $name, array $opts, string $hint='') use ($pp) {
            $cur = $pp[$name]??'';
            echo '<tr><td class="cfg-label"><b>'.$label.'</b>';
            if ($hint) echo '<div class="cfg-hint">'.$hint.'</div>';
            echo '</td><td class="cfg-val">';
            foreach ($opts as $val=>$lbl) {
                $chk = ($cur==$val)?' checked':'';
                echo '<label class="cfg-radio"><input type="radio" name="'.$name.'" value="'.htmlspecialchars($val,ENT_QUOTES,'UTF-8').'"'.$chk.'> '.htmlspecialchars($lbl,ENT_QUOTES,'UTF-8').'</label>';
            }
            echo '</td></tr>';
        };

        echo '<table class="cfg-table">';

        // Enable / Mode
        echo '<tr><td colspan="2" style="background:rgba(168,204,238,0.3);padding:8px 12px;font-weight:bold;font-size:14px;color:#1a4a80;">⚙️ ' . t('pp_section') . '</td></tr>';
        $r_radio(t('pp_enable'), 'pp_enable', ['1'=>t('cfg_yes'),'0'=>t('cfg_no')]);
        $r_radio(t('pp_mode'), 'pp_mode', ['sandbox'=>t('pp_mode_sandbox'),'live'=>t('pp_mode_live')]);

        // Account
        echo '<tr><td colspan="2" style="background:rgba(168,204,238,0.3);padding:8px 12px;font-weight:bold;font-size:13px;color:#1a4a80;">🔑 ' . t('pp_email') . ' / API</td></tr>';
        $r_text(t('pp_email'), 'pp_email', t('pp_email_h'), 'email');
        $r_text(t('pp_client_id'), 'pp_client_id', t('pp_client_id_h'));
        $r_text(t('pp_secret'), 'pp_secret', t('pp_secret_h'), 'password');

        // Price
        echo '<tr><td colspan="2" style="background:rgba(168,204,238,0.3);padding:8px 12px;font-weight:bold;font-size:13px;color:#1a4a80;">💰 ' . t('pp_price') . '</td></tr>';
        $r_text(t('pp_price'), 'pp_price', t('pp_price_h'));
        $r_radio(t('pp_currency'), 'pp_currency', ['PLN'=>'PLN','EUR'=>'EUR','USD'=>'USD','GBP'=>'GBP']);
        $r_text(t('pp_item_name'), 'pp_item_name', '');

        // URLs
        echo '<tr><td colspan="2" style="background:rgba(168,204,238,0.3);padding:8px 12px;font-weight:bold;font-size:13px;color:#1a4a80;">🔗 URL</td></tr>';
        $r_text(t('pp_return_url'), 'pp_return_url', t('pp_return_url_h'));
        $r_text(t('pp_cancel_url'), 'pp_cancel_url', t('pp_cancel_url_h'));

        // Messages
        echo '<tr><td colspan="2" style="background:rgba(168,204,238,0.3);padding:8px 12px;font-weight:bold;font-size:13px;color:#1a4a80;">💬 ' . t('cfg_email') . '</td></tr>';
        $r_text(t('pp_msg_pending'), 'pp_msg_pending', '', 'textarea');
        $r_text(t('pp_msg_success'), 'pp_msg_success', '', 'textarea');
        $r_text(t('pp_msg_error'),   'pp_msg_error',   '', 'textarea');

        echo '</table>';
        echo '<br/><button type="submit" class="btn" style="width:auto;padding:10px 32px;">💾 ' . t('save') . '</button>';
        echo '</form>';

    } elseif ($pay_tab === 'stripe' || $pay_tab === 'p24') {
        echo '<div style="color:#7a9aaa;font-style:italic;padding:20px 0;">' . t('payments_coming_soon') . ' ⏳</div>';
    }

    echo '</div>';
    break;

// ============================================================
// REDIRECT: sidebar links ?a=kat&id=X and ?a=pod&id=X
// ============================================================
case 'kat':
case 'pod':
    header('Location: index.php?a=kategorie'); exit;

// ============================================================
// POD EDIT
// ============================================================
case 'pod_edit':
    $pid = (int)($_GET['id'] ?? 0);
    $pod_row = $pdo->prepare("SELECT p.*, k.nazwa as kat_nazwa FROM {$prefix}podkategorie p LEFT JOIN {$prefix}kategorie k ON k.id=p.id_kat WHERE p.id=:id");
    $pod_row->execute([':id' => $pid]); $pod_row = $pod_row->fetch();
    if (!$pod_row) { header('Location: index.php?a=kategorie'); exit; }
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && hash_equals($csrf, $_POST['csrf_token'] ?? '')) {
        $new_name = htmlspecialchars(substr(strip_tags(trim($_POST['nazwa'] ?? '')), 0, 255), ENT_QUOTES, 'UTF-8');
        if (strlen($new_name) >= 2) {
            $pdo->prepare("UPDATE {$prefix}podkategorie SET nazwa=:n WHERE id=:id")->execute([':n' => $new_name, ':id' => $pid]);
        }
        header('Location: index.php?a=kategorie&err=0'); exit;
    }
    echo '<div class="admin-section-title">✏️ ' . t('edit') . ': ' . htmlspecialchars($pod_row['nazwa'], ENT_QUOTES, 'UTF-8') . '</div>';
    echo '<div style="font-size:12px;color:#7a9aaa;margin-bottom:10px;">' . t('category') . ': <b>' . htmlspecialchars($pod_row['kat_nazwa'] ?? '', ENT_QUOTES, 'UTF-8') . '</b></div>';
    echo '<form method="post" action="index.php?a=pod_edit&id=' . $pid . '">';
    echo '<input type="hidden" name="csrf_token" value="' . $csrf . '">';
    echo '<input type="text" name="nazwa" value="' . htmlspecialchars($pod_row['nazwa'], ENT_QUOTES, 'UTF-8') . '" style="width:300px;padding:6px;" />';
    echo ' <button type="submit" class="btn" style="width:auto;padding:6px 20px;">💾 ' . t('save') . '</button>';
    echo ' <a href="index.php?a=kategorie" class="btn" style="background:#888;width:auto;padding:6px 16px;text-decoration:none;">↩ ' . t('cancel') . '</a>';
    echo '</form>';
    break;
    $wid = (int)($_GET['id']??0);
    $st  = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE id=:id");
    $st->execute([':id'=>$wid]); $wpi = $st->fetch();
    if (!$wpi) { header('Location: index.php'); exit; }
    echo '<div class="admin-section-title">'.t('entry_title').': '.htmlspecialchars($wpi['tytul'],ENT_QUOTES,'UTF-8').'</div>';
    echo '<p>'.t('entry_url').': '.htmlspecialchars('http://'.$wpi['url'].'/'.$wpi['uri'],ENT_QUOTES,'UTF-8').'</p>';
    echo '<p>'.t('entry_desc').': '.htmlspecialchars($wpi['opis'],ENT_QUOTES,'UTF-8').'</p>';
    echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="wpi_approve"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.$wid.'"><button type="submit" class="btn">'.t('entry_approve').'</button></form> ';
    echo '<form method="post" style="display:inline"><input type="hidden" name="option" value="wpi_del"><input type="hidden" name="csrf_token" value="'.$csrf.'"><input type="hidden" name="wid" value="'.$wid.'"><button type="submit" class="btn btn-danger" onclick="return confirm(\''.t('confirm_delete').'\')">'.t('entry_delete').'</button></form>';
    break;

// ============================================================
// XML IMPORT (oddzielna zakładka)
// ============================================================
case 'xml_import':
    include __DIR__ . '/xml_import.php';
    break;
}

admin_site_footer();
