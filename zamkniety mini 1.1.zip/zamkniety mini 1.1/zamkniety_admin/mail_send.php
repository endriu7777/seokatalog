<?php
// Zamknięty mini v1.0 - mail_send.php
// Uniwersalna funkcja wysyłki e-mail (PHP mail() lub SMTP)
// Używana przez mail_dodano.php i mail_usunieto.php

function zm_send_mail(array $cfg, string $to, string $subject, string $html_body): bool
{
    $method   = $cfg['mail_method'] ?? 'mail'; // 'mail' or 'smtp'
    $from_addr = $cfg['mail_nadaw']  ?? '';
    $from_name = $cfg['mail_odkog']  ?? 'Administrator';
    $charset   = $cfg['mail_chars']  ?? 'UTF-8';

    $headers  = "From: =?{$charset}?B?" . base64_encode($from_name) . "?= <{$from_addr}>\r\n";
    $headers .= "Reply-To: {$from_addr}\r\n";
    $headers .= "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset={$charset}\r\n";
    $headers .= "X-Mailer: ZamkniętyMini/1.0\r\n";

    $enc_subject = '=?' . $charset . '?B?' . base64_encode($subject) . '?=';

    if ($method === 'smtp') {
        return zm_smtp_send($cfg, $to, $subject, $html_body, $from_addr, $from_name);
    }

    // PHP mail()
    return @mail($to, $enc_subject, $html_body, $headers);
}

function zm_smtp_send(array $cfg, string $to, string $subject, string $html_body, string $from_addr, string $from_name): bool
{
    $host     = $cfg['smtp_host']     ?? '';
    $port     = (int)($cfg['smtp_port'] ?? 587);
    $user     = $cfg['smtp_user']     ?? '';
    $pass     = $cfg['smtp_pass']     ?? '';
    $secure   = $cfg['smtp_secure']   ?? 'tls'; // 'tls', 'ssl', or ''
    $charset  = $cfg['mail_chars']    ?? 'UTF-8';

    if (empty($host) || empty($user)) return false;

    try {
        $ctx = stream_context_create(['ssl' => [
            'verify_peer'       => false,
            'verify_peer_name'  => false,
            'allow_self_signed' => true,
        ]]);

        $prefix = ($secure === 'ssl') ? 'ssl://' : '';
        $sock = @stream_socket_client("{$prefix}{$host}:{$port}", $errno, $errstr, 15, STREAM_CLIENT_CONNECT, $ctx);
        if (!$sock) return false;

        $read = function() use ($sock) { return fgets($sock, 1024); };
        $write = function(string $cmd) use ($sock) { fwrite($sock, $cmd . "\r\n"); };

        $read(); // 220 greeting

        $write('EHLO ' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
        while (($line = $read()) !== false) {
            if (substr($line, 3, 1) === ' ') break; // last line of EHLO
        }

        if ($secure === 'tls') {
            $write('STARTTLS');
            $read();
            stream_socket_enable_crypto($sock, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            $write('EHLO ' . ($_SERVER['HTTP_HOST'] ?? 'localhost'));
            while (($line = $read()) !== false) {
                if (substr($line, 3, 1) === ' ') break;
            }
        }

        $write('AUTH LOGIN');
        $read();
        $write(base64_encode($user));
        $read();
        $write(base64_encode($pass));
        $r = $read();
        if (substr(trim($r), 0, 3) !== '235') { fclose($sock); return false; }

        $write("MAIL FROM:<{$from_addr}>");
        $read();
        $write("RCPT TO:<{$to}>");
        $read();
        $write('DATA');
        $read();

        $enc_subject = '=?' . $charset . '?B?' . base64_encode($subject) . '?=';
        $msg  = "From: =?{$charset}?B?" . base64_encode($from_name) . "?= <{$from_addr}>\r\n";
        $msg .= "To: {$to}\r\n";
        $msg .= "Subject: {$enc_subject}\r\n";
        $msg .= "MIME-Version: 1.0\r\n";
        $msg .= "Content-Type: text/html; charset={$charset}\r\n";
        $msg .= "X-Mailer: ZamkniętyMini/1.0\r\n";
        $msg .= "\r\n";
        $msg .= $html_body . "\r\n";
        $msg .= '.';

        $write($msg);
        $r = $read();
        $write('QUIT');
        fclose($sock);

        return substr(trim($r), 0, 3) === '250';

    } catch (\Throwable $e) {
        return false;
    }
}
