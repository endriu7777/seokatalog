<?php
// Zamknięty mini v1.0 - mail_usunieto.php
// Wysyła e-mail do użytkownika po odrzuceniu wpisu

if (empty($wpis) || empty($cfg)) return;

$temat = $cfg['mailu_tem'] ?? 'Wpis odrzucony';
$body  = $cfg['mailu_tre'] ?? 'Witaj, Twój wpis nie został dodany.';

$body = str_replace('[MyBB[email]]', $wpis['mail'] ?? '', $body);
$body = str_replace('[MyBB[home]]',  $cfg['o4'] ?? '', $body);
$body = str_replace('[MyBB[tytul]]', $wpis['tytul'] ?? '', $body);

$html_mail = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head><body>' . nl2br(htmlspecialchars($body, ENT_QUOTES, 'UTF-8')) . '</body></html>';

if (!empty($wpis['mail']) && filter_var($wpis['mail'], FILTER_VALIDATE_EMAIL)) {
    zm_send_mail($cfg, $wpis['mail'], $temat, $html_mail);
}
