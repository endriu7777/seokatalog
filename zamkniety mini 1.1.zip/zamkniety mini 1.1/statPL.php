<?php
// statPL.php — Statystyki katalogu (wersja polska)
// Użycie w boxie reklamowym w Wygląd: <php>statPL.php</php>

global $pdo, $prefix;
if (empty($pdo) || empty($prefix)) return;

// Liczniki z tabeli ilosci
$_sp = [];
foreach ($pdo->query("SELECT nazwa, ilosc FROM {$prefix}ilosci") as $r) {
    $_sp[$r['nazwa']] = (int)$r['ilosc'];
}

// Odwiedziny dziś — unikalne IP dzisiaj (tabela wizyty)
try {
    $_ss = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}wizyty WHERE dzien = CURDATE()");
    $_ss->execute();
    $_sp_day = (int)$_ss->fetchColumn();
} catch (Exception $e) { $_sp_day = 0; }

// Online teraz — aktywne sesje z ostatnich 3 minut
try {
    $_so = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}sesje WHERE czas > :t");
    $_so->execute([':t' => time() - 180]);
    $_sp_online = (int)$_so->fetchColumn();
} catch (Exception $e) { $_sp_online = (int)($_sp['sescount'] ?? 0); }

$_sp_total  = (int)($_sp['odwiedziny'] ?? 0);  // unikalne IP-dzień łącznie (z ilosci)
$_sp_wpi_a  = (int)($_sp['wpi_a']     ?? 0);
$_sp_wpi_n  = (int)($_sp['wpi_n']     ?? 0);
$_sp_kat    = (int)($_sp['kat_a'] ?? 0) + (int)($_sp['kat_n'] ?? 0);
$_sp_pod    = (int)($_sp['pod_a'] ?? 0) + (int)($_sp['pod_n'] ?? 0);
?>
<div class="stat_box">
<div class="stat_title">&#128202; Statystyki katalogu</div>
<table class="stat_table">
<tr><td class="stat_label">Wpisów aktywnych:</td><td class="stat_val"><?php echo $_sp_wpi_a; ?></td></tr>
<tr><td class="stat_label">Wpisów nieaktywnych:</td><td class="stat_val"><?php echo $_sp_wpi_n; ?></td></tr>
<tr><td class="stat_label">Kategorii:</td><td class="stat_val"><?php echo $_sp_kat; ?></td></tr>
<tr><td class="stat_label">Podkategorii:</td><td class="stat_val"><?php echo $_sp_pod; ?></td></tr>
<tr class="stat_sep"><td class="stat_label">Odwiedzin łącznie:</td><td class="stat_val"><?php echo number_format($_sp_total, 0, ',', '&nbsp;'); ?></td></tr>
<tr><td class="stat_label">Odwiedzin dziś:</td><td class="stat_val"><?php echo $_sp_day; ?></td></tr>
<tr><td class="stat_label">Online teraz:</td><td class="stat_val"><span class="stat_online">&#9679; <?php echo $_sp_online; ?></span></td></tr>
</table>
</div>
<style>.stat_box{font-size:12px;color:#2a4a6a;margin:4px 0}.stat_title{font-weight:bold;font-size:13px;color:#1a3a6a;margin-bottom:6px;padding-bottom:4px;border-bottom:1px solid rgba(100,160,220,.3)}.stat_table{width:100%;border-collapse:collapse}.stat_label{padding:2px 4px 2px 0;color:#5a7a9a;vertical-align:top}.stat_val{padding:2px 0;font-weight:bold;color:#1a3a6a;text-align:right;white-space:nowrap}.stat_sep td{border-top:1px solid rgba(100,160,220,.2);padding-top:5px}.stat_online{color:#2a8a2a;font-weight:bold}</style>
