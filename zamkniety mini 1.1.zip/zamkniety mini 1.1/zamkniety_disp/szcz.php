<?php
// Zamknięty mini v1.0 - szcz.php
    $wpis_id = (int)($_GET['id'] ?? 0);
    $stmt    = $pdo->prepare("SELECT * FROM {$prefix}wpisy WHERE id = :id AND akt = '1'");
    $stmt->execute([':id' => $wpis_id]);
    $li_lw   = $stmt->fetch();

    if (!empty($li_lw['id']) && $li_lw['akt'] == 1) {
        $pdo->prepare("UPDATE {$prefix}wpisy SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$wpis_id]);

        disp_header(
            $li_lw['tytul'] . ' - ' . ($cfg['o1'] ?? ''),
            $li_lw['opis']  . ' - ' . ($cfg['o2'] ?? ''),
            $li_lw['slowa'] . ' - ' . ($cfg['o3'] ?? '')
        );

        mini_magic($tpl['ads2'] ?? '');

        $url2   = 'http://' . $li_lw['url'] . '/' . $li_lw['uri'];
        $url2_e = htmlspecialchars($url2, ENT_QUOTES, 'UTF-8');
        $tytul  = htmlspecialchars($li_lw['tytul'], ENT_QUOTES, 'UTF-8');
        $data   = date('d-m-Y', (int)$li_lw['data']);
        $det    = htmlspecialchars(szcz_link($wpis_id, $li_lw['tytul'], $cfg), ENT_QUOTES, 'UTF-8');

        $w5_szcz = (int)($cfg['w5'] ?? 2);
        $url1 = ($w5_szcz === 1) ? $url2_e : htmlspecialchars('index.php?a=go&id=' . $wpis_id, ENT_QUOTES, 'UTF-8');
        $t_attr_szcz = ($w5_szcz === 1 && !empty($target)) ? $target : ' target="_blank"';

        echo '<div class="links_block">';
        echo '<div class="link_block">';
        echo '<table><tr><td class="wpistd">';
        if ($cfg['min'] == 1) {
            $svg_raw_szcz = '<svg xmlns="http://www.w3.org/2000/svg" width="80" height="60" viewBox="0 0 80 60">'
                . '<rect width="80" height="60" fill="#e8f0f8" rx="3"/>'
                . '<rect width="80" height="60" fill="none" stroke="#b0c8e0" stroke-width="1" rx="3"/>'
                . '<line x1="0" y1="0" x2="80" y2="60" stroke="#ccd8e8" stroke-width="0.7"/>'
                . '<line x1="80" y1="0" x2="0" y2="60" stroke="#ccd8e8" stroke-width="0.7"/>'
                . '<rect x="-5" y="18" width="90" height="16" fill="#b82020" opacity="0.88" transform="rotate(-22 40 26)"/>'
                . '<text x="40" y="28" font-family="Arial,Helvetica,sans-serif" font-size="8.5" font-weight="bold" fill="#ffffff" text-anchor="middle" transform="rotate(-22 40 26)" letter-spacing="0.8">ZAMKNIETY</text>'
                . '</svg>';
            $svg_thumb_szcz = 'data:image/svg+xml;base64,' . base64_encode($svg_raw_szcz);
            echo '<img src="' . $svg_thumb_szcz . '" class="msn" alt="zamkniety" loading="lazy" width="80" height="60" />';
        }
        echo '</td><td class="wpistd">';
        echo '<a href="' . $url1 . '" class="out_link"' . $nofollow . $t_attr_szcz . '>' . $tytul . '</a>';
        echo '<div class="text_link">' . dekoder($li_lw['opis']) . '</div>';
        echo '<div class="text_link">' . $url2_e . '</div>';
        echo '<div class="text_link">data dodania wpisu: ' . $data . '</div>';
        echo '<div class="text_link"><b>Keywords:</b> ' . htmlspecialchars($li_lw['slowa'], ENT_QUOTES, 'UTF-8') . '</div>';
        echo '</td></tr></table></div>';

        // Related categories
        if ((int)$li_lw['relacji'] > 0) {
            $rel = $pdo->prepare("SELECT * FROM {$prefix}relacje WHERE id_wpi = :id");
            $rel->execute([':id' => $wpis_id]);
            echo '<div class="text_body_h3">' . fl('entry_in_subcats') . '</div>';
            while ($l = $rel->fetch()) {
                $p_stmt = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id = :id");
                $p_stmt->execute([':id' => $l['id_pod']]);
                $pod = $p_stmt->fetch();
                $k_stmt = $pdo->prepare("SELECT * FROM {$prefix}kategorie WHERE id = :id");
                $k_stmt->execute([':id' => $l['id_kat']]);
                $kat = $k_stmt->fetch();

                if ($kat['akt'] == 1 && $pod['akt'] == 1) {
                    $kl = htmlspecialchars(kat_link((int)$l['id_kat'], $kat['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
                    $pl = htmlspecialchars(pod_link((int)$l['id_pod'], $pod['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
                    echo '<div class="nav_det"><a href="' . $kl . '" class="body_links">' . htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8') . '</a> / <a href="' . $pl . '" class="body_links">' . htmlspecialchars($pod['nazwa'], ENT_QUOTES, 'UTF-8') . '</a></div>';
                }
            }
        }

        echo '</div>';

        if ($cfg['loktag'] == 1 && !empty($li_lw['slowa'])) {
            lokalne_tagi($li_lw['slowa']);
        }

        if ($cfg['pob_tresc'] == 1) {
            $source = @file_get_contents($url2);
            $data_t = html2txt($source ?: '');
            echo '<div class="text_body_h3">Szybki podgląd zawartości ' . $url2_e . ':</div>';
            echo '<div class="ramka">' . htmlspecialchars($data_t, ENT_QUOTES, 'UTF-8') . '</div>';
        }

        if ($cfg['rss'] == 1) {
            rss_parser($li_lw['rss'] ?? '', $cfg['rss_kanal'] ?? '');
        }

        // Open Page Rank na stronie szczegółów
        if ((int)($cfg['opr'] ?? 0) === 1 && !empty($cfg['opr_key'])) {
            $opr_domain = parse_url($url2, PHP_URL_HOST) ?: $li_lw['url'];
            $opr_cache_file = sys_get_temp_dir() . '/opr_' . md5($opr_domain) . '.txt';
            $opr_rank = null;
            if (file_exists($opr_cache_file) && (time() - filemtime($opr_cache_file)) < 86400) {
                $opr_rank = (int)file_get_contents($opr_cache_file);
            } else {
                $opr_url = 'https://openpagerank.com/api/v1.0/getPageRank?domains%5B0%5D=' . urlencode($opr_domain);
                $opr_ctx = stream_context_create(['http' => [
                    'method'  => 'GET',
                    'header'  => 'API-OPR: ' . trim($cfg['opr_key']),
                    'timeout' => 3,
                ]]);
                $opr_resp = @file_get_contents($opr_url, false, $opr_ctx);
                if ($opr_resp) {
                    $opr_json = @json_decode($opr_resp, true);
                    $opr_rank = (int)($opr_json['response'][0]['page_rank_integer'] ?? 0);
                    @file_put_contents($opr_cache_file, $opr_rank);
                }
            }
            if ($opr_rank !== null) {
                $opr_color = $opr_rank >= 7 ? '#2a8a2a' : ($opr_rank >= 4 ? '#e07a00' : '#7a9aaa');
                echo '<div class="text_link" style="margin-top:6px;">'
                    . '<span style="font-size:11px;background:' . $opr_color . ';color:#fff;padding:2px 8px;border-radius:3px;font-weight:bold;">'
                    . 'PAGE RANK = ' . $opr_rank
                    . '</span></div>';
            }
        }

        include __DIR__ . '/robots.php';
        mini_magic($tpl['ads3'] ?? '');
        disp_footer();

    } else {
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: /');
        header('Connection: close');
        exit;
    }
