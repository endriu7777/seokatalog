<?php
// Zamknięty mini v1.0 - pp.php (Polityka prywatności / Privacy Policy)
    $lang = !empty($_SESSION['lang']) ? $_SESSION['lang'] : 'pl';
    $title = ($lang === 'en') ? 'Privacy Policy' : 'Polityka prywatności';
    disp_header(
        $title . ' - ' . ($cfg['o1'] ?? ''),
        $cfg['o2'] ?? '',
        $cfg['o3'] ?? ''
    );
    mini_magic($tpl['ads2'] ?? '');
    echo '<div class="text_body_h1">' . htmlspecialchars($title, ENT_QUOTES, 'UTF-8') . '</div>';
    echo $tpl['pp'] ?? '<p>' . ($lang === 'en' ? 'No privacy policy content.' : 'Brak treści polityki prywatności.') . '</p>';
    mini_magic($tpl['ads3'] ?? '');
    disp_footer();
