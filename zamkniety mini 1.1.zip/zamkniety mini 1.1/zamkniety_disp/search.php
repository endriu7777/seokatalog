<?php
// Zamknięty mini v1.0 - search.php
    if (($_GET['a'] ?? '') === 'search') {

        $szukaj_raw = $_GET['szukaj'] ?? '';
        $sep        = $cfg['m2'] ?? '-';
        $szukaj_raw = str_replace($sep, ' ', trim($szukaj_raw));

        // Check if it is a tag code
        $tag_stmt = $pdo->prepare("SELECT slowo FROM {$prefix}tagi WHERE kod = :kod");
        $tag_stmt->execute([':kod' => $szukaj_raw]);
        $tag_row  = $tag_stmt->fetch();
        if (!empty($tag_row['slowo'])) {
            $szukaj_raw    = trim($tag_row['slowo']);
            $cfg['m8'] = 'tag';
        }

        $szukaj = $szukaj_raw;

        $po_ile = (int)($cfg['p1'] ?? 10);
        $min    = max(0, (int)($_GET['min'] ?? 0));
        $next   = $min + $po_ile;
        $prev   = $min - $po_ile;

        // Count total results (use prepared statement to prevent SQL injection)
        $count_stmt = $pdo->prepare(
            "SELECT COUNT(*) FROM {$prefix}wpisy
             WHERE (tytul LIKE :s1 OR url LIKE :s2 OR opis LIKE :s3 OR slowa LIKE :s4) AND akt='1'"
        );
        $like = '%' . $szukaj . '%';
        $count_stmt->execute([':s1'=>$like,':s2'=>$like,':s3'=>$like,':s4'=>$like]);
        $kat_count = (int)$count_stmt->fetchColumn();

        $m8    = $cfg['m8'] ?? '';
        if ($m8 === '') $cfg['m8'] = $m8 = 'search';

        // Pagination
        $dod = '';
        $stron = (int)floor($kat_count / $po_ile);
        if ($prev >= 0) {
            $dod .= '<a href="index.php?a=search&amp;szukaj=' . urlencode($szukaj) . '&amp;min=' . $prev . '" class="body_links">&lt; prev</a> | ';
        }
        for ($i = 0; $i <= $stron; $i++) {
            $strona = $i * $po_ile;
            $j      = $i + 1;
            if ($stron < 10 || $j <= 3 || ($stron > 10 && $j > $stron - 2)) {
                $dod .= '<a href="index.php?a=search&amp;szukaj=' . urlencode($szukaj) . '&amp;min=' . $strona . '" class="body_links">' . $j . '</a> | ';
            }
        }
        if ($next >= $po_ile && $kat_count > $next) {
            $dod .= '<a href="index.php?a=search&amp;szukaj=' . urlencode($szukaj) . '&amp;min=' . $next . '" class="body_links">next &gt;</a>';
        }

        $min_list  = $min + 1;
        $next_list = ($next >= $kat_count) ? $kat_count : $next;
        $listwa    = '';
        if ($kat_count > $po_ile) {
            $listwa = '<div class="nav">wyświetlono: ' . $min_list . ' - ' . $next_list . ' z <b>' . $kat_count . '</b> &nbsp; ' . $dod . '</div>';
        }

        disp_header(
            fl('search_result') . ' ' . htmlspecialchars($szukaj, ENT_QUOTES, 'UTF-8'),
            fl('search_result') . ' ' . htmlspecialchars($szukaj, ENT_QUOTES, 'UTF-8'),
            htmlspecialchars($szukaj, ENT_QUOTES, 'UTF-8')
        );
        mini_magic($tpl['ads2'] ?? '');

        echo '<div class="text_body_h3">' . fl('search_result') . ' ' . htmlspecialchars($szukaj, ENT_QUOTES, 'UTF-8') . '</div>';

        if ($szukaj !== '') {
            $li_stmt = $pdo->prepare(
                "SELECT * FROM {$prefix}wpisy
                 WHERE akt='1' AND (tytul LIKE :s1 OR url LIKE :s2 OR opis LIKE :s3 OR slowa LIKE :s4)
                 LIMIT :min, :po_ile"
            );
            $li_stmt->bindValue(':s1', $like);
            $li_stmt->bindValue(':s2', $like);
            $li_stmt->bindValue(':s3', $like);
            $li_stmt->bindValue(':s4', $like);
            $li_stmt->bindValue(':min',    $min,    PDO::PARAM_INT);
            $li_stmt->bindValue(':po_ile', $po_ile, PDO::PARAM_INT);
            $li_stmt->execute();

            echo $listwa;
            echo '<div class="links_block">';

            $any = false;
            while ($li = $li_stmt->fetch()) {
                $any = true;
                render_entry($li, $pdo, $prefix, $cfg, $nofollow, $target);
            }
            if (!$any) {
                echo '<div class="text_body_h3">' . fl('search_no_result') . ' ' . htmlspecialchars($szukaj, ENT_QUOTES, 'UTF-8') . '</div>';
            }
            echo '</div>';
            echo $listwa;
        } else {
            echo 'Brak wpisów.';
        }

        mini_magic($tpl['ads3'] ?? '');
        disp_footer();

    } else {
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: /');
        header('Connection: close');
        exit;
    }
