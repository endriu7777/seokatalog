<?php
// Zamknięty mini v1.0 - pod.php
    $pod_id = (int)($_GET['id'] ?? 0);
    $stmt   = $pdo->prepare("SELECT * FROM {$prefix}podkategorie WHERE id = :id AND akt = '1'");
    $stmt->execute([':id' => $pod_id]);
    $pod    = $stmt->fetch();

    if (!empty($pod['id']) && $pod['akt'] == 1) {
        $kat_stmt = $pdo->prepare("SELECT * FROM {$prefix}kategorie WHERE id = :id AND akt = '1'");
        $kat_stmt->execute([':id' => $pod['id_kat']]);
        $kat = $kat_stmt->fetch();

        $pdo->prepare("UPDATE {$prefix}podkategorie SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$pod_id]);

        $po_ile = (int)($cfg['p1'] ?? 10);
        $min    = max(0, (int)($_GET['min'] ?? 0));
        $next   = $min + $po_ile;
        $prev   = $min - $po_ile;

        // Sortowanie: link_prz=1 promuje wpisy z linkiem zwrotnym, link_sor=1 sortuje po URL linku zwrotnego
        if ((int)($cfg['link_prz'] ?? 0) === 1) {
            $sortuj = 'CASE WHEN w.link_zwrotny!=\'\' AND w.link_zwrotny IS NOT NULL THEN 0 ELSE 1 END ASC, ';
        } elseif ((int)($cfg['link_sor'] ?? 0) === 1) {
            $sortuj = 'w.link_zwrotny DESC, ';
        } else {
            $sortuj = '';
        }

        $zap = $pdo->prepare(
            "SELECT w.* FROM {$prefix}relacje r
             JOIN {$prefix}wpisy w ON w.id = r.id_wpi
             WHERE r.id_kat = :kid AND r.id_pod = :pid AND w.akt = 1
             ORDER BY {$sortuj} w.tytul
             LIMIT :min, :po_ile"
        );
        $zap->bindValue(':kid', $pod['id_kat'], PDO::PARAM_INT);
        $zap->bindValue(':pid', $pod_id, PDO::PARAM_INT);
        $zap->bindValue(':min', $min, PDO::PARAM_INT);
        $zap->bindValue(':po_ile', $po_ile, PDO::PARAM_INT);
        $zap->execute();

        // Pagination
        $dod   = '';
        $total = (int)$pod['wpi_a'];
        $stron = (int)floor($total / $po_ile);
        if ($prev >= 0) {
            $dod .= '<a href="index.php?a=pod&amp;id=' . $pod_id . '&amp;min=' . $prev . '" class="body_links">&lt; prev</a> | ';
        }
        for ($i = 0; $i <= $stron; $i++) {
            $strona = $i * $po_ile;
            $j      = $i + 1;
            if ($stron < 10 || $j <= 3 || ($stron > 10 && $j > $stron - 2)) {
                $dod .= '<a href="index.php?a=pod&amp;id=' . $pod_id . '&amp;min=' . $strona . '" class="body_links">' . $j . '</a> | ';
            }
        }
        if ($next >= $po_ile && $total > $next) {
            $dod .= '<a href="index.php?a=pod&amp;id=' . $pod_id . '&amp;min=' . $next . '" class="body_links">next &gt;</a>';
        }

        $min_list  = $min + 1;
        $next_list = ($next >= $total) ? $total : $next;
        $listwa    = '';
        if ($total > $po_ile) {
            $listwa = '<div class="nav">wyświetlono: ' . $min_list . ' - ' . $next_list . ' z <b>' . $total . '</b> &nbsp; ' . $dod . '</div>';
        }

        disp_header(
            $kat['nazwa'] . ' / ' . $pod['nazwa'] . ' - ' . ($cfg['o1'] ?? ''),
            $kat['nazwa'] . ' / ' . $pod['nazwa'] . ' - ' . ($cfg['o2'] ?? ''),
            $kat['nazwa'] . ' / ' . $pod['nazwa'] . ' - ' . ($cfg['o3'] ?? '')
        );

        $kat_link_e = htmlspecialchars(kat_link((int)$pod['id_kat'], $kat['nazwa'], $cfg), ENT_QUOTES, 'UTF-8');
        echo '<div style="margin-bottom:10px;"><a href="' . $kat_link_e . '" class="in_link_home_cat">' . htmlspecialchars($kat['nazwa'], ENT_QUOTES, 'UTF-8') . '</a><span class="text_body_h1"> &raquo; ' . htmlspecialchars($pod['nazwa'], ENT_QUOTES, 'UTF-8') . '</span></div>';

        mini_magic($tpl['ads2'] ?? '');

        if ($total > 0) {
            echo $listwa;
            echo '<div class="links_block">';
            while ($li = $zap->fetch()) {
                $pdo->prepare("UPDATE {$prefix}wpisy SET odslon=odslon+1 WHERE id=:id")->execute([':id'=>$li['id']]);
                render_entry($li, $pdo, $prefix, $cfg, $nofollow, $target);
            }
            echo '</div>';
            include 'robots.php';
            echo $listwa;
        } else {
            echo fl('no_entries');
        }
?>
<div class="add_block">
<?php add_link_form('', (int)$pod['id_kat'], $pod_id); ?>
</div>
<?php
        mini_magic($tpl['ads3'] ?? '');
        disp_footer();
    } else {
        header('HTTP/1.1 301 Moved Permanently');
        header('Location: /');
        header('Connection: close');
        exit;
    }
