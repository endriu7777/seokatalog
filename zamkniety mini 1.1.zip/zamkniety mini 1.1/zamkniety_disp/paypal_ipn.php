<?php
// Zamknięty mini v1.0 - paypal_ipn.php
// PayPal Instant Payment Notification (IPN) handler
// Wywoływany przez PayPal automatycznie po każdej płatności

global $pdo, $prefix, $cfg;

// PayPal IPN verification
$mode     = $cfg['pp_mode'] ?? 'sandbox';
$pp_host  = ($mode === 'live') ? 'ipnpb.paypal.com' : 'ipnpb.sandbox.paypal.com';
$pp_url   = 'https://' . $pp_host . '/cgi-bin/webscr';

// Read raw POST data
$raw_post = file_get_contents('php://input');
if (empty($raw_post)) {
    http_response_code(200);
    exit;
}

// Send verification back to PayPal
$verify_body = 'cmd=_notify-validate&' . $raw_post;
$ctx = stream_context_create([
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/x-www-form-urlencoded\r\nUser-Agent: PHP-IPN-Verification\r\n",
        'content' => $verify_body,
        'timeout' => 15,
        'ignore_errors' => true,
    ],
    'ssl' => ['verify_peer' => true],
]);
$verify_response = @file_get_contents($pp_url, false, $ctx);

if ($verify_response !== 'VERIFIED') {
    // Log invalid IPN
    $pdo->prepare("INSERT IGNORE INTO {$prefix}ilosci (nazwa,ilosc) VALUES ('ipn_invalid',0)")
        ->execute();
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='ipn_invalid'");
    http_response_code(200);
    exit;
}

// Parse IPN data
parse_str($raw_post, $ipn);

$payment_status = $ipn['payment_status'] ?? '';
$txn_id         = $ipn['txn_id']         ?? '';
$receiver_email = strtolower($ipn['receiver_email'] ?? '');
$our_email      = strtolower($cfg['pp_email'] ?? '');
$amount_paid    = (float)($ipn['mc_gross'] ?? 0);
$currency       = $ipn['mc_currency'] ?? '';
$item_number    = (int)($ipn['item_number'] ?? ($ipn['custom'] ?? 0));
$expected_price = (float)($cfg['pp_price'] ?? 0);
$expected_curr  = $cfg['pp_currency'] ?? 'PLN';

// Security checks
if ($receiver_email !== $our_email) { http_response_code(200); exit; }
if ($payment_status !== 'Completed') { http_response_code(200); exit; }
if ($expected_price > 0 && abs($amount_paid - $expected_price) > 0.01) { http_response_code(200); exit; }
if ($expected_price > 0 && strtoupper($currency) !== strtoupper($expected_curr)) { http_response_code(200); exit; }
if (!$item_number) { http_response_code(200); exit; }

// Check for duplicate IPN (prevent double activation)
$dup = $pdo->prepare("SELECT id FROM {$prefix}wpisy WHERE id=:id AND akt=1");
$dup->execute([':id' => $item_number]);
if ($dup->fetch()) { http_response_code(200); exit; }

// Activate the entry
$pdo->prepare("UPDATE {$prefix}wpisy SET akt=1 WHERE id=:id AND akt=0")
    ->execute([':id' => $item_number]);

if ($pdo->rowCount() > 0) {
    // Update counters
    $rels = $pdo->prepare("SELECT id_kat, id_pod FROM {$prefix}relacje WHERE id_wpi=:id");
    $rels->execute([':id' => $item_number]);
    foreach ($rels->fetchAll() as $rel) {
        $pdo->prepare("UPDATE {$prefix}kategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id'=>$rel['id_kat']]);
        $pdo->prepare("UPDATE {$prefix}podkategorie SET wpi_a=wpi_a+1, wpi_n=GREATEST(0,wpi_n-1) WHERE id=:id")->execute([':id'=>$rel['id_pod']]);
    }
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='wpi_a'");
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=GREATEST(0,ilosc-1) WHERE nazwa='wpi_n'");

    // Add tags
    $wpi_row = $pdo->prepare("SELECT slowa FROM {$prefix}wpisy WHERE id=:id");
    $wpi_row->execute([':id' => $item_number]);
    $wpi_data = $wpi_row->fetch();
    if ($wpi_data && !empty($wpi_data['slowa'])) {
        foreach (explode(',', $wpi_data['slowa']) as $tag_raw) {
            $tag_trim = trim($tag_raw);
            if ($tag_trim === '') continue;
            $tag_kod = preg_replace('/[^a-z0-9\-]/','',str_replace(' ','-',mb_strtolower($tag_trim,'UTF-8')));
            $ex = $pdo->prepare("SELECT COUNT(*) FROM {$prefix}tagi WHERE slowo=:s");
            $ex->execute([':s' => $tag_trim]);
            if ($ex->fetchColumn() < 1) {
                $pdo->prepare("INSERT INTO {$prefix}tagi (slowo,kod,ilosc) VALUES (:s,:k,1)")->execute([':s'=>$tag_trim,':k'=>$tag_kod]);
            } else {
                $pdo->prepare("UPDATE {$prefix}tagi SET ilosc=ilosc+1 WHERE slowo=:s")->execute([':s'=>$tag_trim]);
            }
        }
    }

    // Log successful IPN
    $pdo->prepare("INSERT IGNORE INTO {$prefix}ilosci (nazwa,ilosc) VALUES ('ipn_ok',0)")->execute();
    $pdo->exec("UPDATE {$prefix}ilosci SET ilosc=ilosc+1 WHERE nazwa='ipn_ok'");
}

http_response_code(200);
exit;
