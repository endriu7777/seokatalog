<?php
// Zamknięty mini v1.0 - paypal.php
// Obsługuje redirect do PayPal oraz powrót po płatności

global $pdo, $prefix, $cfg;

$action = $_GET['action'] ?? '';

// ============================================================
// REDIRECT DO PAYPAL — po zapisaniu wpisu
// ============================================================
if ($action === 'pay') {
    $wpi_id  = (int)($_GET['wpi'] ?? 0);
    if (!$wpi_id) { header('Location: index.php'); exit; }

    $mode      = $cfg['pp_mode']       ?? 'sandbox';
    $email     = $cfg['pp_email']       ?? '';
    $price     = number_format((float)($cfg['pp_price'] ?? 0), 2, '.', '');
    $currency  = $cfg['pp_currency']    ?? 'PLN';
    $item_name = $cfg['pp_item_name']   ?? 'Dodanie wpisu do katalogu';
    $base      = rtrim($cfg['o4'] ?? ('http://'.($_SERVER['HTTP_HOST']??'')), '/');
    $return_url = !empty($cfg['pp_return_url']) ? $cfg['pp_return_url'] : $base . '/index.php?a=paypal&action=success&wpi=' . $wpi_id;
    $cancel_url = !empty($cfg['pp_cancel_url']) ? $cfg['pp_cancel_url'] : $base . '/index.php?a=paypal&action=cancel&wpi=' . $wpi_id;
    $ipn_url    = $base . '/index.php?a=paypal_ipn';

    $pp_url = ($mode === 'live')
        ? 'https://www.paypal.com/cgi-bin/webscr'
        : 'https://www.sandbox.paypal.com/cgi-bin/webscr';

    // Build PayPal form and auto-submit
    disp_header('Przekierowanie do PayPal', '', '');
    echo '<div class="text_body_h1">Przekierowanie do PayPal...</div>';
    echo '<p>' . htmlspecialchars($cfg['pp_msg_pending'] ?? 'Trwa przekierowanie do systemu płatności PayPal.', ENT_QUOTES, 'UTF-8') . '</p>';
    echo '<form id="ppform" action="' . htmlspecialchars($pp_url, ENT_QUOTES, 'UTF-8') . '" method="post">';
    echo '<input type="hidden" name="cmd"           value="_xclick">';
    echo '<input type="hidden" name="business"      value="' . htmlspecialchars($email, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="item_name"     value="' . htmlspecialchars($item_name, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="item_number"   value="' . $wpi_id . '">';
    echo '<input type="hidden" name="amount"        value="' . $price . '">';
    echo '<input type="hidden" name="currency_code" value="' . htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="return"        value="' . htmlspecialchars($return_url, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="cancel_return" value="' . htmlspecialchars($cancel_url, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="notify_url"    value="' . htmlspecialchars($ipn_url, ENT_QUOTES, 'UTF-8') . '">';
    echo '<input type="hidden" name="charset"       value="UTF-8">';
    echo '<input type="hidden" name="no_shipping"   value="1">';
    echo '<input type="hidden" name="custom"        value="' . $wpi_id . '">';
    echo '<noscript><button type="submit" class="button">Kliknij aby przejść do PayPal</button></noscript>';
    echo '</form>';
    echo '<script>document.getElementById("ppform").submit();</script>';
    disp_footer();
    exit;
}

// ============================================================
// POWRÓT PO UDANEJ PŁATNOŚCI
// ============================================================
if ($action === 'success') {
    $wpi_id = (int)($_GET['wpi'] ?? 0);
    $msg = htmlspecialchars($cfg['pp_msg_success'] ?? 'Dziękujemy za płatność!', ENT_QUOTES, 'UTF-8');
    disp_header('Płatność zakończona', '', '');
    echo '<div class="text_body_h1">✅ ' . ($cfg['pp_lang'] === 'en' ? 'Payment successful' : 'Płatność zakończona') . '</div>';
    echo '<p>' . $msg . '</p>';
    echo '<p><a href="' . htmlspecialchars($cfg['o4'] ?? '/', ENT_QUOTES, 'UTF-8') . '" class="button">→ ' . ($cfg['pp_lang'] === 'en' ? 'Back to directory' : 'Powrót do katalogu') . '</a></p>';
    disp_footer();
    exit;
}

// ============================================================
// ANULOWANIE PŁATNOŚCI
// ============================================================
if ($action === 'cancel') {
    $wpi_id = (int)($_GET['wpi'] ?? 0);
    // Delete pending entry on cancel if price > 0
    if ($wpi_id && (float)($cfg['pp_price'] ?? 0) > 0) {
        $pdo->prepare("DELETE FROM {$prefix}wpisy WHERE id=:id AND akt=0")->execute([':id'=>$wpi_id]);
        $pdo->prepare("DELETE FROM {$prefix}relacje WHERE id_wpi=:id")->execute([':id'=>$wpi_id]);
    }
    $msg = htmlspecialchars($cfg['pp_msg_error'] ?? 'Płatność została anulowana.', ENT_QUOTES, 'UTF-8');
    disp_header('Płatność anulowana', '', '');
    echo '<div class="text_body_h1">⚠️ ' . ($cfg['pp_lang'] === 'en' ? 'Payment cancelled' : 'Płatność anulowana') . '</div>';
    echo '<p>' . $msg . '</p>';
    echo '<p><a href="' . htmlspecialchars($cfg['o4'] ?? '/', ENT_QUOTES, 'UTF-8') . '" class="button">→ ' . ($cfg['pp_lang'] === 'en' ? 'Back to directory' : 'Powrót do katalogu') . '</a></p>';
    disp_footer();
    exit;
}

// Default redirect
header('Location: index.php');
exit;
