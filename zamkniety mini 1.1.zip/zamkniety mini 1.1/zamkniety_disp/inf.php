<?php
// Zamknięty mini v1.1 - inf.php
    $lang_inf = $_SESSION['lang'] ?? 'pl';
    $inf_title = ($lang_inf === 'en') ? 'Terms of Service' : 'Regulamin';
    disp_header(
        $inf_title . ' - ' . ($cfg['o1'] ?? ''),
        $cfg['o2'] ?? '',
        $cfg['o3'] ?? ''
    );
    mini_magic($tpl['ads2'] ?? '');
    echo '<div class="text_body_h1">' . htmlspecialchars($inf_title, ENT_QUOTES, 'UTF-8') . '</div>';
    echo $tpl['inf'] ?? '<p>' . ($lang_inf === 'en' ? 'No terms content.' : 'Brak treści regulaminu.') . '</p>';
    mini_magic($tpl['ads3'] ?? '');
    disp_footer();
