<?php
// Zamknięty mini v1.1 - blok_menu.php
// Dynamiczne menu nawigacyjne z obsługą języka PL/EN
// Użycie w zakładce Wygląd: <php>blok_menu.php</php>

global $cfg;

$lang = $_SESSION['lang'] ?? 'pl';
$m1   = (int)($cfg['m1'] ?? 0);
$m6   = $cfg['m6'] ?? 'inf';

// Build URLs
$home_url = ($cfg['o4'] ?? '') ?: '/';
$inf_url  = ($m1===1||$m1===3) ? '/'. $m6 .'.html' : 'index.php?a=inf';
$pp_url   = ($m1===1||$m1===3) ? '/pp.html'         : 'index.php?a=pp';

// Labels
if ($lang === 'en') {
    $lbl_home = 'Home';
    $lbl_inf  = 'Terms of Service';
    $lbl_pp   = 'Privacy Policy';
} else {
    $lbl_home = 'Strona główna';
    $lbl_inf  = 'Regulamin';
    $lbl_pp   = 'Polityka prywatności';
}
?>
<div style="padding:8px 0;">
    <a href="<?= htmlspecialchars($home_url, ENT_QUOTES, 'UTF-8') ?>" class="in_link_home_cat"><?= htmlspecialchars($lbl_home, ENT_QUOTES, 'UTF-8') ?></a><br />
    <a href="<?= htmlspecialchars($inf_url, ENT_QUOTES, 'UTF-8') ?>" class="in_link_home_cat"><?= htmlspecialchars($lbl_inf, ENT_QUOTES, 'UTF-8') ?></a><br />
    <a href="<?= htmlspecialchars($pp_url, ENT_QUOTES, 'UTF-8') ?>" class="in_link_home_cat"><?= htmlspecialchars($lbl_pp, ENT_QUOTES, 'UTF-8') ?></a>
</div>
